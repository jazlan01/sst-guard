// Window variable extractor - runs in page context
(function() {
  const result = {};
  const seen = new WeakSet();
  
  // Safe stringify that handles circular references
  function safeStringify(value) {
    try {
      return JSON.stringify(value, function(key, val) {
        if (typeof val === 'function') return undefined; // Skip functions entirely
        if (typeof val === 'symbol') return undefined;
        if (val instanceof HTMLElement) return undefined; // Skip DOM elements
        if (val instanceof Node) return undefined;
        if (typeof val === 'object' && val !== null) {
          if (seen.has(val)) return '[Circular]';
          seen.add(val);
        }
        return val;
      });
    } catch (e) {
      return String(value);
    }
  }
  
  // Iterate ALL window properties
  for (const prop of Object.getOwnPropertyNames(window)) {
    try {
      const value = window[prop];
      if (value === undefined || value === null) continue;
      if (value === window) continue;
      if (typeof value === 'function') continue;
      
      const stringified = safeStringify(value);
      if (stringified && stringified.length > 2 && stringified !== 'null') {
        result[prop] = stringified;
      }
    } catch (e) {
      // Skip inaccessible properties
    }
  }
  
  // Dispatch custom event with the data
  window.dispatchEvent(new CustomEvent('__SST_WINDOW_VARS__', { 
    detail: JSON.stringify(result) 
  }));
})();

