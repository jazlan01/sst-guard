/*!
 * ONNX Runtime Web v1.21.0-dev.20250114-228dd16893
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */var Wa=Object.defineProperty,Pm=Object.getOwnPropertyDescriptor,Vm=Object.getOwnPropertyNames,Um=Object.prototype.hasOwnProperty,Wm=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof require<"u"?require:t)[r]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),P=(e,t)=>()=>(e&&(t=e(e=0)),t),fr=(e,t)=>{for(var r in t)Wa(e,r,{get:t[r],enumerable:!0})},qm=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Vm(t))!Um.call(e,a)&&a!==r&&Wa(e,a,{get:()=>t[a],enumerable:!(i=Pm(t,a))||i.enumerable});return e},Fr=e=>qm(Wa({},"__esModule",{value:!0}),e),Yt,ft,Vt,Js,Od,Dd=P(()=>{Yt=new Map,ft=[],Vt=(e,t,r)=>{if(t&&typeof t.init=="function"&&typeof t.createInferenceSessionHandler=="function"){let i=Yt.get(e);if(i===void 0)Yt.set(e,{backend:t,priority:r});else{if(i.priority>r)return;if(i.priority===r&&i.backend!==t)throw new Error(`cannot register backend "${e}" using priority ${r}`)}if(r>=0){let a=ft.indexOf(e);a!==-1&&ft.splice(a,1);for(let s=0;s<ft.length;s++)if(Yt.get(ft[s]).priority<=r){ft.splice(s,0,e);return}ft.push(e)}return}throw new TypeError("not a valid backend")},Js=async e=>{let t=Yt.get(e);if(!t)return"backend not found.";if(t.initialized)return t.backend;if(t.aborted)return t.error;{let r=!!t.initPromise;try{return r||(t.initPromise=t.backend.init(e)),await t.initPromise,t.initialized=!0,t.backend}catch(i){return r||(t.error=`${i}`,t.aborted=!0),t.error}finally{delete t.initPromise}}},Od=async e=>{let t=e.executionProviders||[],r=t.map(d=>typeof d=="string"?d:d.name),i=r.length===0?ft:r,a,s=[],n=new Set;for(let d of i){let p=await Js(d);typeof p=="string"?s.push({name:d,err:p}):(a||(a=p),a===p&&n.add(d))}if(!a)throw new Error(`no available backend found. ERR: ${s.map(d=>`[${d.name}] ${d.err}`).join(", ")}`);for(let{name:d,err:p}of s)r.includes(d)&&console.warn(`removing requested execution provider "${d}" from session options because it is not available: ${p}`);let u=t.filter(d=>n.has(typeof d=="string"?d:d.name));return[a,new Proxy(e,{get:(d,p)=>p==="executionProviders"?u:Reflect.get(d,p)})]}}),Lm=P(()=>{Dd()}),Rd,Fm=P(()=>{Rd="1.21.0-dev.20241212-1f88284f96"}),Ci,Ue,Bd=P(()=>{Fm(),Ci="warning",Ue={wasm:{},webgl:{},webgpu:{},versions:{common:Rd},set logLevel(e){if(e!==void 0){if(typeof e!="string"||["verbose","info","warning","error","fatal"].indexOf(e)===-1)throw new Error(`Unsupported logging level: ${e}`);Ci=e}},get logLevel(){return Ci}},Object.defineProperty(Ue,"logLevel",{enumerable:!0})}),ge,Gm=P(()=>{Bd(),ge=Ue}),Nd,Md,Hm=P(()=>{Nd=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas"):new OffscreenCanvas(1,1);r.width=e.dims[3],r.height=e.dims[2];let i=r.getContext("2d");if(i!=null){let a,s;(t==null?void 0:t.tensorLayout)!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],s=e.dims[3]):(a=e.dims[3],s=e.dims[2]);let n=(t==null?void 0:t.format)!==void 0?t.format:"RGB",u=t==null?void 0:t.norm,d,p;u===void 0||u.mean===void 0?d=[255,255,255,255]:typeof u.mean=="number"?d=[u.mean,u.mean,u.mean,u.mean]:(d=[u.mean[0],u.mean[1],u.mean[2],0],u.mean[3]!==void 0&&(d[3]=u.mean[3])),u===void 0||u.bias===void 0?p=[0,0,0,0]:typeof u.bias=="number"?p=[u.bias,u.bias,u.bias,u.bias]:(p=[u.bias[0],u.bias[1],u.bias[2],0],u.bias[3]!==void 0&&(p[3]=u.bias[3]));let f=s*a,h=0,l=f,y=f*2,_=-1;n==="RGBA"?(h=0,l=f,y=f*2,_=f*3):n==="RGB"?(h=0,l=f,y=f*2):n==="RBG"&&(h=0,y=f,l=f*2);for(let b=0;b<s;b++)for(let v=0;v<a;v++){let x=(e.data[h++]-p[0])*d[0],$=(e.data[l++]-p[1])*d[1],S=(e.data[y++]-p[2])*d[2],k=_===-1?255:(e.data[_++]-p[3])*d[3];i.fillStyle="rgba("+x+","+$+","+S+","+k+")",i.fillRect(v,b,1,1)}if("toDataURL"in r)return r.toDataURL();throw new Error("toDataURL is not supported")}else throw new Error("Can not access image data")},Md=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas").getContext("2d"):new OffscreenCanvas(1,1).getContext("2d"),i;if(r!=null){let a,s,n;(t==null?void 0:t.tensorLayout)!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],s=e.dims[1],n=e.dims[3]):(a=e.dims[3],s=e.dims[2],n=e.dims[1]);let u=t!==void 0&&t.format!==void 0?t.format:"RGB",d=t==null?void 0:t.norm,p,f;d===void 0||d.mean===void 0?p=[255,255,255,255]:typeof d.mean=="number"?p=[d.mean,d.mean,d.mean,d.mean]:(p=[d.mean[0],d.mean[1],d.mean[2],255],d.mean[3]!==void 0&&(p[3]=d.mean[3])),d===void 0||d.bias===void 0?f=[0,0,0,0]:typeof d.bias=="number"?f=[d.bias,d.bias,d.bias,d.bias]:(f=[d.bias[0],d.bias[1],d.bias[2],0],d.bias[3]!==void 0&&(f[3]=d.bias[3]));let h=s*a;if(t!==void 0&&(t.format!==void 0&&n===4&&t.format!=="RGBA"||n===3&&t.format!=="RGB"&&t.format!=="BGR"))throw new Error("Tensor format doesn't match input tensor dims");let l=4,y=0,_=1,b=2,v=3,x=0,$=h,S=h*2,k=-1;u==="RGBA"?(x=0,$=h,S=h*2,k=h*3):u==="RGB"?(x=0,$=h,S=h*2):u==="RBG"&&(x=0,S=h,$=h*2),i=r.createImageData(a,s);for(let T=0;T<s*a;y+=l,_+=l,b+=l,v+=l,T++)i.data[y]=(e.data[x++]-f[0])*p[0],i.data[_]=(e.data[$++]-f[1])*p[1],i.data[b]=(e.data[S++]-f[2])*p[2],i.data[v]=k===-1?255:(e.data[k++]-f[3])*p[3]}else throw new Error("Can not access image data");return i}}),Ir,Pd,Vd,Ud,Wd,qd,jm=P(()=>{qa(),Ir=(e,t)=>{if(e===void 0)throw new Error("Image buffer must be defined");if(t.height===void 0||t.width===void 0)throw new Error("Image height and width must be defined");if(t.tensorLayout==="NHWC")throw new Error("NHWC Tensor layout is not supported yet");let{height:r,width:i}=t,a=t.norm??{mean:255,bias:0},s,n;typeof a.mean=="number"?s=[a.mean,a.mean,a.mean,a.mean]:s=[a.mean[0],a.mean[1],a.mean[2],a.mean[3]??255],typeof a.bias=="number"?n=[a.bias,a.bias,a.bias,a.bias]:n=[a.bias[0],a.bias[1],a.bias[2],a.bias[3]??0];let u=t.format!==void 0?t.format:"RGBA",d=t.tensorFormat!==void 0&&t.tensorFormat!==void 0?t.tensorFormat:"RGB",p=r*i,f=d==="RGBA"?new Float32Array(p*4):new Float32Array(p*3),h=4,l=0,y=1,_=2,b=3,v=0,x=p,$=p*2,S=-1;u==="RGB"&&(h=3,l=0,y=1,_=2,b=-1),d==="RGBA"?S=p*3:d==="RBG"?(v=0,$=p,x=p*2):d==="BGR"&&($=0,x=p,v=p*2);for(let k=0;k<p;k++,l+=h,_+=h,y+=h,b+=h)f[v++]=(e[l]+n[0])/s[0],f[x++]=(e[y]+n[1])/s[1],f[$++]=(e[_]+n[2])/s[2],S!==-1&&b!==-1&&(f[S++]=(e[b]+n[3])/s[3]);return d==="RGBA"?new Ne("float32",f,[1,4,r,i]):new Ne("float32",f,[1,3,r,i])},Pd=async(e,t)=>{let r=typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement,i=typeof ImageData<"u"&&e instanceof ImageData,a=typeof ImageBitmap<"u"&&e instanceof ImageBitmap,s=typeof e=="string",n,u=t??{},d=()=>{if(typeof document<"u")return document.createElement("canvas");if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(1,1);throw new Error("Canvas is not supported")},p=f=>typeof HTMLCanvasElement<"u"&&f instanceof HTMLCanvasElement||f instanceof OffscreenCanvas?f.getContext("2d"):null;if(r){let f=d();f.width=e.width,f.height=e.height;let h=p(f);if(h!=null){let l=e.height,y=e.width;if(t!==void 0&&t.resizedHeight!==void 0&&t.resizedWidth!==void 0&&(l=t.resizedHeight,y=t.resizedWidth),t!==void 0){if(u=t,t.tensorFormat!==void 0)throw new Error("Image input config format must be RGBA for HTMLImageElement");u.tensorFormat="RGBA",u.height=l,u.width=y}else u.tensorFormat="RGBA",u.height=l,u.width=y;h.drawImage(e,0,0),n=h.getImageData(0,0,y,l).data}else throw new Error("Can not access image data")}else if(i){let f,h;if(t!==void 0&&t.resizedWidth!==void 0&&t.resizedHeight!==void 0?(f=t.resizedHeight,h=t.resizedWidth):(f=e.height,h=e.width),t!==void 0&&(u=t),u.format="RGBA",u.height=f,u.width=h,t!==void 0){let l=d();l.width=h,l.height=f;let y=p(l);if(y!=null)y.putImageData(e,0,0),n=y.getImageData(0,0,h,f).data;else throw new Error("Can not access image data")}else n=e.data}else if(a){if(t===void 0)throw new Error("Please provide image config with format for Imagebitmap");let f=d();f.width=e.width,f.height=e.height;let h=p(f);if(h!=null){let l=e.height,y=e.width;return h.drawImage(e,0,0,y,l),n=h.getImageData(0,0,y,l).data,u.height=l,u.width=y,Ir(n,u)}else throw new Error("Can not access image data")}else{if(s)return new Promise((f,h)=>{let l=d(),y=p(l);if(!e||!y)return h();let _=new Image;_.crossOrigin="Anonymous",_.src=e,_.onload=()=>{l.width=_.width,l.height=_.height,y.drawImage(_,0,0,l.width,l.height);let b=y.getImageData(0,0,l.width,l.height);u.height=l.height,u.width=l.width,f(Ir(b.data,u))}});throw new Error("Input data provided is not supported - aborted tensor creation")}if(n!==void 0)return Ir(n,u);throw new Error("Input data provided is not supported - aborted tensor creation")},Vd=(e,t)=>{let{width:r,height:i,download:a,dispose:s}=t,n=[1,i,r,4];return new Ne({location:"texture",type:"float32",texture:e,dims:n,download:a,dispose:s})},Ud=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:s}=t;return new Ne({location:"gpu-buffer",type:r??"float32",gpuBuffer:e,dims:i,download:a,dispose:s})},Wd=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:s}=t;return new Ne({location:"ml-tensor",type:r??"float32",mlTensor:e,dims:i,download:a,dispose:s})},qd=(e,t,r)=>new Ne({location:"cpu-pinned",type:e,data:t,dims:r??[t.length]})}),Et,nr,Ei,Ld,Km=P(()=>{Et=new Map([["float32",Float32Array],["uint8",Uint8Array],["int8",Int8Array],["uint16",Uint16Array],["int16",Int16Array],["int32",Int32Array],["bool",Uint8Array],["float64",Float64Array],["uint32",Uint32Array],["int4",Uint8Array],["uint4",Uint8Array]]),nr=new Map([[Float32Array,"float32"],[Uint8Array,"uint8"],[Int8Array,"int8"],[Uint16Array,"uint16"],[Int16Array,"int16"],[Int32Array,"int32"],[Float64Array,"float64"],[Uint32Array,"uint32"]]),Ei=!1,Ld=()=>{if(!Ei){Ei=!0;let e=typeof BigInt64Array<"u"&&BigInt64Array.from,t=typeof BigUint64Array<"u"&&BigUint64Array.from,r=typeof Float16Array<"u"&&Float16Array.from;e&&(Et.set("int64",BigInt64Array),nr.set(BigInt64Array,"int64")),t&&(Et.set("uint64",BigUint64Array),nr.set(BigUint64Array,"uint64")),r?(Et.set("float16",Float16Array),nr.set(Float16Array,"float16")):Et.set("float16",Uint16Array)}}}),Fd,Gd,Zm=P(()=>{qa(),Fd=e=>{let t=1;for(let r=0;r<e.length;r++){let i=e[r];if(typeof i!="number"||!Number.isSafeInteger(i))throw new TypeError(`dims[${r}] must be an integer, got: ${i}`);if(i<0)throw new RangeError(`dims[${r}] must be a non-negative integer, got: ${i}`);t*=i}return t},Gd=(e,t)=>{switch(e.location){case"cpu":return new Ne(e.type,e.data,t);case"cpu-pinned":return new Ne({location:"cpu-pinned",data:e.data,type:e.type,dims:t});case"texture":return new Ne({location:"texture",texture:e.texture,type:e.type,dims:t});case"gpu-buffer":return new Ne({location:"gpu-buffer",gpuBuffer:e.gpuBuffer,type:e.type,dims:t});case"ml-tensor":return new Ne({location:"ml-tensor",mlTensor:e.mlTensor,type:e.type,dims:t});default:throw new Error(`tensorReshape: tensor location ${e.location} is not supported`)}}}),Ne,qa=P(()=>{Hm(),jm(),Km(),Zm(),Ne=class{constructor(e,t,r){Ld();let i,a;if(typeof e=="object"&&"location"in e)switch(this.dataLocation=e.location,i=e.type,a=e.dims,e.location){case"cpu-pinned":{let n=Et.get(i);if(!n)throw new TypeError(`unsupported type "${i}" to create tensor from pinned buffer`);if(!(e.data instanceof n))throw new TypeError(`buffer should be of type ${n.name}`);this.cpuData=e.data;break}case"texture":{if(i!=="float32")throw new TypeError(`unsupported type "${i}" to create tensor from texture`);this.gpuTextureData=e.texture,this.downloader=e.download,this.disposer=e.dispose;break}case"gpu-buffer":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from gpu buffer`);this.gpuBufferData=e.gpuBuffer,this.downloader=e.download,this.disposer=e.dispose;break}case"ml-tensor":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint64"&&i!=="int8"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from MLTensor`);this.mlTensorData=e.mlTensor,this.downloader=e.download,this.disposer=e.dispose;break}default:throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`)}else{let n,u;if(typeof e=="string")if(i=e,u=r,e==="string"){if(!Array.isArray(t))throw new TypeError("A string tensor's data must be a string array.");n=t}else{let d=Et.get(e);if(d===void 0)throw new TypeError(`Unsupported tensor type: ${e}.`);if(Array.isArray(t)){if(e==="float16"&&d===Uint16Array||e==="uint4"||e==="int4")throw new TypeError(`Creating a ${e} tensor from number array is not supported. Please use ${d.name} as data.`);e==="uint64"||e==="int64"?n=d.from(t,BigInt):n=d.from(t)}else if(t instanceof d)n=t;else if(t instanceof Uint8ClampedArray)if(e==="uint8")n=Uint8Array.from(t);else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");else throw new TypeError(`A ${i} tensor's data must be type of ${d}`)}else if(u=t,Array.isArray(e)){if(e.length===0)throw new TypeError("Tensor type cannot be inferred from an empty array.");let d=typeof e[0];if(d==="string")i="string",n=e;else if(d==="boolean")i="bool",n=Uint8Array.from(e);else throw new TypeError(`Invalid element type of data array: ${d}.`)}else if(e instanceof Uint8ClampedArray)i="uint8",n=Uint8Array.from(e);else{let d=nr.get(e.constructor);if(d===void 0)throw new TypeError(`Unsupported type for tensor data: ${e.constructor}.`);i=d,n=e}if(u===void 0)u=[n.length];else if(!Array.isArray(u))throw new TypeError("A tensor's dims must be a number array");a=u,this.cpuData=n,this.dataLocation="cpu"}let s=Fd(a);if(this.cpuData&&s!==this.cpuData.length&&!((i==="uint4"||i==="int4")&&Math.ceil(s/2)===this.cpuData.length))throw new Error(`Tensor's size(${s}) does not match data length(${this.cpuData.length}).`);this.type=i,this.dims=a,this.size=s}static async fromImage(e,t){return Pd(e,t)}static fromTexture(e,t){return Vd(e,t)}static fromGpuBuffer(e,t){return Ud(e,t)}static fromMLTensor(e,t){return Wd(e,t)}static fromPinnedBuffer(e,t,r){return qd(e,t,r)}toDataURL(e){return Nd(this,e)}toImageData(e){return Md(this,e)}get data(){if(this.ensureValid(),!this.cpuData)throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");return this.cpuData}get location(){return this.dataLocation}get texture(){if(this.ensureValid(),!this.gpuTextureData)throw new Error("The data is not stored as a WebGL texture.");return this.gpuTextureData}get gpuBuffer(){if(this.ensureValid(),!this.gpuBufferData)throw new Error("The data is not stored as a WebGPU buffer.");return this.gpuBufferData}get mlTensor(){if(this.ensureValid(),!this.mlTensorData)throw new Error("The data is not stored as a WebNN MLTensor.");return this.mlTensorData}async getData(e){switch(this.ensureValid(),this.dataLocation){case"cpu":case"cpu-pinned":return this.data;case"texture":case"gpu-buffer":case"ml-tensor":{if(!this.downloader)throw new Error("The current tensor is not created with a specified data downloader.");if(this.isDownloading)throw new Error("The current tensor is being downloaded.");try{this.isDownloading=!0;let t=await this.downloader();return this.downloader=void 0,this.dataLocation="cpu",this.cpuData=t,e&&this.disposer&&(this.disposer(),this.disposer=void 0),t}finally{this.isDownloading=!1}}default:throw new Error(`cannot get data from location: ${this.dataLocation}`)}}dispose(){if(this.isDownloading)throw new Error("The current tensor is being downloaded.");this.disposer&&(this.disposer(),this.disposer=void 0),this.cpuData=void 0,this.gpuTextureData=void 0,this.gpuBufferData=void 0,this.mlTensorData=void 0,this.downloader=void 0,this.isDownloading=void 0,this.dataLocation="none"}ensureValid(){if(this.dataLocation==="none")throw new Error("The tensor is disposed.")}reshape(e){if(this.ensureValid(),this.downloader||this.disposer)throw new Error("Cannot reshape a tensor that owns GPU resource.");return Gd(this,e)}}}),He,Hd=P(()=>{qa(),He=Ne}),Gr,Ii,tt,je,jd=P(()=>{Bd(),Gr=(e,t)=>{(typeof Ue.trace>"u"?!Ue.wasm.trace:!Ue.trace)||console.timeStamp(`${e}::ORT::${t}`)},Ii=(e,t)=>{var a;let r=((a=new Error().stack)==null?void 0:a.split(/\r\n|\r|\n/g))||[],i=!1;for(let s=0;s<r.length;s++){if(i&&!r[s].includes("TRACE_FUNC")){let n=`FUNC_${e}::${r[s].trim().split(" ")[1]}`;t&&(n+=`::${t}`),Gr("CPU",n);return}r[s].includes("TRACE_FUNC")&&(i=!0)}},tt=e=>{(typeof Ue.trace>"u"?!Ue.wasm.trace:!Ue.trace)||Ii("BEGIN",e)},je=e=>{(typeof Ue.trace>"u"?!Ue.wasm.trace:!Ue.trace)||Ii("END",e)}}),Kd,Ym=P(()=>{Dd(),Hd(),jd(),Kd=class Zd{constructor(t){this.handler=t}async run(t,r,i){tt();let a={},s={};if(typeof t!="object"||t===null||t instanceof He||Array.isArray(t))throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let n=!0;if(typeof r=="object"){if(r===null)throw new TypeError("Unexpected argument[1]: cannot be null.");if(r instanceof He)throw new TypeError("'fetches' cannot be a Tensor");if(Array.isArray(r)){if(r.length===0)throw new TypeError("'fetches' cannot be an empty array.");n=!1;for(let p of r){if(typeof p!="string")throw new TypeError("'fetches' must be a string array or an object.");if(this.outputNames.indexOf(p)===-1)throw new RangeError(`'fetches' contains invalid output name: ${p}.`);a[p]=null}if(typeof i=="object"&&i!==null)s=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else{let p=!1,f=Object.getOwnPropertyNames(r);for(let h of this.outputNames)if(f.indexOf(h)!==-1){let l=r[h];(l===null||l instanceof He)&&(p=!0,n=!1,a[h]=l)}if(p){if(typeof i=="object"&&i!==null)s=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else s=r}}else if(typeof r<"u")throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let p of this.inputNames)if(typeof t[p]>"u")throw new Error(`input '${p}' is missing in 'feeds'.`);if(n)for(let p of this.outputNames)a[p]=null;let u=await this.handler.run(t,a,s),d={};for(let p in u)if(Object.hasOwnProperty.call(u,p)){let f=u[p];f instanceof He?d[p]=f:d[p]=new He(f.type,f.data,f.dims)}return je(),d}async release(){return this.handler.dispose()}static async create(t,r,i,a){tt();let s,n={};if(typeof t=="string"){if(s=t,typeof r=="object"&&r!==null)n=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof Uint8Array){if(s=t,typeof r=="object"&&r!==null)n=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof ArrayBuffer||typeof SharedArrayBuffer<"u"&&t instanceof SharedArrayBuffer){let f=t,h=0,l=t.byteLength;if(typeof r=="object"&&r!==null)n=r;else if(typeof r=="number"){if(h=r,!Number.isSafeInteger(h))throw new RangeError("'byteOffset' must be an integer.");if(h<0||h>=f.byteLength)throw new RangeError(`'byteOffset' is out of range [0, ${f.byteLength}).`);if(l=t.byteLength-h,typeof i=="number"){if(l=i,!Number.isSafeInteger(l))throw new RangeError("'byteLength' must be an integer.");if(l<=0||h+l>f.byteLength)throw new RangeError(`'byteLength' is out of range (0, ${f.byteLength-h}].`);if(typeof a=="object"&&a!==null)n=a;else if(typeof a<"u")throw new TypeError("'options' must be an object.")}else if(typeof i<"u")throw new TypeError("'byteLength' must be a number.")}else if(typeof r<"u")throw new TypeError("'options' must be an object.");s=new Uint8Array(f,h,l)}else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");let[u,d]=await Od(n),p=await u.createInferenceSessionHandler(s,d);return je(),new Zd(p)}startProfiling(){this.handler.startProfiling()}endProfiling(){this.handler.endProfiling()}get inputNames(){return this.handler.inputNames}get outputNames(){return this.handler.outputNames}}}),La,Qm=P(()=>{Ym(),La=Kd}),Jm=P(()=>{}),Xm=P(()=>{}),eg=P(()=>{}),tg=P(()=>{}),rg={};fr(rg,{InferenceSession:()=>La,TRACE:()=>Gr,TRACE_FUNC_BEGIN:()=>tt,TRACE_FUNC_END:()=>je,Tensor:()=>He,env:()=>ge,registerBackend:()=>Vt});var Ke=P(()=>{Lm(),Gm(),Qm(),Hd(),Jm(),Xm(),jd(),eg(),tg()}),Fa=P(()=>{}),Yd={};fr(Yd,{default:()=>Qd});var zi,Ai,Qd,ig=P(()=>{var e;ef(),Dt(),Ga(),zi="ort-wasm-proxy-worker",Ai=((e=globalThis.self)==null?void 0:e.name)===zi,Ai&&(self.onmessage=t=>{let{type:r,in:i}=t.data;try{switch(r){case"init-wasm":Ha(i.wasm).then(()=>{pn(i).then(()=>{postMessage({type:r})},a=>{postMessage({type:r,err:a})})},a=>{postMessage({type:r,err:a})});break;case"init-ep":{let{epName:a,env:s}=i;cn(s,a).then(()=>{postMessage({type:r})},n=>{postMessage({type:r,err:n})});break}case"copy-from":{let{buffer:a}=i,s=Qr(a);postMessage({type:r,out:s});break}case"create":{let{model:a,options:s}=i;hn(a,s).then(n=>{postMessage({type:r,out:n})},n=>{postMessage({type:r,err:n})});break}case"release":fn(i),postMessage({type:r});break;case"run":{let{sessionId:a,inputIndices:s,inputs:n,outputIndices:u,options:d}=i;mn(a,s,n,u,new Array(u.length).fill(null),d).then(p=>{p.some(f=>f[3]!=="cpu")?postMessage({type:r,err:"Proxy does not support non-cpu tensor location."}):postMessage({type:r,out:p},yn([...n,...p]))},p=>{postMessage({type:r,err:p})});break}case"end-profiling":gn(i),postMessage({type:r});break;default:}}catch(a){postMessage({type:r,err:a})}}),Qd=Ai?null:t=>new Worker(t??Be,{type:"module",name:zi})}),Jd={};fr(Jd,{default:()=>Xd});var Oi,Di,Xd,ag=P(()=>{var e;Di=(Oi=import.meta.url,async function(t={}){function r(){return G.buffer!=Z.buffer&&me(),Z}function i(){return G.buffer!=Z.buffer&&me(),ue}function a(){return G.buffer!=Z.buffer&&me(),N}function s(){return G.buffer!=Z.buffer&&me(),q}function n(){return G.buffer!=Z.buffer&&me(),se}function u(){return G.buffer!=Z.buffer&&me(),we}function d(){return G.buffer!=Z.buffer&&me(),Ae}function p(){return G.buffer!=Z.buffer&&me(),wt}var f,h,l=Object.assign({},t),y=new Promise((o,c)=>{f=o,h=c}),_=typeof window=="object",b=typeof importScripts=="function",v=b&&self.name=="em-pthread";l.mountExternalData=(o,c)=>{o.startsWith("./")&&(o=o.substring(2)),(l.Fb||(l.Fb=new Map)).set(o,c)},l.unmountExternalData=()=>{delete l.Fb};var x=globalThis.SharedArrayBuffer??new WebAssembly.Memory({initial:0,maximum:0,shared:!0}).buffer.constructor;let $=()=>{let o=(m,g,w)=>(...C)=>{let O=Je,B=g==null?void 0:g();C=m(...C);let V=g==null?void 0:g();return B!==V&&(m=V,w(B),g=w=null),Je!=O?new Promise((L,Q)=>{bi={resolve:L,reject:Q}}):C},c=m=>async(...g)=>{var w;try{if(l.Gb)throw Error("Session already started");let C=l.Gb={hc:g[0],errors:[]},O=await m(...g);if(l.Gb!==C)throw Error("Session mismatch");(w=l.Hb)==null||w.flush();let B=C.errors;if(0<B.length){let V=await Promise.all(B);if(V=V.filter(L=>L),0<V.length)throw Error(V.join(`
`))}return O}finally{l.Gb=null}};l._OrtCreateSession=o(l._OrtCreateSession,()=>l._OrtCreateSession,m=>l._OrtCreateSession=m),l._OrtRun=c(o(l._OrtRun,()=>l._OrtRun,m=>l._OrtRun=m)),l._OrtRunWithBinding=c(o(l._OrtRunWithBinding,()=>l._OrtRunWithBinding,m=>l._OrtRunWithBinding=m)),l._OrtBindInput=o(l._OrtBindInput,()=>l._OrtBindInput,m=>l._OrtBindInput=m),$=void 0};l.jsepInit=(o,c)=>{if($==null||$(),o==="webgpu"){[l.Hb,l.Vb,l.Zb,l.Ob,l.Yb,l.kb,l.$b,l.cc,l.Wb,l.Xb,l.ac]=c;let m=l.Hb;l.jsepRegisterBuffer=(g,w,C,O)=>m.registerBuffer(g,w,C,O),l.jsepGetBuffer=g=>m.getBuffer(g),l.jsepCreateDownloader=(g,w,C)=>m.createDownloader(g,w,C),l.jsepOnCreateSession=g=>{m.onCreateSession(g)},l.jsepOnReleaseSession=g=>{m.onReleaseSession(g)},l.jsepOnRunStart=g=>m.onRunStart(g),l.dc=(g,w)=>{m.upload(g,w)}}else if(o==="webnn"){[l.Hb,l.bc,l.Pb,l.jsepEnsureTensor,l.ec,l.jsepDownloadTensor]=c,l.jsepReleaseTensorId=l.Pb;let m=l.Hb;l.jsepOnRunStart=g=>m.onRunStart(g),l.jsepRegisterMLContext=(g,w)=>{m.registerMLContext(g,w)},l.jsepOnReleaseSession=g=>{m.onReleaseSession(g)},l.jsepCreateMLTensorDownloader=(g,w)=>m.createMLTensorDownloader(g,w),l.jsepRegisterMLTensor=(g,w,C)=>m.registerMLTensor(g,w,C),l.jsepCreateMLContext=g=>m.createMLContext(g),l.jsepRegisterMLConstant=(g,w,C,O,B)=>m.registerMLConstant(g,w,C,O,B,l.Fb)}};var S,k,T=Object.assign({},l),E="./this.program",I=(o,c)=>{throw c},D="";(_||b)&&(b?D=self.location.href:typeof document<"u"&&document.currentScript&&(D=document.currentScript.src),Oi&&(D=Oi),D=D.startsWith("blob:")?"":D.substr(0,D.replace(/[?#].*/,"").lastIndexOf("/")+1),b&&(k=o=>{var c=new XMLHttpRequest;return c.open("GET",o,!1),c.responseType="arraybuffer",c.send(null),new Uint8Array(c.response)}),S=(o,c,m)=>{var g=new XMLHttpRequest;g.open("GET",o,!0),g.responseType="arraybuffer",g.onload=()=>{g.status==200||g.status==0&&g.response?c(g.response):m()},g.onerror=m,g.send(null)});var M,W=console.log.bind(console),ee=console.error.bind(console),te=W,U=ee;if(Object.assign(l,T),T=null,v){let o=function(c){try{var m=c.data,g=m.cmd;if(g==="load"){let w=[];self.onmessage=C=>w.push(C),self.startWorker=()=>{postMessage({cmd:"loaded"});for(let C of w)o(C);self.onmessage=o};for(let C of m.handlers)l[C]&&!l[C].proxy||(l[C]=(...O)=>{postMessage({Nb:"callHandler",pc:C,args:O})},C=="print"&&(te=l[C]),C=="printErr"&&(U=l[C]));G=m.wasmMemory,me(),ae(m.wasmModule)}else if(g==="run"){xi(m.pthread_ptr,0,0,1,0,0),yi(m.pthread_ptr),vf(),Ln(),F||(Us(),F=!0);try{xf(m.start_routine,m.arg)}catch(w){if(w!="unwind")throw w}}else g==="cancel"?Mt()&&Cr(-1):m.target!=="setimmediate"&&(g==="checkMailbox"?F&&yr():g&&(U(`worker: received unknown command ${g}`),U(m)))}catch(w){throw Ws(),w}};var ae,F=!1;U=function(...c){c=c.join(" "),console.error(c)},self.alert=function(...c){postMessage({Nb:"alert",text:c.join(" "),rc:Mt()})},l.instantiateWasm=(c,m)=>new Promise(g=>{ae=w=>{w=new WebAssembly.Instance(w,Pn()),m(w),g()}}),self.onunhandledrejection=c=>{throw c.reason||c},self.onmessage=o}l.wasmBinary&&(M=l.wasmBinary);var G,de,J,Z,ue,N,q,se,we,Ae,ke,Ze,wt,ye=!1;function me(){var o=G.buffer;l.HEAP8=Z=new Int8Array(o),l.HEAP16=N=new Int16Array(o),l.HEAPU8=ue=new Uint8Array(o),l.HEAPU16=q=new Uint16Array(o),l.HEAP32=se=new Int32Array(o),l.HEAPU32=we=new Uint32Array(o),l.HEAPF32=Ae=new Float32Array(o),l.HEAPF64=wt=new Float64Array(o),l.HEAP64=ke=new BigInt64Array(o),l.HEAPU64=Ze=new BigUint64Array(o)}if(!v){if(!((G=new WebAssembly.Memory({initial:256,maximum:65536,shared:!0})).buffer instanceof x))throw U("requested a shared WebAssembly.Memory but the returned buffer is not a SharedArrayBuffer, indicating that while the browser has SharedArrayBuffer it does not have WebAssembly threads support - you may need to set a flag"),Error("bad memory");me()}var ut=[],Ht=[],ai=[],jt=0,Kt=null;function Dn(){if(--jt==0&&Kt){var o=Kt;Kt=null,o()}}function lt(o){throw U(o="Aborted("+o+")"),ye=!0,J=1,o=new WebAssembly.RuntimeError(o+". Build with -sASSERTIONS for more info."),h(o),o}var ni,Rn=o=>o.startsWith("data:application/octet-stream;base64,"),Bn=o=>o.startsWith("file://");function Nn(o){if(o==ni&&M)return new Uint8Array(M);if(k)return k(o);throw"both async and sync fetching of the wasm failed"}function Mn(o,c,m){return function(g){if(!M&&(_||b)){if(typeof fetch=="function"&&!Bn(g))return fetch(g,{credentials:"same-origin"}).then(w=>{if(!w.ok)throw`failed to load wasm binary file at '${g}'`;return w.arrayBuffer()}).catch(()=>Nn(g));if(S)return new Promise((w,C)=>{S(g,O=>w(new Uint8Array(O)),C)})}return Promise.resolve().then(()=>Nn(g))}(o).then(g=>WebAssembly.instantiate(g,c)).then(m,g=>{U(`failed to asynchronously prepare wasm: ${g}`),lt(g)})}function Pn(){return{a:{O:$f,Aa:wf,b:Sf,aa:jn,B:Yn,qa:Qn,Y:Xn,_:es,ra:ts,oa:rs,ha:is,na:as,L:ns,Z:ss,W:os,pa:us,X:ls,va:Tf,F:Cf,Q:Ef,P:zf,E:Of,u:Df,q:Rf,G:Bf,A:qf,R:Lf,ua:Ff,ka:Gf,U:Hf,ba:jf,H:Kf,ja:yi,ta:Zf,t:Yf,Ba:Qf,x:em,n:tm,l:im,c:mi,o:am,j:om,w:um,p:lm,f:dm,s:pm,m:cm,e:hm,k:fm,i:mm,h:gm,d:ym,ea:_m,fa:bm,ga:wm,ca:xs,da:ks,T:$m,g:vm,D:xm,I:km,M:Sm,y:Tm,sa:Cm,V:Em,v:Ts,z:Im,N:zm,S:Am,za:Om,ya:Dm,la:Is,ma:zs,$:di,C:As,K:Os,ia:Ds,J:Rs,a:G,xa:li,wa:Ms,r:Nm}}}var si={913700:(o,c,m,g,w)=>{if(l===void 0||!l.Fb)return 1;if((o=xe(Number(o>>>0))).startsWith("./")&&(o=o.substring(2)),!(o=l.Fb.get(o)))return 2;if(c=Number(c>>>0),m=Number(m>>>0),g=Number(g>>>0),c+m>o.byteLength)return 3;try{let C=o.subarray(c,c+m);switch(w){case 0:i().set(C,g>>>0);break;case 1:l.dc(g,C);break;default:return 4}return 0}catch{return 4}},914415:(o,c,m)=>{l.ec(o,i().subarray(c>>>0,c+m>>>0))},914478:()=>l.bc(),914519:o=>{l.Pb(o)},914555:()=>{l.Wb()},914586:()=>{l.Xb()},914615:()=>{l.ac()},914640:o=>l.Vb(o),914673:o=>l.Zb(o),914705:(o,c,m)=>{l.Ob(Number(o),Number(c),Number(m),!0)},914768:(o,c,m)=>{l.Ob(Number(o),Number(c),Number(m))},914825:()=>typeof wasmOffsetConverter<"u",914882:o=>{l.kb("Abs",o,void 0)},914933:o=>{l.kb("Neg",o,void 0)},914984:o=>{l.kb("Floor",o,void 0)},915037:o=>{l.kb("Ceil",o,void 0)},915089:o=>{l.kb("Reciprocal",o,void 0)},915147:o=>{l.kb("Sqrt",o,void 0)},915199:o=>{l.kb("Exp",o,void 0)},915250:o=>{l.kb("Erf",o,void 0)},915301:o=>{l.kb("Sigmoid",o,void 0)},915356:(o,c,m)=>{l.kb("HardSigmoid",o,{alpha:c,beta:m})},915435:o=>{l.kb("Log",o,void 0)},915486:o=>{l.kb("Sin",o,void 0)},915537:o=>{l.kb("Cos",o,void 0)},915588:o=>{l.kb("Tan",o,void 0)},915639:o=>{l.kb("Asin",o,void 0)},915691:o=>{l.kb("Acos",o,void 0)},915743:o=>{l.kb("Atan",o,void 0)},915795:o=>{l.kb("Sinh",o,void 0)},915847:o=>{l.kb("Cosh",o,void 0)},915899:o=>{l.kb("Asinh",o,void 0)},915952:o=>{l.kb("Acosh",o,void 0)},916005:o=>{l.kb("Atanh",o,void 0)},916058:o=>{l.kb("Tanh",o,void 0)},916110:o=>{l.kb("Not",o,void 0)},916161:(o,c,m)=>{l.kb("Clip",o,{min:c,max:m})},916230:o=>{l.kb("Clip",o,void 0)},916282:(o,c)=>{l.kb("Elu",o,{alpha:c})},916340:o=>{l.kb("Gelu",o,void 0)},916392:o=>{l.kb("Relu",o,void 0)},916444:(o,c)=>{l.kb("LeakyRelu",o,{alpha:c})},916508:(o,c)=>{l.kb("ThresholdedRelu",o,{alpha:c})},916578:(o,c)=>{l.kb("Cast",o,{to:c})},916636:o=>{l.kb("Add",o,void 0)},916687:o=>{l.kb("Sub",o,void 0)},916738:o=>{l.kb("Mul",o,void 0)},916789:o=>{l.kb("Div",o,void 0)},916840:o=>{l.kb("Pow",o,void 0)},916891:o=>{l.kb("Equal",o,void 0)},916944:o=>{l.kb("Greater",o,void 0)},916999:o=>{l.kb("GreaterOrEqual",o,void 0)},917061:o=>{l.kb("Less",o,void 0)},917113:o=>{l.kb("LessOrEqual",o,void 0)},917172:(o,c,m,g,w)=>{l.kb("ReduceMean",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},917347:(o,c,m,g,w)=>{l.kb("ReduceMax",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},917521:(o,c,m,g,w)=>{l.kb("ReduceMin",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},917695:(o,c,m,g,w)=>{l.kb("ReduceProd",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},917870:(o,c,m,g,w)=>{l.kb("ReduceSum",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},918044:(o,c,m,g,w)=>{l.kb("ReduceL1",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},918217:(o,c,m,g,w)=>{l.kb("ReduceL2",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},918390:(o,c,m,g,w)=>{l.kb("ReduceLogSum",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},918567:(o,c,m,g,w)=>{l.kb("ReduceSumSquare",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},918747:(o,c,m,g,w)=>{l.kb("ReduceLogSumExp",o,{keepDims:!!c,noopWithEmptyAxes:!!m,axes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},918927:o=>{l.kb("Where",o,void 0)},918980:(o,c,m)=>{l.kb("Transpose",o,{perm:c?Array.from(n().subarray(Number(c)>>>0,Number(m)>>>0)):[]})},919104:(o,c,m,g)=>{l.kb("DepthToSpace",o,{blocksize:c,mode:xe(m),format:g?"NHWC":"NCHW"})},919237:(o,c,m,g)=>{l.kb("DepthToSpace",o,{blocksize:c,mode:xe(m),format:g?"NHWC":"NCHW"})},919370:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A,ne)=>{l.kb("ConvTranspose",o,{format:V?"NHWC":"NCHW",autoPad:c,dilations:[m],group:g,kernelShape:[w],pads:[C,O],strides:[B],wIsConst:()=>!!r()[L>>>0],outputPadding:Q?Array.from(n().subarray(Number(Q)>>>0,Number(oe)>>>0)):[],outputShape:ce?Array.from(n().subarray(Number(ce)>>>0,Number(A)>>>0)):[],activation:xe(ne)})},919803:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A)=>{l.kb("ConvTranspose",o,{format:B?"NHWC":"NCHW",autoPad:c,dilations:Array.from(n().subarray(Number(m)>>>0,2+(Number(m)>>>0)>>>0)),group:g,kernelShape:Array.from(n().subarray(Number(w)>>>0,2+(Number(w)>>>0)>>>0)),pads:Array.from(n().subarray(Number(C)>>>0,4+(Number(C)>>>0)>>>0)),strides:Array.from(n().subarray(Number(O)>>>0,2+(Number(O)>>>0)>>>0)),wIsConst:()=>!!r()[V>>>0],outputPadding:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],outputShape:oe?Array.from(n().subarray(Number(oe)>>>0,Number(ce)>>>0)):[],activation:xe(A)})},920464:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A,ne)=>{l.kb("ConvTranspose",o,{format:V?"NHWC":"NCHW",autoPad:c,dilations:[m],group:g,kernelShape:[w],pads:[C,O],strides:[B],wIsConst:()=>!!r()[L>>>0],outputPadding:Q?Array.from(n().subarray(Number(Q)>>>0,Number(oe)>>>0)):[],outputShape:ce?Array.from(n().subarray(Number(ce)>>>0,Number(A)>>>0)):[],activation:xe(ne)})},920897:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A)=>{l.kb("ConvTranspose",o,{format:B?"NHWC":"NCHW",autoPad:c,dilations:Array.from(n().subarray(Number(m)>>>0,2+(Number(m)>>>0)>>>0)),group:g,kernelShape:Array.from(n().subarray(Number(w)>>>0,2+(Number(w)>>>0)>>>0)),pads:Array.from(n().subarray(Number(C)>>>0,4+(Number(C)>>>0)>>>0)),strides:Array.from(n().subarray(Number(O)>>>0,2+(Number(O)>>>0)>>>0)),wIsConst:()=>!!r()[V>>>0],outputPadding:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],outputShape:oe?Array.from(n().subarray(Number(oe)>>>0,Number(ce)>>>0)):[],activation:xe(A)})},921558:(o,c)=>{l.kb("GlobalAveragePool",o,{format:c?"NHWC":"NCHW"})},921649:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A)=>{l.kb("AveragePool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:m,count_include_pad:g,storage_order:w,dilations:C?Array.from(n().subarray(Number(C)>>>0,Number(O)>>>0)):[],kernel_shape:B?Array.from(n().subarray(Number(B)>>>0,Number(V)>>>0)):[],pads:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],strides:oe?Array.from(n().subarray(Number(oe)>>>0,Number(ce)>>>0)):[]})},922128:(o,c)=>{l.kb("GlobalAveragePool",o,{format:c?"NHWC":"NCHW"})},922219:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A)=>{l.kb("AveragePool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:m,count_include_pad:g,storage_order:w,dilations:C?Array.from(n().subarray(Number(C)>>>0,Number(O)>>>0)):[],kernel_shape:B?Array.from(n().subarray(Number(B)>>>0,Number(V)>>>0)):[],pads:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],strides:oe?Array.from(n().subarray(Number(oe)>>>0,Number(ce)>>>0)):[]})},922698:(o,c)=>{l.kb("GlobalMaxPool",o,{format:c?"NHWC":"NCHW"})},922785:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A)=>{l.kb("MaxPool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:m,count_include_pad:g,storage_order:w,dilations:C?Array.from(n().subarray(Number(C)>>>0,Number(O)>>>0)):[],kernel_shape:B?Array.from(n().subarray(Number(B)>>>0,Number(V)>>>0)):[],pads:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],strides:oe?Array.from(n().subarray(Number(oe)>>>0,Number(ce)>>>0)):[]})},923260:(o,c)=>{l.kb("GlobalMaxPool",o,{format:c?"NHWC":"NCHW"})},923347:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A)=>{l.kb("MaxPool",o,{format:A?"NHWC":"NCHW",auto_pad:c,ceil_mode:m,count_include_pad:g,storage_order:w,dilations:C?Array.from(n().subarray(Number(C)>>>0,Number(O)>>>0)):[],kernel_shape:B?Array.from(n().subarray(Number(B)>>>0,Number(V)>>>0)):[],pads:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],strides:oe?Array.from(n().subarray(Number(oe)>>>0,Number(ce)>>>0)):[]})},923822:(o,c,m,g,w)=>{l.kb("Gemm",o,{alpha:c,beta:m,transA:g,transB:w})},923926:o=>{l.kb("MatMul",o,void 0)},923980:(o,c,m,g)=>{l.kb("ArgMax",o,{keepDims:!!c,selectLastIndex:!!m,axis:g})},924088:(o,c,m,g)=>{l.kb("ArgMin",o,{keepDims:!!c,selectLastIndex:!!m,axis:g})},924196:(o,c)=>{l.kb("Softmax",o,{axis:c})},924259:(o,c)=>{l.kb("Concat",o,{axis:c})},924319:(o,c,m,g,w)=>{l.kb("Split",o,{axis:c,numOutputs:m,splitSizes:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},924475:o=>{l.kb("Expand",o,void 0)},924529:(o,c)=>{l.kb("Gather",o,{axis:Number(c)})},924600:(o,c)=>{l.kb("GatherElements",o,{axis:Number(c)})},924679:(o,c)=>{l.kb("GatherND",o,{batch_dims:Number(c)})},924758:(o,c,m,g,w,C,O,B,V,L,Q)=>{l.kb("Resize",o,{antialias:c,axes:m?Array.from(n().subarray(Number(m)>>>0,Number(g)>>>0)):[],coordinateTransformMode:xe(w),cubicCoeffA:C,excludeOutside:O,extrapolationValue:B,keepAspectRatioPolicy:xe(V),mode:xe(L),nearestMode:xe(Q)})},925120:(o,c,m,g,w,C,O)=>{l.kb("Slice",o,{starts:c?Array.from(n().subarray(Number(c)>>>0,Number(m)>>>0)):[],ends:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[],axes:C?Array.from(n().subarray(Number(C)>>>0,Number(O)>>>0)):[]})},925384:o=>{l.kb("Tile",o,void 0)},925436:(o,c,m)=>{l.kb("InstanceNormalization",o,{epsilon:c,format:m?"NHWC":"NCHW"})},925550:(o,c,m)=>{l.kb("InstanceNormalization",o,{epsilon:c,format:m?"NHWC":"NCHW"})},925664:o=>{l.kb("Range",o,void 0)},925717:(o,c)=>{l.kb("Einsum",o,{equation:xe(c)})},925798:(o,c,m,g,w)=>{l.kb("Pad",o,{mode:c,value:m,pads:g?Array.from(n().subarray(Number(g)>>>0,Number(w)>>>0)):[]})},925941:(o,c,m,g,w,C)=>{l.kb("BatchNormalization",o,{epsilon:c,momentum:m,spatial:!!w,trainingMode:!!g,format:C?"NHWC":"NCHW"})},926110:(o,c,m,g,w,C)=>{l.kb("BatchNormalization",o,{epsilon:c,momentum:m,spatial:!!w,trainingMode:!!g,format:C?"NHWC":"NCHW"})},926279:(o,c,m)=>{l.kb("CumSum",o,{exclusive:Number(c),reverse:Number(m)})},926376:(o,c,m)=>{l.kb("DequantizeLinear",o,{axis:c,blockSize:m})},926466:(o,c,m,g,w)=>{l.kb("GridSample",o,{align_corners:c,mode:xe(m),padding_mode:xe(g),format:w?"NHWC":"NCHW"})},926636:(o,c,m,g,w)=>{l.kb("GridSample",o,{align_corners:c,mode:xe(m),padding_mode:xe(g),format:w?"NHWC":"NCHW"})},926806:(o,c,m,g,w,C,O,B,V)=>{l.kb("Attention",o,{numHeads:c,isUnidirectional:m,maskFilterValue:g,scale:w,doRotary:C,qkvHiddenSizes:O?Array.from(n().subarray(Number(B)>>>0,Number(B)+O>>>0)):[],pastPresentShareBuffer:!!V})},927078:o=>{l.kb("BiasAdd",o,void 0)},927133:o=>{l.kb("BiasSplitGelu",o,void 0)},927194:o=>{l.kb("FastGelu",o,void 0)},927250:(o,c,m,g,w,C,O,B,V,L,Q,oe,ce,A,ne,$e)=>{l.kb("Conv",o,{format:oe?"NHWC":"NCHW",auto_pad:c,dilations:m?Array.from(n().subarray(Number(m)>>>0,Number(g)>>>0)):[],group:w,kernel_shape:C?Array.from(n().subarray(Number(C)>>>0,Number(O)>>>0)):[],pads:B?Array.from(n().subarray(Number(B)>>>0,Number(V)>>>0)):[],strides:L?Array.from(n().subarray(Number(L)>>>0,Number(Q)>>>0)):[],w_is_const:()=>!!r()[Number(ce)>>>0],activation:xe(A),activation_params:ne?Array.from(d().subarray(Number(ne)>>>0,Number($e)>>>0)):[]})},927834:o=>{l.kb("Gelu",o,void 0)},927886:(o,c,m,g,w,C,O,B,V)=>{l.kb("GroupQueryAttention",o,{numHeads:c,kvNumHeads:m,scale:g,softcap:w,doRotary:C,rotaryInterleaved:O,smoothSoftmax:B,localWindowSize:V})},928103:(o,c,m,g)=>{l.kb("LayerNormalization",o,{axis:c,epsilon:m,simplified:!!g})},928214:(o,c,m,g)=>{l.kb("LayerNormalization",o,{axis:c,epsilon:m,simplified:!!g})},928325:(o,c,m,g,w,C)=>{l.kb("MatMulNBits",o,{k:c,n:m,accuracyLevel:g,bits:w,blockSize:C})},928452:(o,c,m,g,w,C)=>{l.kb("MultiHeadAttention",o,{numHeads:c,isUnidirectional:m,maskFilterValue:g,scale:w,doRotary:C})},928611:(o,c)=>{l.kb("QuickGelu",o,{alpha:c})},928675:(o,c,m,g,w)=>{l.kb("RotaryEmbedding",o,{interleaved:!!c,numHeads:m,rotaryEmbeddingDim:g,scale:w})},928814:(o,c,m)=>{l.kb("SkipLayerNormalization",o,{epsilon:c,simplified:!!m})},928916:(o,c,m)=>{l.kb("SkipLayerNormalization",o,{epsilon:c,simplified:!!m})},929018:(o,c,m,g)=>{l.kb("GatherBlockQuantized",o,{gatherAxis:c,quantizeAxis:m,blockSize:g})},929139:o=>{l.$b(o)},929173:(o,c)=>l.cc(Number(o),Number(c),l.Gb.hc,l.Gb.errors)};function wf(o,c,m){return _s(async()=>{await l.Yb(Number(o),Number(c),Number(m))})}function $f(){return typeof wasmOffsetConverter<"u"}function oi(o){this.name="ExitStatus",this.message=`Program terminated with exit(${o})`,this.status=o}var ui=o=>{o.terminate(),o.onmessage=()=>{}},Vn=o=>{dt.length==0&&(Gn(),Fn(dt[0]));var c=dt.pop();if(!c)return 6;vt.push(c),Ye[o.Bb]=c,c.Bb=o.Bb;var m={cmd:"run",start_routine:o.ic,arg:o.Rb,pthread_ptr:o.Bb};return c.postMessage(m,o.nc),0},$t=0,_e=(o,c,...m)=>{for(var g=2*m.length,w=Ti(),C=Si(8*g),O=C>>>3,B=0;B<m.length;B++){var V=m[B];typeof V=="bigint"?(ke[O+2*B]=1n,ke[O+2*B+1]=V):(ke[O+2*B]=0n,p()[O+2*B+1>>>0]=V)}return o=qs(o,0,g,C,c),Er(w),o};function li(o){if(v)return _e(0,1,o);if(J=o,!(0<$t)){for(var c of vt)ui(c);for(c of dt)ui(c);dt=[],vt=[],Ye=[],ye=!0}I(o,new oi(o))}function Un(o){if(v)return _e(1,0,o);di(o)}var di=o=>{if(J=o,v)throw Un(o),"unwind";li(o)},dt=[],vt=[],Wn=[],Ye={},qn=o=>{var c=o.Bb;delete Ye[c],dt.push(o),vt.splice(vt.indexOf(o),1),o.Bb=0,ki(c)};function Ln(){Wn.forEach(o=>o())}var Fn=o=>new Promise(c=>{o.onmessage=w=>{var C=(w=w.data).cmd;if(w.targetThread&&w.targetThread!=Mt()){var O=Ye[w.targetThread];O?O.postMessage(w,w.transferList):U(`Internal error! Worker sent a message "${C}" to target pthread ${w.targetThread}, but that thread no longer exists!`)}else C==="checkMailbox"?yr():C==="spawnThread"?Vn(w):C==="cleanupThread"?qn(Ye[w.thread]):C==="killThread"?(w=w.thread,C=Ye[w],delete Ye[w],ui(C),ki(w),vt.splice(vt.indexOf(C),1),C.Bb=0):C==="cancelThread"?Ye[w.thread].postMessage({cmd:"cancel"}):C==="loaded"?(o.loaded=!0,c(o)):C==="alert"?alert(`Thread ${w.threadId}: ${w.text}`):w.target==="setimmediate"?o.postMessage(w):C==="callHandler"?l[w.handler](...w.args):C&&U(`worker sent an unknown command ${C}`)},o.onerror=w=>{throw U(`worker sent an error! ${w.filename}:${w.lineno}: ${w.message}`),w};var m,g=[];for(m of[])l.hasOwnProperty(m)&&g.push(m);o.postMessage({cmd:"load",handlers:g,wasmMemory:G,wasmModule:de})});function Gn(){var o=new Worker(import.meta.url.startsWith("file:")?new URL("/assets/ort.bundle.min-B0HgSllI.mjs",import.meta.url):new URL(import.meta.url),{type:"module",workerData:"em-pthread",name:"em-pthread"});dt.push(o)}var gr=o=>{for(;0<o.length;)o.shift()(l)},vf=()=>{var o=Mt(),c=u()[o+52>>>2>>>0];o=u()[o+56>>>2>>>0],Fs(c,c-o),Er(c)},xf=(o,c)=>{$t=0,o=Gs(o,c),0<$t?J=o:Cr(o)};class kf{constructor(c){this.Kb=c-24}}function Sf(o,c,m){var g=new kf(o>>>=0);throw c>>>=0,m>>>=0,u()[g.Kb+16>>>2>>>0]=0,u()[g.Kb+4>>>2>>>0]=c,u()[g.Kb+8>>>2>>>0]=m,o}function Hn(o,c,m,g){return v?_e(2,1,o,c,m,g):jn(o,c,m,g)}function jn(o,c,m,g){if(o>>>=0,c>>>=0,m>>>=0,g>>>=0,x===void 0)return U("Current environment does not support SharedArrayBuffer, pthreads are not available!"),6;var w=[];return v&&w.length===0?Hn(o,c,m,g):(o={ic:m,Bb:o,Rb:g,nc:w},v?(o.Nb="spawnThread",postMessage(o,w),0):Vn(o))}var Kn=typeof TextDecoder<"u"?new TextDecoder("utf8"):void 0,Zn=(o,c,m)=>{var g=(c>>>=0)+m;for(m=c;o[m]&&!(m>=g);)++m;if(16<m-c&&o.buffer&&Kn)return Kn.decode(o.buffer instanceof x?o.slice(c,m):o.subarray(c,m));for(g="";c<m;){var w=o[c++];if(128&w){var C=63&o[c++];if((224&w)==192)g+=String.fromCharCode((31&w)<<6|C);else{var O=63&o[c++];65536>(w=(240&w)==224?(15&w)<<12|C<<6|O:(7&w)<<18|C<<12|O<<6|63&o[c++])?g+=String.fromCharCode(w):(w-=65536,g+=String.fromCharCode(55296|w>>10,56320|1023&w))}}else g+=String.fromCharCode(w)}return g},xe=(o,c)=>(o>>>=0)?Zn(i(),o,c):"";function Yn(o,c,m){return v?_e(3,1,o,c,m):0}function Qn(o,c){if(v)return _e(4,1,o,c)}var pi=o=>{for(var c=0,m=0;m<o.length;++m){var g=o.charCodeAt(m);127>=g?c++:2047>=g?c+=2:55296<=g&&57343>=g?(c+=4,++m):c+=3}return c},Jn=(o,c,m,g)=>{if(!(0<g))return 0;var w=m>>>=0;g=m+g-1;for(var C=0;C<o.length;++C){var O=o.charCodeAt(C);if(55296<=O&&57343>=O&&(O=65536+((1023&O)<<10)|1023&o.charCodeAt(++C)),127>=O){if(m>=g)break;c[m++>>>0]=O}else{if(2047>=O){if(m+1>=g)break;c[m++>>>0]=192|O>>6}else{if(65535>=O){if(m+2>=g)break;c[m++>>>0]=224|O>>12}else{if(m+3>=g)break;c[m++>>>0]=240|O>>18,c[m++>>>0]=128|O>>12&63}c[m++>>>0]=128|O>>6&63}c[m++>>>0]=128|63&O}}return c[m>>>0]=0,m-w},Bt=(o,c,m)=>Jn(o,i(),c,m);function Xn(o,c){if(v)return _e(5,1,o,c)}function es(o,c,m){if(v)return _e(6,1,o,c,m)}function ts(o,c,m){return v?_e(7,1,o,c,m):0}function rs(o,c){if(v)return _e(8,1,o,c)}function is(o,c,m){if(v)return _e(9,1,o,c,m)}function as(o,c,m,g){if(v)return _e(10,1,o,c,m,g)}function ns(o,c,m,g){if(v)return _e(11,1,o,c,m,g)}function ss(o,c,m,g){if(v)return _e(12,1,o,c,m,g)}function os(o){if(v)return _e(13,1,o)}function us(o,c){if(v)return _e(14,1,o,c)}function ls(o,c,m){if(v)return _e(15,1,o,c,m)}var ds,pt,Tf=()=>{lt("")},Qe=o=>{for(var c="";i()[o>>>0];)c+=ds[i()[o++>>>0]];return c},ci={},hi={};function rt(o,c,m={}){if(!("argPackAdvance"in c))throw new TypeError("registerType registeredInstance requires argPackAdvance");return function(g,w,C={}){var O=w.name;if(!g)throw new pt(`type "${O}" must have a positive integer typeid pointer`);if(hi.hasOwnProperty(g)){if(C.Tb)return;throw new pt(`Cannot register type '${O}' twice`)}hi[g]=w,ci.hasOwnProperty(g)&&(w=ci[g],delete ci[g],w.forEach(B=>B()))}(o,c,m)}var ps=(o,c,m)=>{switch(c){case 1:return m?g=>r()[g>>>0]:g=>i()[g>>>0];case 2:return m?g=>a()[g>>>1>>>0]:g=>s()[g>>>1>>>0];case 4:return m?g=>n()[g>>>2>>>0]:g=>u()[g>>>2>>>0];case 8:return m?g=>ke[g>>>3]:g=>Ze[g>>>3];default:throw new TypeError(`invalid integer width (${c}): ${o}`)}};function Cf(o,c,m){m>>>=0,rt(o>>>=0,{name:c=Qe(c>>>0),fromWireType:g=>g,toWireType:function(g,w){if(typeof w!="bigint"&&typeof w!="number")throw w=w===null?"null":(g=typeof w)=="object"||g==="array"||g==="function"?w.toString():""+w,new TypeError(`Cannot convert "${w}" to ${this.name}`);return typeof w=="number"&&(w=BigInt(w)),w},argPackAdvance:ct,readValueFromPointer:ps(c,m,c.indexOf("u")==-1),Eb:null})}var ct=8;function Ef(o,c,m,g){rt(o>>>=0,{name:c=Qe(c>>>0),fromWireType:function(w){return!!w},toWireType:function(w,C){return C?m:g},argPackAdvance:ct,readValueFromPointer:function(w){return this.fromWireType(i()[w>>>0])},Eb:null})}var fi=[],it=[];function mi(o){9<(o>>>=0)&&--it[o+1]==0&&(it[o]=void 0,fi.push(o))}var Re=o=>{if(!o)throw new pt("Cannot use deleted val. handle = "+o);return it[o]},Ve=o=>{switch(o){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:let c=fi.pop()||it.length;return it[c]=o,it[c+1]=1,c}};function gi(o){return this.fromWireType(u()[o>>>2>>>0])}var If={name:"emscripten::val",fromWireType:o=>{var c=Re(o);return mi(o),c},toWireType:(o,c)=>Ve(c),argPackAdvance:ct,readValueFromPointer:gi,Eb:null};function zf(o){return rt(o>>>0,If)}var Af=(o,c)=>{switch(c){case 4:return function(m){return this.fromWireType(d()[m>>>2>>>0])};case 8:return function(m){return this.fromWireType(p()[m>>>3>>>0])};default:throw new TypeError(`invalid float width (${c}): ${o}`)}};function Of(o,c,m){m>>>=0,rt(o>>>=0,{name:c=Qe(c>>>0),fromWireType:g=>g,toWireType:(g,w)=>w,argPackAdvance:ct,readValueFromPointer:Af(c,m),Eb:null})}function Df(o,c,m,g,w){if(o>>>=0,m>>>=0,c=Qe(c>>>0),w===-1&&(w=4294967295),w=B=>B,g===0){var C=32-8*m;w=B=>B<<C>>>C}var O=c.includes("unsigned")?function(B,V){return V>>>0}:function(B,V){return V};rt(o,{name:c,fromWireType:w,toWireType:O,argPackAdvance:ct,readValueFromPointer:ps(c,m,g!==0),Eb:null})}function Rf(o,c,m){function g(C){var O=u()[C>>>2>>>0];return C=u()[C+4>>>2>>>0],new w(r().buffer,C,O)}var w=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array][c];rt(o>>>=0,{name:m=Qe(m>>>0),fromWireType:g,argPackAdvance:ct,readValueFromPointer:g},{Tb:!0})}function Bf(o,c){o>>>=0;var m=(c=Qe(c>>>0))==="std::string";rt(o,{name:c,fromWireType:function(g){var w=u()[g>>>2>>>0],C=g+4;if(m)for(var O=C,B=0;B<=w;++B){var V=C+B;if(B==w||i()[V>>>0]==0){if(O=xe(O,V-O),L===void 0)var L=O;else L+="\0",L+=O;O=V+1}}else{for(L=Array(w),B=0;B<w;++B)L[B]=String.fromCharCode(i()[C+B>>>0]);L=L.join("")}return Xe(g),L},toWireType:function(g,w){w instanceof ArrayBuffer&&(w=new Uint8Array(w));var C=typeof w=="string";if(!(C||w instanceof Uint8Array||w instanceof Uint8ClampedArray||w instanceof Int8Array))throw new pt("Cannot pass non-string to std::string");var O=m&&C?pi(w):w.length,B=Tr(4+O+1),V=B+4;if(u()[B>>>2>>>0]=O,m&&C)Bt(w,V,O+1);else if(C)for(C=0;C<O;++C){var L=w.charCodeAt(C);if(255<L)throw Xe(V),new pt("String has UTF-16 code units that do not fit in 8 bits");i()[V+C>>>0]=L}else for(C=0;C<O;++C)i()[V+C>>>0]=w[C];return g!==null&&g.push(Xe,B),B},argPackAdvance:ct,readValueFromPointer:gi,Eb(g){Xe(g)}})}var cs=typeof TextDecoder<"u"?new TextDecoder("utf-16le"):void 0,Nf=(o,c)=>{for(var m=o>>1,g=m+c/2;!(m>=g)&&s()[m>>>0];)++m;if(32<(m<<=1)-o&&cs)return cs.decode(i().slice(o,m));for(m="",g=0;!(g>=c/2);++g){var w=a()[o+2*g>>>1>>>0];if(w==0)break;m+=String.fromCharCode(w)}return m},Mf=(o,c,m)=>{if(m??(m=2147483647),2>m)return 0;var g=c;m=(m-=2)<2*o.length?m/2:o.length;for(var w=0;w<m;++w){var C=o.charCodeAt(w);a()[c>>>1>>>0]=C,c+=2}return a()[c>>>1>>>0]=0,c-g},Pf=o=>2*o.length,Vf=(o,c)=>{for(var m=0,g="";!(m>=c/4);){var w=n()[o+4*m>>>2>>>0];if(w==0)break;++m,65536<=w?(w-=65536,g+=String.fromCharCode(55296|w>>10,56320|1023&w)):g+=String.fromCharCode(w)}return g},Uf=(o,c,m)=>{if(c>>>=0,m??(m=2147483647),4>m)return 0;var g=c;m=g+m-4;for(var w=0;w<o.length;++w){var C=o.charCodeAt(w);if(55296<=C&&57343>=C&&(C=65536+((1023&C)<<10)|1023&o.charCodeAt(++w)),n()[c>>>2>>>0]=C,(c+=4)+4>m)break}return n()[c>>>2>>>0]=0,c-g},Wf=o=>{for(var c=0,m=0;m<o.length;++m){var g=o.charCodeAt(m);55296<=g&&57343>=g&&++m,c+=4}return c};function qf(o,c,m){if(o>>>=0,c>>>=0,m=Qe(m>>>=0),c===2)var g=Nf,w=Mf,C=Pf,O=B=>s()[B>>>1>>>0];else c===4&&(g=Vf,w=Uf,C=Wf,O=B=>u()[B>>>2>>>0]);rt(o,{name:m,fromWireType:B=>{for(var V,L=u()[B>>>2>>>0],Q=B+4,oe=0;oe<=L;++oe){var ce=B+4+oe*c;oe!=L&&O(ce)!=0||(Q=g(Q,ce-Q),V===void 0?V=Q:(V+="\0",V+=Q),Q=ce+c)}return Xe(B),V},toWireType:(B,V)=>{if(typeof V!="string")throw new pt(`Cannot pass non-string to C++ string type ${m}`);var L=C(V),Q=Tr(4+L+c);return u()[Q>>>2>>>0]=L/c,w(V,Q+4,L+c),B!==null&&B.push(Xe,Q),Q},argPackAdvance:ct,readValueFromPointer:gi,Eb(B){Xe(B)}})}function Lf(o,c){rt(o>>>=0,{Ub:!0,name:c=Qe(c>>>0),argPackAdvance:0,fromWireType:()=>{},toWireType:()=>{}})}var Ff=()=>1;function Gf(o){xi(o>>>0,!b,1,!_,131072,!1),Ln()}var hs=o=>{if(!ye)try{if(o(),!(0<$t))try{v?Cr(J):di(J)}catch(c){c instanceof oi||c=="unwind"||I(1,c)}}catch(c){c instanceof oi||c=="unwind"||I(1,c)}};function yi(o){o>>>=0,typeof Atomics.oc=="function"&&(Atomics.oc(n(),o>>>2,o).value.then(yr),o+=128,Atomics.store(n(),o>>>2,1))}var yr=()=>{var o=Mt();o&&(yi(o),hs(Ls))};function Hf(o,c){(o>>>=0)==c>>>0?setTimeout(yr):v?postMessage({targetThread:o,cmd:"checkMailbox"}):(o=Ye[o])&&o.postMessage({cmd:"checkMailbox"})}var _i=[];function jf(o,c,m,g,w){for(c>>>=0,g/=2,_i.length=g,m=w>>>0>>>3,w=0;w<g;w++)_i[w]=ke[m+2*w]?ke[m+2*w+1]:p()[m+2*w+1>>>0];return(c?si[c]:Mm[o])(..._i)}function Kf(o){o>>>=0,v?postMessage({cmd:"cleanupThread",thread:o}):qn(Ye[o])}function Zf(o){}var _r=(o,c)=>{var m=hi[o];if(m===void 0)throw o=Vs(o),m=Qe(o),Xe(o),new pt(`${c} has unknown type ${m}`);return m},fs=(o,c,m)=>{var g=[];return o=o.toWireType(g,m),g.length&&(u()[c>>>2>>>0]=Ve(g)),o};function Yf(o,c,m){return c>>>=0,m>>>=0,o=Re(o>>>0),c=_r(c,"emval::as"),fs(c,m,o)}function Qf(o,c){return c>>>=0,o=Re(o>>>0),(c=_r(c,"emval::as")).toWireType(null,o)}var br=o=>{try{o()}catch(c){lt(c)}},ht=0,Je=null,ms=0,wr=[],gs={},ys={},Jf=0,bi=null,Xf=[];function _s(o){return function(c){if(!ye){if(ht===0){var m=!1,g=!1;c((w=0)=>{if(!ye&&(ms=w,m=!0,g)){ht=2,br(()=>Ks(Je)),typeof Browser<"u"&&Browser.Lb.Sb&&Browser.Lb.resume(),w=!1;try{var C=function(){var V=n()[Je+8>>>2>>>0];return V=Y[ys[V]],--$t,V()}()}catch(V){C=V,w=!0}var O=!1;if(!Je){var B=bi;B&&(bi=null,(w?B.reject:B.resolve)(C),O=!0)}if(w&&!O)throw C}}),g=!0,m||(ht=1,Je=function(){var w=Tr(65548),C=w+12;u()[w>>>2>>>0]=C,u()[w+4>>>2>>>0]=C+65536,C=wr[0];var O=gs[C];return O===void 0&&(O=Jf++,gs[C]=O,ys[O]=C),C=O,n()[w+8>>>2>>>0]=C,w}(),typeof Browser<"u"&&Browser.Lb.Sb&&Browser.Lb.pause(),br(()=>Hs(Je)))}else ht===2?(ht=0,br(Zs),Xe(Je),Je=null,Xf.forEach(hs)):lt(`invalid state: ${ht}`);return ms}}(c=>{o().then(c)})}function em(o){return o>>>=0,_s(()=>(o=Re(o)).then(Ve))}var $r=[];function tm(o,c,m,g){return m>>>=0,g>>>=0,(o=$r[o>>>0])(null,c=Re(c>>>0),m,g)}var rm={},vr=o=>{var c=rm[o];return c===void 0?Qe(o):c};function im(o,c,m,g,w){return m>>>=0,g>>>=0,w>>>=0,(o=$r[o>>>0])(c=Re(c>>>0),c[m=vr(m)],g,w)}var bs=()=>typeof globalThis=="object"?globalThis:Function("return this")();function am(o){return(o>>>=0)==0?Ve(bs()):(o=vr(o),Ve(bs()[o]))}var nm=o=>{var c=$r.length;return $r.push(o),c},sm=(o,c)=>{for(var m=Array(o),g=0;g<o;++g)m[g]=_r(u()[c+4*g>>>2>>>0],"parameter "+g);return m},ws=(o,c)=>Object.defineProperty(c,"name",{value:o});function om(o,c,m){var g=(c=sm(o,c>>>0)).shift();o--;var w=`return function (obj, func, destructorsRef, args) {
`,C=0,O=[];m===0&&O.push("obj");for(var B=["retType"],V=[g],L=0;L<o;++L)O.push("arg"+L),B.push("argType"+L),V.push(c[L]),w+=`  var arg${L} = argType${L}.readValueFromPointer(args${C?"+"+C:""});
`,C+=c[L].argPackAdvance;return w+=`  var rv = ${m===1?"new func":"func.call"}(${O.join(", ")});
`,g.Ub||(B.push("emval_returnValue"),V.push(fs),w+=`  return emval_returnValue(retType, destructorsRef, rv);
`),B.push(w+`};
`),o=function(Q){var oe=Function;if(!(oe instanceof Function))throw new TypeError(`new_ called with constructor type ${typeof oe} which is not a function`);var ce=ws(oe.name||"unknownFunctionName",function(){});return ce.prototype=oe.prototype,ce=new ce,(Q=oe.apply(ce,Q))instanceof Object?Q:ce}(B)(...V),m=`methodCaller<(${c.map(Q=>Q.name).join(", ")}) => ${g.name}>`,nm(ws(m,o))}function um(o){return o=vr(o>>>0),Ve(l[o])}function lm(o,c){return c>>>=0,o=Re(o>>>0),c=Re(c),Ve(o[c])}function dm(o){9<(o>>>=0)&&(it[o+1]+=1)}function pm(){return Ve([])}function cm(o){o=Re(o>>>0);for(var c=Array(o.length),m=0;m<o.length;m++)c[m]=o[m];return Ve(c)}function hm(o){return Ve(vr(o>>>0))}function fm(){return Ve({})}function mm(o){for(var c=Re(o>>>=0);c.length;){var m=c.pop();c.pop()(m)}mi(o)}function gm(o,c,m){c>>>=0,m>>>=0,o=Re(o>>>0),c=Re(c),m=Re(m),o[c]=m}function ym(o,c){return c>>>=0,o=(o=_r(o>>>0,"_emval_take_value")).readValueFromPointer(c),Ve(o)}function _m(o,c){o=-9007199254740992>o||9007199254740992<o?NaN:Number(o),c>>>=0,o=new Date(1e3*o),n()[c>>>2>>>0]=o.getUTCSeconds(),n()[c+4>>>2>>>0]=o.getUTCMinutes(),n()[c+8>>>2>>>0]=o.getUTCHours(),n()[c+12>>>2>>>0]=o.getUTCDate(),n()[c+16>>>2>>>0]=o.getUTCMonth(),n()[c+20>>>2>>>0]=o.getUTCFullYear()-1900,n()[c+24>>>2>>>0]=o.getUTCDay(),o=(o.getTime()-Date.UTC(o.getUTCFullYear(),0,1,0,0,0,0))/864e5|0,n()[c+28>>>2>>>0]=o}var Nt=o=>o%4==0&&(o%100!=0||o%400==0),$s=[0,31,60,91,121,152,182,213,244,274,305,335],vs=[0,31,59,90,120,151,181,212,243,273,304,334];function bm(o,c){o=-9007199254740992>o||9007199254740992<o?NaN:Number(o),c>>>=0,o=new Date(1e3*o),n()[c>>>2>>>0]=o.getSeconds(),n()[c+4>>>2>>>0]=o.getMinutes(),n()[c+8>>>2>>>0]=o.getHours(),n()[c+12>>>2>>>0]=o.getDate(),n()[c+16>>>2>>>0]=o.getMonth(),n()[c+20>>>2>>>0]=o.getFullYear()-1900,n()[c+24>>>2>>>0]=o.getDay();var m=(Nt(o.getFullYear())?$s:vs)[o.getMonth()]+o.getDate()-1|0;n()[c+28>>>2>>>0]=m,n()[c+36>>>2>>>0]=-60*o.getTimezoneOffset(),m=new Date(o.getFullYear(),6,1).getTimezoneOffset();var g=new Date(o.getFullYear(),0,1).getTimezoneOffset();o=0|(m!=g&&o.getTimezoneOffset()==Math.min(g,m)),n()[c+32>>>2>>>0]=o}function wm(o){o>>>=0;var c=new Date(n()[o+20>>>2>>>0]+1900,n()[o+16>>>2>>>0],n()[o+12>>>2>>>0],n()[o+8>>>2>>>0],n()[o+4>>>2>>>0],n()[o>>>2>>>0],0),m=n()[o+32>>>2>>>0],g=c.getTimezoneOffset(),w=new Date(c.getFullYear(),6,1).getTimezoneOffset(),C=new Date(c.getFullYear(),0,1).getTimezoneOffset(),O=Math.min(C,w);return 0>m?n()[o+32>>>2>>>0]=+(w!=C&&O==g):0<m!=(O==g)&&(w=Math.max(C,w),c.setTime(c.getTime()+6e4*((0<m?O:w)-g))),n()[o+24>>>2>>>0]=c.getDay(),m=(Nt(c.getFullYear())?$s:vs)[c.getMonth()]+c.getDate()-1|0,n()[o+28>>>2>>>0]=m,n()[o>>>2>>>0]=c.getSeconds(),n()[o+4>>>2>>>0]=c.getMinutes(),n()[o+8>>>2>>>0]=c.getHours(),n()[o+12>>>2>>>0]=c.getDate(),n()[o+16>>>2>>>0]=c.getMonth(),n()[o+20>>>2>>>0]=c.getYear(),o=c.getTime(),BigInt(isNaN(o)?-1:o/1e3)}function xs(o,c,m,g,w,C,O){return v?_e(16,1,o,c,m,g,w,C,O):-52}function ks(o,c,m,g,w,C){if(v)return _e(17,1,o,c,m,g,w,C)}function $m(o,c,m,g){o>>>=0,c>>>=0,m>>>=0,g>>>=0;var w=new Date().getFullYear(),C=new Date(w,0,1),O=new Date(w,6,1);w=C.getTimezoneOffset();var B=O.getTimezoneOffset(),V=Math.max(w,B);u()[o>>>2>>>0]=60*V,n()[c>>>2>>>0]=+(w!=B),C=(o=L=>L.toLocaleTimeString(void 0,{hour12:!1,timeZoneName:"short"}).split(" ")[1])(C),O=o(O),B<w?(Bt(C,m,17),Bt(O,g,17)):(Bt(C,g,17),Bt(O,m,17))}var wi=[],Ss=(o,c)=>{wi.length=0;for(var m;m=i()[o++>>>0];){var g=m!=105;c+=(g&=m!=112)&&c%8?4:0,wi.push(m==112?u()[c>>>2>>>0]:m==106?ke[c>>>3]:m==105?n()[c>>>2>>>0]:p()[c>>>3>>>0]),c+=g?8:4}return wi};function vm(o,c,m){return o>>>=0,c=Ss(c>>>0,m>>>0),si[o](...c)}function xm(o,c,m){return o>>>=0,c=Ss(c>>>0,m>>>0),si[o](...c)}var km=()=>{},Sm=()=>Date.now();function Tm(o,c){return U(xe(o>>>0,c>>>0))}var Ts,Cm=()=>{throw $t+=1,"unwind"};function Em(){return 4294901760}Ts=()=>performance.timeOrigin+performance.now();var Im=()=>navigator.hardwareConcurrency;function zm(){return lt("Cannot use emscripten_pc_get_function without -sUSE_OFFSET_CONVERTER"),0}function Am(o){o>>>=0;var c=i().length;if(o<=c||4294901760<o)return!1;for(var m=1;4>=m;m*=2){var g=c*(1+.2/m);g=Math.min(g,o+100663296);var w=Math;g=Math.max(o,g);e:{w=(w.min.call(w,4294901760,g+(65536-g%65536)%65536)-G.buffer.byteLength+65535)/65536;try{G.grow(w),me();var C=1;break e}catch{}C=void 0}if(C)return!0}return!1}var xr=()=>(lt("Cannot use convertFrameToPC (needed by __builtin_return_address) without -sUSE_OFFSET_CONVERTER"),0),Zt={},Cs=o=>{o.forEach(c=>{xr()})};function Om(){var o=Error().stack.toString().split(`
`);return o[0]=="Error"&&o.shift(),Cs(o),Zt.Qb=xr(),Zt.fc=o,Zt.Qb}function Dm(o,c,m){if(o>>>=0,c>>>=0,Zt.Qb==o)var g=Zt.fc;else(g=Error().stack.toString().split(`
`))[0]=="Error"&&g.shift(),Cs(g);for(var w=3;g[w]&&xr()!=o;)++w;for(o=0;o<m&&g[o+w];++o)n()[c+4*o>>>2>>>0]=xr();return o}var $i,vi={},Es=()=>{if(!$i){var o,c={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:(typeof navigator=="object"&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8",_:E};for(o in vi)vi[o]===void 0?delete c[o]:c[o]=vi[o];var m=[];for(o in c)m.push(`${o}=${c[o]}`);$i=m}return $i};function Is(o,c){if(v)return _e(18,1,o,c);o>>>=0,c>>>=0;var m=0;return Es().forEach((g,w)=>{var C=c+m;for(w=u()[o+4*w>>>2>>>0]=C,C=0;C<g.length;++C)r()[w++>>>0]=g.charCodeAt(C);r()[w>>>0]=0,m+=g.length+1}),0}function zs(o,c){if(v)return _e(19,1,o,c);o>>>=0,c>>>=0;var m=Es();u()[o>>>2>>>0]=m.length;var g=0;return m.forEach(w=>g+=w.length+1),u()[c>>>2>>>0]=g,0}function As(o){return v?_e(20,1,o):52}function Os(o,c,m,g){return v?_e(21,1,o,c,m,g):52}function Ds(o,c,m,g){return v?_e(22,1,o,c,m,g):70}var Rm=[null,[],[]];function Rs(o,c,m,g){if(v)return _e(23,1,o,c,m,g);c>>>=0,m>>>=0,g>>>=0;for(var w=0,C=0;C<m;C++){var O=u()[c>>>2>>>0],B=u()[c+4>>>2>>>0];c+=8;for(var V=0;V<B;V++){var L=i()[O+V>>>0],Q=Rm[o];L===0||L===10?((o===1?te:U)(Zn(Q,0)),Q.length=0):Q.push(L)}w+=B}return u()[g>>>2>>>0]=w,0}var Bs=[31,29,31,30,31,30,31,31,30,31,30,31],Ns=[31,28,31,30,31,30,31,31,30,31,30,31],Bm=(o,c)=>{r().set(o,c>>>0)};function Ms(o,c,m,g){function w(A,ne,$e){for(A=typeof A=="number"?A.toString():A||"";A.length<ne;)A=$e[0]+A;return A}function C(A,ne){return w(A,ne,"0")}function O(A,ne){function $e(Qs){return 0>Qs?-1:0<Qs?1:0}var xt;return(xt=$e(A.getFullYear()-ne.getFullYear()))===0&&(xt=$e(A.getMonth()-ne.getMonth()))===0&&(xt=$e(A.getDate()-ne.getDate())),xt}function B(A){switch(A.getDay()){case 0:return new Date(A.getFullYear()-1,11,29);case 1:return A;case 2:return new Date(A.getFullYear(),0,3);case 3:return new Date(A.getFullYear(),0,2);case 4:return new Date(A.getFullYear(),0,1);case 5:return new Date(A.getFullYear()-1,11,31);case 6:return new Date(A.getFullYear()-1,11,30)}}function V(A){var ne=A.Cb;for(A=new Date(new Date(A.Db+1900,0,1).getTime());0<ne;){var $e=A.getMonth(),xt=(Nt(A.getFullYear())?Bs:Ns)[$e];if(!(ne>xt-A.getDate())){A.setDate(A.getDate()+ne);break}ne-=xt-A.getDate()+1,A.setDate(1),11>$e?A.setMonth($e+1):(A.setMonth(0),A.setFullYear(A.getFullYear()+1))}return $e=new Date(A.getFullYear()+1,0,4),ne=B(new Date(A.getFullYear(),0,4)),$e=B($e),0>=O(ne,A)?0>=O($e,A)?A.getFullYear()+1:A.getFullYear():A.getFullYear()-1}o>>>=0,c>>>=0,m>>>=0,g>>>=0;var L=u()[g+40>>>2>>>0];for(var Q in g={lc:n()[g>>>2>>>0],kc:n()[g+4>>>2>>>0],Ib:n()[g+8>>>2>>>0],Mb:n()[g+12>>>2>>>0],Jb:n()[g+16>>>2>>>0],Db:n()[g+20>>>2>>>0],vb:n()[g+24>>>2>>>0],Cb:n()[g+28>>>2>>>0],sc:n()[g+32>>>2>>>0],jc:n()[g+36>>>2>>>0],mc:L?xe(L):""},m=xe(m),L={"%c":"%a %b %d %H:%M:%S %Y","%D":"%m/%d/%y","%F":"%Y-%m-%d","%h":"%b","%r":"%I:%M:%S %p","%R":"%H:%M","%T":"%H:%M:%S","%x":"%m/%d/%y","%X":"%H:%M:%S","%Ec":"%c","%EC":"%C","%Ex":"%m/%d/%y","%EX":"%H:%M:%S","%Ey":"%y","%EY":"%Y","%Od":"%d","%Oe":"%e","%OH":"%H","%OI":"%I","%Om":"%m","%OM":"%M","%OS":"%S","%Ou":"%u","%OU":"%U","%OV":"%V","%Ow":"%w","%OW":"%W","%Oy":"%y"})m=m.replace(new RegExp(Q,"g"),L[Q]);var oe="Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),ce="January February March April May June July August September October November December".split(" ");for(Q in L={"%a":A=>oe[A.vb].substring(0,3),"%A":A=>oe[A.vb],"%b":A=>ce[A.Jb].substring(0,3),"%B":A=>ce[A.Jb],"%C":A=>C((A.Db+1900)/100|0,2),"%d":A=>C(A.Mb,2),"%e":A=>w(A.Mb,2," "),"%g":A=>V(A).toString().substring(2),"%G":V,"%H":A=>C(A.Ib,2),"%I":A=>((A=A.Ib)==0?A=12:12<A&&(A-=12),C(A,2)),"%j":A=>{for(var ne=0,$e=0;$e<=A.Jb-1;ne+=(Nt(A.Db+1900)?Bs:Ns)[$e++]);return C(A.Mb+ne,3)},"%m":A=>C(A.Jb+1,2),"%M":A=>C(A.kc,2),"%n":()=>`
`,"%p":A=>0<=A.Ib&&12>A.Ib?"AM":"PM","%S":A=>C(A.lc,2),"%t":()=>"	","%u":A=>A.vb||7,"%U":A=>C(Math.floor((A.Cb+7-A.vb)/7),2),"%V":A=>{var ne=Math.floor((A.Cb+7-(A.vb+6)%7)/7);if(2>=(A.vb+371-A.Cb-2)%7&&ne++,ne)ne==53&&(($e=(A.vb+371-A.Cb)%7)==4||$e==3&&Nt(A.Db)||(ne=1));else{ne=52;var $e=(A.vb+7-A.Cb-1)%7;($e==4||$e==5&&Nt(A.Db%400-1))&&ne++}return C(ne,2)},"%w":A=>A.vb,"%W":A=>C(Math.floor((A.Cb+7-(A.vb+6)%7)/7),2),"%y":A=>(A.Db+1900).toString().substring(2),"%Y":A=>A.Db+1900,"%z":A=>{var ne=0<=(A=A.jc);return A=Math.abs(A)/60,(ne?"+":"-")+("0000"+(A/60*100+A%60)).slice(-4)},"%Z":A=>A.mc,"%%":()=>"%"},m=m.replace(/%%/g,"\0\0"),L)m.includes(Q)&&(m=m.replace(new RegExp(Q,"g"),L[Q](g)));return Q=function(A){var ne=Array(pi(A)+1);return Jn(A,ne,0,ne.length),ne}(m=m.replace(/\0\0/g,"%")),Q.length>c?0:(Bm(Q,o),Q.length-1)}function Nm(o,c,m,g){return Ms(o>>>0,c>>>0,m>>>0,g>>>0)}v||function(){for(var o=l.numThreads-1;o--;)Gn();ut.unshift(()=>{jt++,function(c){v?c():Promise.all(dt.map(Fn)).then(c)}(()=>Dn())})}();for(var Ps=Array(256),kr=0;256>kr;++kr)Ps[kr]=String.fromCharCode(kr);ds=Ps,pt=l.BindingError=class extends Error{constructor(o){super(o),this.name="BindingError"}},l.InternalError=class extends Error{constructor(o){super(o),this.name="InternalError"}},it.push(0,1,void 0,1,null,1,!0,1,!1,1),l.count_emval_handles=()=>it.length/2-5-fi.length;var Mm=[li,Un,Hn,Yn,Qn,Xn,es,ts,rs,is,as,ns,ss,os,us,ls,xs,ks,Is,zs,As,Os,Ds,Rs],Y=function(){function o(m,g){return Y=m.exports,Y=function(){var w=Y,C={};for(let[O,B]of Object.entries(w))C[O]=typeof B=="function"?(...V)=>{wr.push(O);try{return B(...V)}finally{ye||(wr.pop(),Je&&ht===1&&wr.length===0&&(ht=0,$t+=1,br(js),typeof Fibers<"u"&&Fibers.tc()))}}:B;return C}(),Y=function(){var w=Y,C=B=>V=>B(V)>>>0,O=B=>()=>B()>>>0;return(w=Object.assign({},w)).Da=C(w.Da),w.gb=O(w.gb),w.ib=C(w.ib),w.emscripten_main_runtime_thread_id=O(w.emscripten_main_runtime_thread_id),w.tb=C(w.tb),w.ub=O(w.ub),w}(),Wn.push(Y.jb),Ht.unshift(Y.Ca),de=g,Dn(),Y}var c=Pn();if(jt++,l.instantiateWasm)try{return l.instantiateWasm(c,o)}catch(m){U(`Module.instantiateWasm callback failed with error: ${m}`),h(m)}return ni||(ni=l.locateFile?Rn("ort-wasm-simd-threaded.jsep.wasm")?"ort-wasm-simd-threaded.jsep.wasm":l.locateFile?l.locateFile("ort-wasm-simd-threaded.jsep.wasm",D):D+"ort-wasm-simd-threaded.jsep.wasm":new URL("/assets/ort-wasm-simd-threaded.jsep-CJtsIIQL.wasm",import.meta.url).href),function(m,g){var w=ni;return M||typeof WebAssembly.instantiateStreaming!="function"||Rn(w)||Bn(w)||typeof fetch!="function"?Mn(w,m,g):fetch(w,{credentials:"same-origin"}).then(C=>WebAssembly.instantiateStreaming(C,m).then(g,function(O){return U(`wasm streaming compile failed: ${O}`),U("falling back to ArrayBuffer instantiation"),Mn(w,m,g)}))}(c,function(m){o(m.instance,m.module)}).catch(h),{}}(),Vs=o=>(Vs=Y.Da)(o),Us=()=>(Us=Y.Ea)();l._OrtInit=(o,c)=>(l._OrtInit=Y.Fa)(o,c),l._OrtGetLastError=(o,c)=>(l._OrtGetLastError=Y.Ga)(o,c),l._OrtCreateSessionOptions=(o,c,m,g,w,C,O,B,V,L)=>(l._OrtCreateSessionOptions=Y.Ha)(o,c,m,g,w,C,O,B,V,L),l._OrtAppendExecutionProvider=(o,c)=>(l._OrtAppendExecutionProvider=Y.Ia)(o,c),l._OrtAddFreeDimensionOverride=(o,c,m)=>(l._OrtAddFreeDimensionOverride=Y.Ja)(o,c,m),l._OrtAddSessionConfigEntry=(o,c,m)=>(l._OrtAddSessionConfigEntry=Y.Ka)(o,c,m),l._OrtReleaseSessionOptions=o=>(l._OrtReleaseSessionOptions=Y.La)(o),l._OrtCreateSession=(o,c,m)=>(l._OrtCreateSession=Y.Ma)(o,c,m),l._OrtReleaseSession=o=>(l._OrtReleaseSession=Y.Na)(o),l._OrtGetInputOutputCount=(o,c,m)=>(l._OrtGetInputOutputCount=Y.Oa)(o,c,m),l._OrtGetInputName=(o,c)=>(l._OrtGetInputName=Y.Pa)(o,c),l._OrtGetOutputName=(o,c)=>(l._OrtGetOutputName=Y.Qa)(o,c),l._OrtFree=o=>(l._OrtFree=Y.Ra)(o),l._OrtCreateTensor=(o,c,m,g,w,C)=>(l._OrtCreateTensor=Y.Sa)(o,c,m,g,w,C),l._OrtGetTensorData=(o,c,m,g,w)=>(l._OrtGetTensorData=Y.Ta)(o,c,m,g,w),l._OrtReleaseTensor=o=>(l._OrtReleaseTensor=Y.Ua)(o),l._OrtCreateRunOptions=(o,c,m,g)=>(l._OrtCreateRunOptions=Y.Va)(o,c,m,g),l._OrtAddRunConfigEntry=(o,c,m)=>(l._OrtAddRunConfigEntry=Y.Wa)(o,c,m),l._OrtReleaseRunOptions=o=>(l._OrtReleaseRunOptions=Y.Xa)(o),l._OrtCreateBinding=o=>(l._OrtCreateBinding=Y.Ya)(o),l._OrtBindInput=(o,c,m)=>(l._OrtBindInput=Y.Za)(o,c,m),l._OrtBindOutput=(o,c,m,g)=>(l._OrtBindOutput=Y._a)(o,c,m,g),l._OrtClearBoundOutputs=o=>(l._OrtClearBoundOutputs=Y.$a)(o),l._OrtReleaseBinding=o=>(l._OrtReleaseBinding=Y.ab)(o),l._OrtRunWithBinding=(o,c,m,g,w)=>(l._OrtRunWithBinding=Y.bb)(o,c,m,g,w),l._OrtRun=(o,c,m,g,w,C,O,B)=>(l._OrtRun=Y.cb)(o,c,m,g,w,C,O,B),l._OrtEndProfiling=o=>(l._OrtEndProfiling=Y.db)(o),l._JsepOutput=(o,c,m)=>(l._JsepOutput=Y.eb)(o,c,m),l._JsepGetNodeName=o=>(l._JsepGetNodeName=Y.fb)(o);var Sr,Mt=()=>(Mt=Y.gb)(),Xe=l._free=o=>(Xe=l._free=Y.hb)(o),Tr=l._malloc=o=>(Tr=l._malloc=Y.ib)(o),xi=(o,c,m,g,w,C)=>(xi=Y.lb)(o,c,m,g,w,C),Ws=()=>(Ws=Y.mb)(),qs=(o,c,m,g,w)=>(qs=Y.nb)(o,c,m,g,w),ki=o=>(ki=Y.ob)(o),Cr=o=>(Cr=Y.pb)(o),Ls=()=>(Ls=Y.qb)(),Fs=(o,c)=>(Fs=Y.rb)(o,c),Er=o=>(Er=Y.sb)(o),Si=o=>(Si=Y.tb)(o),Ti=()=>(Ti=Y.ub)(),Gs=l.dynCall_ii=(o,c)=>(Gs=l.dynCall_ii=Y.wb)(o,c),Hs=o=>(Hs=Y.xb)(o),js=()=>(js=Y.yb)(),Ks=o=>(Ks=Y.zb)(o),Zs=()=>(Zs=Y.Ab)();function Ys(){0<jt||(v?(f(l),v||gr(Ht),startWorker(l)):(gr(ut),0<jt||Sr||(Sr=!0,l.calledRun=!0,ye||(v||gr(Ht),f(l),v||gr(ai)))))}return l.___start_em_js=929301,l.___stop_em_js=929547,l.stackSave=()=>Ti(),l.stackRestore=o=>Er(o),l.stackAlloc=o=>Si(o),l.setValue=function(o,c,m="i8"){switch(m.endsWith("*")&&(m="*"),m){case"i1":case"i8":r()[o>>>0]=c;break;case"i16":a()[o>>>1>>>0]=c;break;case"i32":n()[o>>>2>>>0]=c;break;case"i64":ke[o>>>3]=BigInt(c);break;case"float":d()[o>>>2>>>0]=c;break;case"double":p()[o>>>3>>>0]=c;break;case"*":u()[o>>>2>>>0]=c;break;default:lt(`invalid type for setValue: ${m}`)}},l.getValue=function(o,c="i8"){switch(c.endsWith("*")&&(c="*"),c){case"i1":case"i8":return r()[o>>>0];case"i16":return a()[o>>>1>>>0];case"i32":return n()[o>>>2>>>0];case"i64":return ke[o>>>3];case"float":return d()[o>>>2>>>0];case"double":return p()[o>>>3>>>0];case"*":return u()[o>>>2>>>0];default:lt(`invalid type for getValue: ${c}`)}},l.UTF8ToString=xe,l.stringToUTF8=Bt,l.lengthBytesUTF8=pi,Kt=function o(){Sr||Ys(),Sr||(Kt=o)},Ys(),l.PTR_SIZE=4,y}),Xd=Di,((e=globalThis.self)==null?void 0:e.name)==="em-pthread"&&Di()}),Ri,Xs,Be,ep,zr,eo,to,Bi,ro,Ni,tp,Mi,rp,Ga=P(()=>{Fa(),Ri=typeof location>"u"?void 0:location.origin,Xs=()=>{var e;return(e=import.meta.url)!=null&&e.startsWith("file:")?new URL(new URL("/assets/ort.bundle.min-B0HgSllI.mjs",import.meta.url).href,Ri).href:import.meta.url},Be=Xs(),ep=()=>{if(Be&&!Be.startsWith("blob:"))return Be.substring(0,Be.lastIndexOf("/")+1)},zr=(e,t)=>{try{let r=t??Be;return(r?new URL(e,r):new URL(e)).origin===Ri}catch{return!1}},eo=(e,t)=>{let r=t??Be;try{return(r?new URL(e,r):new URL(e)).href}catch{return}},to=(e,t)=>`${t??"./"}${e}`,Bi=async e=>{let t=await(await fetch(e,{credentials:"same-origin"})).blob();return URL.createObjectURL(t)},ro=async e=>(await import(e)).default,Ni=(ig(),Fr(Yd)).default,tp=async()=>{if(!Be)throw new Error("Failed to load proxy worker: cannot determine the script source URL.");if(zr(Be))return[void 0,Ni()];let e=await Bi(Be);return[e,Ni(e)]},Mi=(ag(),Fr(Jd)).default,rp=async(e,t,r)=>{if(!e&&!t&&Mi&&Be&&zr(Be))return[void 0,Mi];{let i="ort-wasm-simd-threaded.jsep.mjs",a=e??eo(i,t),s=r&&a&&!zr(a,t),n=s?await Bi(a):a??to(i,t);return[s?n:void 0,await ro(n)]}}}),Pi,Ar,Qt,Vi,io,ao,Ha,Se,Dt=P(()=>{Ga(),Ar=!1,Qt=!1,Vi=!1,io=()=>{if(typeof SharedArrayBuffer>"u")return!1;try{return typeof MessageChannel<"u"&&new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)),WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,5,4,1,3,1,1,10,11,1,9,0,65,0,254,16,2,0,26,11]))}catch{return!1}},ao=()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,30,1,28,0,65,0,253,15,253,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,253,186,1,26,11]))}catch{return!1}},Ha=async e=>{if(Ar)return Promise.resolve();if(Qt)throw new Error("multiple calls to 'initializeWebAssembly()' detected.");if(Vi)throw new Error("previous call to 'initializeWebAssembly()' failed.");Qt=!0;let t=e.initTimeout,r=e.numThreads;if(!ao())throw new Error("WebAssembly SIMD is not supported in the current environment.");let i=io();r>1&&!i&&(typeof self<"u"&&!self.crossOriginIsolated&&console.warn("env.wasm.numThreads is set to "+r+", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."),console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."),e.numThreads=r=1);let a=e.wasmPaths,s=typeof a=="string"?a:void 0,n=a==null?void 0:a.mjs,u=(n==null?void 0:n.href)??n,d=a==null?void 0:a.wasm,p=(d==null?void 0:d.href)??d,f=e.wasmBinary,[h,l]=await rp(u,s,r>1),y=!1,_=[];if(t>0&&_.push(new Promise(b=>{setTimeout(()=>{y=!0,b()},t)})),_.push(new Promise((b,v)=>{let x={numThreads:r};if(f)x.wasmBinary=f;else if(p||s)x.locateFile=$=>p??s+$;else if(u&&u.indexOf("blob:")!==0)x.locateFile=$=>new URL($,u).href;else if(h){let $=ep();$&&(x.locateFile=S=>$+S)}l(x).then($=>{Qt=!1,Ar=!0,Pi=$,b(),h&&URL.revokeObjectURL(h)},$=>{Qt=!1,Vi=!0,v($)})})),await Promise.race(_),y)throw new Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`)},Se=()=>{if(Ar&&Pi)return Pi;throw new Error("WebAssembly is not initialized yet.")}}),Ee,Hr,pe,ja=P(()=>{Dt(),Ee=(e,t)=>{let r=Se(),i=r.lengthBytesUTF8(e)+1,a=r._malloc(i);return r.stringToUTF8(e,a,i),t.push(a),a},Hr=(e,t,r,i)=>{if(typeof e=="object"&&e!==null){if(r.has(e))throw new Error("Circular reference in options");r.add(e)}Object.entries(e).forEach(([a,s])=>{let n=t?t+a:a;if(typeof s=="object")Hr(s,n+".",r,i);else if(typeof s=="string"||typeof s=="number")i(n,s.toString());else if(typeof s=="boolean")i(n,s?"1":"0");else throw new Error(`Can't handle extra config type: ${typeof s}`)})},pe=e=>{let t=Se(),r=t.stackSave();try{let i=t.PTR_SIZE,a=t.stackAlloc(2*i);t._OrtGetLastError(a,a+i);let s=Number(t.getValue(a,i===4?"i32":"i64")),n=t.getValue(a+i,"*"),u=n?t.UTF8ToString(n):"";throw new Error(`${e} ERROR_CODE: ${s}, ERROR_MESSAGE: ${u}`)}finally{t.stackRestore(r)}}}),ip,ng=P(()=>{Dt(),ja(),ip=e=>{let t=Se(),r=0,i=[],a=e||{};try{if((e==null?void 0:e.logSeverityLevel)===void 0)a.logSeverityLevel=2;else if(typeof e.logSeverityLevel!="number"||!Number.isInteger(e.logSeverityLevel)||e.logSeverityLevel<0||e.logSeverityLevel>4)throw new Error(`log serverity level is not valid: ${e.logSeverityLevel}`);if((e==null?void 0:e.logVerbosityLevel)===void 0)a.logVerbosityLevel=0;else if(typeof e.logVerbosityLevel!="number"||!Number.isInteger(e.logVerbosityLevel))throw new Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);(e==null?void 0:e.terminate)===void 0&&(a.terminate=!1);let s=0;return(e==null?void 0:e.tag)!==void 0&&(s=Ee(e.tag,i)),r=t._OrtCreateRunOptions(a.logSeverityLevel,a.logVerbosityLevel,!!a.terminate,s),r===0&&pe("Can't create run options."),(e==null?void 0:e.extra)!==void 0&&Hr(e.extra,"",new WeakSet,(n,u)=>{let d=Ee(n,i),p=Ee(u,i);t._OrtAddRunConfigEntry(r,d,p)!==0&&pe(`Can't set a run config entry: ${n} - ${u}.`)}),[r,i]}catch(s){throw r!==0&&t._OrtReleaseRunOptions(r),i.forEach(n=>t._free(n)),s}}}),no,so,oo,uo,ap,sg=P(()=>{Dt(),ja(),no=e=>{switch(e){case"disabled":return 0;case"basic":return 1;case"extended":return 2;case"all":return 99;default:throw new Error(`unsupported graph optimization level: ${e}`)}},so=e=>{switch(e){case"sequential":return 0;case"parallel":return 1;default:throw new Error(`unsupported execution mode: ${e}`)}},oo=e=>{e.extra||(e.extra={}),e.extra.session||(e.extra.session={});let t=e.extra.session;t.use_ort_model_bytes_directly||(t.use_ort_model_bytes_directly="1"),e.executionProviders&&e.executionProviders.some(r=>(typeof r=="string"?r:r.name)==="webgpu")&&(e.enableMemPattern=!1)},uo=(e,t,r)=>{for(let i of t){let a=typeof i=="string"?i:i.name;switch(a){case"webnn":if(a="WEBNN",typeof i!="string"){let n=i==null?void 0:i.deviceType;if(n){let u=Ee("deviceType",r),d=Ee(n,r);Se()._OrtAddSessionConfigEntry(e,u,d)!==0&&pe(`Can't set a session config entry: 'deviceType' - ${n}.`)}}break;case"webgpu":if(a="JS",typeof i!="string"){let n=i;if(n!=null&&n.preferredLayout){if(n.preferredLayout!=="NCHW"&&n.preferredLayout!=="NHWC")throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${n.preferredLayout}`);let u=Ee("preferredLayout",r),d=Ee(n.preferredLayout,r);Se()._OrtAddSessionConfigEntry(e,u,d)!==0&&pe(`Can't set a session config entry: 'preferredLayout' - ${n.preferredLayout}.`)}}break;case"wasm":case"cpu":continue;default:throw new Error(`not supported execution provider: ${a}`)}let s=Ee(a,r);Se()._OrtAppendExecutionProvider(e,s)!==0&&pe(`Can't append execution provider: ${a}.`)}},ap=e=>{let t=Se(),r=0,i=[],a=e||{};oo(a);try{let s=no(a.graphOptimizationLevel??"all"),n=so(a.executionMode??"sequential"),u=typeof a.logId=="string"?Ee(a.logId,i):0,d=a.logSeverityLevel??2;if(!Number.isInteger(d)||d<0||d>4)throw new Error(`log serverity level is not valid: ${d}`);let p=a.logVerbosityLevel??0;if(!Number.isInteger(p)||p<0||p>4)throw new Error(`log verbosity level is not valid: ${p}`);let f=typeof a.optimizedModelFilePath=="string"?Ee(a.optimizedModelFilePath,i):0;if(r=t._OrtCreateSessionOptions(s,!!a.enableCpuMemArena,!!a.enableMemPattern,n,!!a.enableProfiling,0,u,d,p,f),r===0&&pe("Can't create session options."),a.executionProviders&&uo(r,a.executionProviders,i),a.enableGraphCapture!==void 0){if(typeof a.enableGraphCapture!="boolean")throw new Error(`enableGraphCapture must be a boolean value: ${a.enableGraphCapture}`);let h=Ee("enableGraphCapture",i),l=Ee(a.enableGraphCapture.toString(),i);t._OrtAddSessionConfigEntry(r,h,l)!==0&&pe(`Can't set a session config entry: 'enableGraphCapture' - ${a.enableGraphCapture}.`)}if(a.freeDimensionOverrides)for(let[h,l]of Object.entries(a.freeDimensionOverrides)){if(typeof h!="string")throw new Error(`free dimension override name must be a string: ${h}`);if(typeof l!="number"||!Number.isInteger(l)||l<0)throw new Error(`free dimension override value must be a non-negative integer: ${l}`);let y=Ee(h,i);t._OrtAddFreeDimensionOverride(r,y,l)!==0&&pe(`Can't set a free dimension override: ${h} - ${l}.`)}return a.extra!==void 0&&Hr(a.extra,"",new WeakSet,(h,l)=>{let y=Ee(h,i),_=Ee(l,i);t._OrtAddSessionConfigEntry(r,y,_)!==0&&pe(`Can't set a session config entry: ${h} - ${l}.`)}),[r,i]}catch(s){throw r!==0&&t._OrtReleaseSessionOptions(r)!==0&&pe("Can't release session options."),i.forEach(n=>t._free(n)),s}}}),sr,It,Ut,Ka,jr,Za,Ya,ka,X=P(()=>{sr=e=>{switch(e){case"int8":return 3;case"uint8":return 2;case"bool":return 9;case"int16":return 5;case"uint16":return 4;case"int32":return 6;case"uint32":return 12;case"float16":return 10;case"float32":return 1;case"float64":return 11;case"string":return 8;case"int64":return 7;case"uint64":return 13;case"int4":return 22;case"uint4":return 21;default:throw new Error(`unsupported data type: ${e}`)}},It=e=>{switch(e){case 3:return"int8";case 2:return"uint8";case 9:return"bool";case 5:return"int16";case 4:return"uint16";case 6:return"int32";case 12:return"uint32";case 10:return"float16";case 1:return"float32";case 11:return"float64";case 8:return"string";case 7:return"int64";case 13:return"uint64";case 22:return"int4";case 21:return"uint4";default:throw new Error(`unsupported data type: ${e}`)}},Ut=(e,t)=>{let r=[-1,4,1,1,2,2,4,8,-1,1,2,8,4,8,-1,-1,-1,-1,-1,-1,-1,.5,.5][e],i=typeof t=="number"?t:t.reduce((a,s)=>a*s,1);return r>0?Math.ceil(i*r):void 0},Ka=e=>{switch(e){case"float16":return typeof Float16Array<"u"&&Float16Array.from?Float16Array:Uint16Array;case"float32":return Float32Array;case"uint8":return Uint8Array;case"int8":return Int8Array;case"uint16":return Uint16Array;case"int16":return Int16Array;case"int32":return Int32Array;case"bool":return Uint8Array;case"float64":return Float64Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"uint64":return BigUint64Array;default:throw new Error(`unsupported type: ${e}`)}},jr=e=>{switch(e){case"verbose":return 0;case"info":return 1;case"warning":return 2;case"error":return 3;case"fatal":return 4;default:throw new Error(`unsupported logging level: ${e}`)}},Za=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",Ya=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint64"||e==="int8"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",ka=e=>{switch(e){case"none":return 0;case"cpu":return 1;case"cpu-pinned":return 2;case"texture":return 3;case"gpu-buffer":return 4;case"ml-tensor":return 5;default:throw new Error(`unsupported data location: ${e}`)}}}),Qa,np=P(()=>{Fa(),Qa=async e=>{if(typeof e=="string"){let t=await fetch(e);if(!t.ok)throw new Error(`failed to load external data file: ${e}`);let r=t.headers.get("Content-Length"),i=r?parseInt(r,10):0;if(i<1073741824)return new Uint8Array(await t.arrayBuffer());{if(!t.body)throw new Error(`failed to load external data file: ${e}, no response body.`);let a=t.body.getReader(),s;try{s=new ArrayBuffer(i)}catch(u){if(u instanceof RangeError){let d=Math.ceil(i/65536);s=new WebAssembly.Memory({initial:d,maximum:d}).buffer}else throw u}let n=0;for(;;){let{done:u,value:d}=await a.read();if(u)break;let p=d.byteLength;new Uint8Array(s,n,p).set(d),n+=p}return new Uint8Array(s,0,i)}}else return e instanceof Blob?new Uint8Array(await e.arrayBuffer()):e instanceof Uint8Array?e:new Uint8Array(e)}}),lo,po,co,ho,Ja,fo,he,st=P(()=>{X(),lo=["V","I","W","E","F"],po=(e,t)=>{console.log(`[${lo[e]},${new Date().toISOString()}]${t}`)},Ja=(e,t)=>{co=e,ho=t},fo=(e,t)=>{let r=jr(e),i=jr(co);r>=i&&po(r,typeof t=="function"?t():t)},he=(...e)=>{ho&&fo(...e)}}),Xa,sp=P(()=>{X(),Xa=(e,t)=>new(Ka(t))(e)}),en=P(()=>{}),Ui,Or,Dr,mo,go,Wi,Sa,yo,op,og=P(()=>{st(),en(),Ui=new Map([[64,250],[128,200],[256,200],[512,200],[2048,230],[4096,200],[8192,50],[16384,50],[32768,50],[65536,50],[131072,50],[262144,50],[524288,50],[1048576,50],[2097152,30],[4194304,20],[8388608,10],[12582912,10],[16777216,10],[26214400,15],[33554432,22],[44236800,2],[58982400,6],[67108864,6],[134217728,6],[167772160,6]]),Or=[],Dr=e=>Math.ceil(Number(e)/16)*16,mo=e=>{for(let t=0;t<Or.length;t++){let r=Or[t];if(e<=r)return r}return Math.ceil(e/16)*16},go=1,Wi=()=>go++,Sa=async(e,t,r,i)=>{let a=Dr(r),s=e.device.createBuffer({size:a,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});try{let n=e.getCommandEncoder();e.endComputePass(),n.copyBufferToBuffer(t,0,s,0,a),e.flush(),await s.mapAsync(GPUMapMode.READ);let u=s.getMappedRange();if(i){let d=i();return d.set(new Uint8Array(u,0,r)),d}else return new Uint8Array(u.slice(0,r))}finally{s.destroy()}},yo=class{constructor(e){this.backend=e,this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.buffersPending=[],this.capturedPendingBuffers=new Map;for(let[t]of Ui)Or.push(t),this.freeBuffers.set(t,[]),this.freeUniformBuffers.set(t,[]);this.sessionCount=0}upload(e,t){let r=t.buffer,i=t.byteOffset,a=t.byteLength,s=Dr(a),n=this.storageCache.get(e);if(!n)throw new Error("gpu data for uploading does not exist");if(Number(n.originalSize)!==a)throw new Error(`inconsistent data size. gpu data size=${n.originalSize}, data size=${a}`);let u=this.backend.device.createBuffer({mappedAtCreation:!0,size:s,usage:GPUBufferUsage.MAP_WRITE|GPUBufferUsage.COPY_SRC}),d=u.getMappedRange();new Uint8Array(d).set(new Uint8Array(r,i,a)),u.unmap();let p=this.backend.device.createCommandEncoder();p.copyBufferToBuffer(u,0,n.gpuData.buffer,0,s),this.backend.device.queue.submit([p.finish()]),u.destroy(),he("verbose",()=>`[WebGPU] GpuDataManager.upload(id=${e})`)}memcpy(e,t){let r=this.storageCache.get(e);if(!r)throw new Error("source gpu data for memcpy does not exist");let i=this.storageCache.get(t);if(!i)throw new Error("destination gpu data for memcpy does not exist");if(r.originalSize!==i.originalSize)throw new Error("inconsistent source and destination gpu data size");let a=Dr(r.originalSize),s=this.backend.getCommandEncoder();this.backend.endComputePass(),s.copyBufferToBuffer(r.gpuData.buffer,0,i.gpuData.buffer,0,a)}registerExternalBuffer(e,t,r){let i;if(r){if(i=r[0],e===r[1])return he("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, buffer is the same, skip.`),i;if(this.backend.capturedCommandList.has(this.backend.currentSessionId))throw new Error(`Registering a different external buffer under graph capture mode is not supported yet.
             Please use the previous external buffer!`)}else i=Wi();return this.storageCache.set(i,{gpuData:{id:i,type:0,buffer:e},originalSize:t}),he("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, registered.`),i}unregisterExternalBuffer(e){e!==void 0&&(this.storageCache.delete(e),he("verbose",()=>`[WebGPU] GpuDataManager.unregisterExternalBuffer() => id=${e}`))}create(e,t=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST){let r=mo(e),i,a=(t&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE,s=(t&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM;if(a||s){let u=(a?this.freeBuffers:this.freeUniformBuffers).get(r);u?u.length>0?i=u.pop():i=this.backend.device.createBuffer({size:r,usage:t}):i=this.backend.device.createBuffer({size:r,usage:t})}else i=this.backend.device.createBuffer({size:r,usage:t});let n={id:Wi(),type:0,buffer:i};return this.storageCache.set(n.id,{gpuData:n,originalSize:Number(e)}),he("verbose",()=>`[WebGPU] GpuDataManager.create(size=${e}) => id=${n.id}`),n}get(e){var t;return(t=this.storageCache.get(e))==null?void 0:t.gpuData}release(e){let t=typeof e=="bigint"?Number(e):e,r=this.storageCache.get(t);if(!r){if(this.storageCache.size===0)return 0;throw new Error("releasing data does not exist")}return he("verbose",()=>`[WebGPU] GpuDataManager.release(id=${t}), gpuDataId=${r.gpuData.id}`),this.storageCache.delete(t),this.buffersPending.push(r.gpuData.buffer),r.originalSize}async download(e,t){let r=this.storageCache.get(Number(e));if(!r)throw new Error("data does not exist");await Sa(this.backend,r.gpuData.buffer,r.originalSize,t)}refreshPendingBuffers(){if(this.buffersPending.length!==0)if(this.backend.sessionStatus==="default"){for(let e of this.buffersPending){let t=Ui.get(e.size);if((e.usage&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE){let r=this.freeBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else if((e.usage&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM){let r=this.freeUniformBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else e.destroy()}this.buffersPending=[]}else{let e=this.capturedPendingBuffers.get(this.backend.currentSessionId);e||(e=[],this.capturedPendingBuffers.set(this.backend.currentSessionId,e));for(let t of this.buffersPending)e.push(t);this.buffersPending=[]}}dispose(){this.freeBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.freeUniformBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.capturedPendingBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.capturedPendingBuffers=new Map}onCreateSession(){this.sessionCount+=1}onReleaseSession(e){let t=this.capturedPendingBuffers.get(e);t&&(t.forEach(r=>{r.destroy()}),this.capturedPendingBuffers.delete(e)),this.sessionCount-=1,this.sessionCount===0&&(he("warning",()=>"[WebGPU] Clearing webgpu buffer cache"),this.storageCache.forEach(r=>{r.gpuData.buffer.destroy()}),this.storageCache=new Map)}},op=(...e)=>new yo(...e)}),_o,fe,ve=P(()=>{_o=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},fe=e=>new _o(e)}),bo,Lt,z,Kr,up,lp,dp,re=P(()=>{bo=class{static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},Lt=class{static calcShape(e,t,r=!1){let i=e.length,a=t.length;if(i===0)return t;if(a===0)return e;let s=Math.max(e.length,t.length),n=new Array(s);if(r){if(i<2||a<2)return;let u=bo.calcMatMulShape([e[i-2],e[i-1]],[t[a-2],t[a-1]]);if(u===void 0)return;[n[s-2],n[s-1]]=u}for(let u=r?3:1;u<=s;u++){let d=i-u<0?1:e[i-u],p=a-u<0?1:t[a-u];if(d!==p&&d>1&&p>1)return;let f=Math.max(d,p);if(d&&p)n[s-u]=Math.max(d,p);else{if(f>1)return;n[s-u]=0}}return n}static isValidBroadcast(e,t){let r=e.length,i=t.length;if(r>i)return!1;for(let a=1;a<=r;a++)if(e[r-a]!==1&&e[r-a]!==t[i-a])return!1;return!0}},z=class qr{static size(t){return qr.getSizeFromDimensionRange(t,0,t.length)}static convertShape(t,r=4){let i=t.length;if(i===0)return[];let a=new Array(i),s=i-1;for(;s>=0;){if(t[s]%r===0){a[s]=t[s]/r;break}if(r%t[s]!==0)throw new Error("cannot convert shape");a[s]=1,r/=t[s],s--}for(s--;s>=0;s--)a[s]=t[s];return a}static sizeFromDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return qr.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return qr.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(t,r,i){let a=1;for(let s=r;s<i;s++){if(t[s]<0)throw new Error("cannot get valid size from specified dimension range. Most likely the range contains negative values in them.");a*=Number(t[s])}return a}static computeStrides(t){let r=t.length;if(r===0)return[];if(r===1)return[1];let i=new Array(r);i[r-1]=1,i[r-2]=t[r-1];for(let a=r-3;a>=0;--a)i[a]=i[a+1]*t[a+1];return i}static normalizeAxis(t,r){if(t<-r&&t>=r)throw new Error("unsupported axis for this operation.");return t<0?t+r:t}static normalizeAxes(t,r){return t.map(i=>this.normalizeAxis(i,r??t.length))}static sortBasedOnPerm(t,r){return r?r.map(i=>t[i]):t.slice().reverse()}static padShape(t,r){let i=t.length;return t.map((a,s)=>a+r[s]+r[s+i])}static areEqual(t,r){return t.length!==r.length?!1:t.every((i,a)=>i===r[a])}},Kr=class or{static adjustPoolAttributes(t,r,i,a,s,n){if(!t&&i.length!==r.length-2)throw new Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(t)for(let u=0;u<r.length-2;u++)u>=i.length?i.push(r[u+2]):i[u]=r[u+2];for(let u=0;u<i.length;u++)if(u<a.length){if(a[u]<0)throw new Error("strides should be greater than or equal to 1")}else a.push(1);for(let u=0;u<i.length;u++)if(u<s.length){if(s[u]<0)throw new Error("dilations should be greater than or equal to 1")}else s.push(1);for(let u=0;u<i.length*2;u++)if(u<n.length){if(n[u]<0)throw new Error("pad should be greater than or equal to 1")}else n.push(0);for(let u=0;u<i.length;u++){if(i[u]<=0)throw new Error("kernel shapes need to be greater than 0");if(n[u]>=i[u]||n[u+i.length]>=i[u])throw new Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,i,a,s,n,u){if(u){if(s.length!==2*(t.length-2))throw new Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw new Error("length of strides should be the length of data dimensions");if(a.length!==t.length-2)throw new Error("length of kernel shapes should be the length of data dimensions");for(let d=0;d<t.length-2;d++)or.adjustPadAndReturnShape(t[d+(n?1:2)],r[d],i[d],a[d],s,d,d+t.length-2,u)}}static computePoolOutputShape(t,r,i,a,s,n,u){if(r.length<=0)throw new Error("input shape must be of size greater than 0");let d=[r[0],r[1]];return or.computeShapeHelper(t,r,d,i,a,s,n,u),d}static computeConvOutputShape(t,r,i,a,s,n,u){if(t.length<=0||r.length<=0)throw new Error("invalid input tensor dims or invalid filter tensor dims");let d=[t[0],r[0]];return or.computeShapeHelper(!1,t,d,i,a,s,n,u),d}static computeShapeHelper(t,r,i,a,s,n,u,d){if(t)for(let p=0;p<r.length-2;p++)i.push(1);else for(let p=0;p<r.length-2;p++)i.push(or.adjustPadAndReturnShape(r[p+2],a[p],s[p],n[p],u,p,p+r.length-2,d))}static adjustPadAndReturnShape(t,r,i,a,s,n,u,d){let p=i*(a-1)+1;if(d&&d!=="NOTSET")switch(d){case"VALID":return s[n]=0,s[u]=0,Math.floor((t-p)/r+1);case"SAME_LOWER":case"SAME_UPPER":if(i!==1)throw new Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let f=((t+r-1)/r-1)*r+a-t;return s[n]=Math.floor(d==="SAME_LOWER"?(f+1)/2:f/2),s[u]=f-s[n],Math.floor((t+f-a)/r+1)}default:throw new Error("Unsupported AutoPad type")}else return Math.floor((t+s[n]+s[u]-p)/r+1)}},up=class{static getShapeOfGemmResult(e,t,r,i,a){if(e.length!==2||r.length!==2)throw new Error("shape need to be of size 2");let s,n,u;t?(s=e[1],n=e[0]):(s=e[0],n=e[1]);let d=-1;if(i?(u=r[0],d=1):(u=r[1],d=0),r[d]!==n)throw new Error("dimension mismatch");if(s<=0||u<=0||n<=0)throw new Error("invalid shape specified");if(a&&!Lt.isValidBroadcast(a,[s,u]))throw new Error("gemm: invalid bias shape for broadcast");return[s,u,n]}},lp=-34028234663852886e22,dp=34028234663852886e22}),Ft,Rr,Te,Ie,K,be,Ta,Wt,yt,j,Jt,R,H,pp,tn,wo,cp,ie=P(()=>{X(),re(),Ft=64,Rr=(e,t)=>{if(t===3)throw new Error("vec3 has same alignment as vec4, use vec4 instead");switch(Number(e)){case 10:return t>1?`vec${t}<f16>`:"f16";case 1:return t>1?`vec${t}<f32>`:"f32";case 6:return t>1?`vec${t}<i32>`:"i32";case 12:return t>1?`vec${t}<u32>`:"u32";case 7:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","i32"];case 13:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","u32"];case 9:if(t!==4)throw new Error("bool must be vec4");return["u32","vec4<bool>"];case 22:return"i32";case 21:return"u32";default:throw new Error(`Unknown data type: ${e}`)}},Te=(e,t=1)=>{let r=Rr(e,t);return typeof r=="string"?r:r[0]},Ie=(e,t=1)=>{let r=Rr(e,t);return typeof r=="string"?r:r[1]},K=(...e)=>{let t=[];return e.forEach(r=>{r.length!==0&&t.push({type:12,data:r},{type:12,data:z.computeStrides(r)})}),t},be=e=>e%4===0?4:e%2===0?2:1,Ta=(e="f32",t,r="0")=>!t||t===1?`${e}(${r})`:`vec${t}<${e}>(${r})`,Wt=(e,t,r)=>e==="f32"?r:t===1?`f32(${r})`:`vec${t}<f32>(${r})`,yt=(e,t)=>t===4?`(${e}.x + ${e}.y + ${e}.z + ${e}.w)`:t===2?`(${e}.x + ${e}.y)`:t===3?`(${e}.x + ${e}.y + ${e}.z)`:e,j=(e,t,r,i)=>e.startsWith("uniforms.")&&r>4?typeof t=="string"?i==="f16"?`${e}[(${t}) / 8][(${t}) % 8 / 4][(${t}) % 8 % 4]`:`${e}[(${t}) / 4][(${t}) % 4]`:i==="f16"?`${e}[${Math.floor(t/8)}][${Math.floor(t%8/4)}][${t%8%4}]`:`${e}[${Math.floor(t/4)}][${t%4}]`:r>1?`${e}[${t}]`:e,Jt=(e,t,r,i,a)=>{let s=typeof r=="number",n=s?r:r.length,u=[...new Array(n).keys()],d=n<2?"u32":n<=4?`vec${n}<u32>`:`array<u32, ${n}>`,p=Rr(t,a),f=typeof p=="string"?p:p[1],h=typeof p=="string"?p:p[0],l={indices:d,value:f,storage:h,tensor:t},y=N=>typeof N=="string"?N:`${N}u`,_={offsetToIndices:!1,indicesToOffset:!1,broadcastedIndicesToOffset:!1,set:!1,setByIndices:!1,get:!1,getByIndices:!1},b=s?"uniforms.":"",v=`${b}${e}_shape`,x=`${b}${e}_strides`,$="";for(let N=0;N<n-1;N++)$+=`
    let dim${N} = current / ${j(x,N,n)};
    let rest${N} = current % ${j(x,N,n)};
    indices[${N}] = dim${N};
    current = rest${N};
    `;$+=`indices[${n-1}] = current;`;let S=n<2?"":`
  fn o2i_${e}(offset: u32) -> ${l.indices} {
    var indices: ${l.indices};
    var current = offset;
    ${$}
    return indices;
  }`,k=N=>(_.offsetToIndices=!0,n<2?N:`o2i_${e}(${N})`),T=[];if(n>=2)for(let N=n-1;N>=0;N--)T.push(`${j(x,N,n)} * (indices[${N}])`);let E=n<2?"":`
  fn i2o_${e}(indices: ${l.indices}) -> u32 {
    return ${T.join("+")};
  }`,I=N=>(_.indicesToOffset=!0,n<2?N:`i2o_${e}(${N})`),D=(...N)=>n===0?"0u":`${l.indices}(${N.map(y).join(",")})`,M=(N,q)=>n<2?`${N}`:`${j(N,q,n)}`,W=(N,q,se)=>n<2?`${N}=${se};`:`${j(N,q,n)}=${se};`,ee={},te=(N,q)=>{_.broadcastedIndicesToOffset=!0;let se=`${q.name}broadcastedIndicesTo${e}Offset`;if(se in ee)return`${se}(${N})`;let we=[];for(let Ae=n-1;Ae>=0;Ae--){let ke=q.indicesGet("outputIndices",Ae+q.rank-n);we.push(`${M(x,Ae)} * (${ke} % ${M(v,Ae)})`)}return ee[se]=`fn ${se}(outputIndices: ${q.type.indices}) -> u32 {
             return ${we.length>0?we.join("+"):"0u"};
           }`,`${se}(${N})`},U=(N,q)=>(()=>{if(l.storage===l.value)return`${e}[${N}]=${q};`;if(l.storage==="vec2<u32>"&&l.value==="i32")return`${e}[${N}]=vec2<u32>(u32(${q}), select(0u, 0xFFFFFFFFu, ${q} < 0));`;if(l.storage==="vec2<u32>"&&l.value==="u32")return`${e}[${N}]=vec2<u32>(u32(${q}), 0u);`;if(l.storage==="u32"&&l.value==="vec4<bool>")return`${e}[${N}]=dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(${q}));`;throw new Error(`not supported combination of storage type ${l.storage} and value type ${l.value} yet`)})(),ae=N=>(()=>{if(l.storage===l.value)return`${e}[${N}]`;if(l.storage==="vec2<u32>"&&l.value==="i32")return`i32(${e}[${N}].x)`;if(l.storage==="vec2<u32>"&&l.value==="u32")return`u32(${e}[${N}].x)`;if(l.storage==="u32"&&l.value==="vec4<bool>")return`vec4<bool>(bool(${e}[${N}] & 0xFFu), bool(${e}[${N}] & 0xFF00u), bool(${e}[${N}] & 0xFF0000u), bool(${e}[${N}] & 0xFF000000u))`;throw new Error(`not supported combination of storage type ${l.storage} and value type ${l.value} yet`)})(),F=n<2?"":`
  fn get_${e}ByIndices(indices: ${l.indices}) -> ${f} {
    return ${ae(`i2o_${e}(indices)`)};
  }`,G=n<2?"":(()=>{let N=u.map(se=>`d${se}: u32`).join(", "),q=u.map(se=>`d${se}`).join(", ");return`
  fn get_${e}(${N}) -> ${f} {
    return get_${e}ByIndices(${D(q)});
  }`})(),de=(...N)=>{if(N.length!==n)throw new Error(`indices length must be ${n}`);let q=N.map(y).join(",");return n===0?ae("0u"):n===1?ae(q[0]):(_.get=!0,_.getByIndices=!0,_.indicesToOffset=!0,`get_${e}(${q})`)},J=N=>n<2?ae(N):(_.getByIndices=!0,_.indicesToOffset=!0,`get_${e}ByIndices(${N})`),Z=n<2?"":`
  fn set_${e}ByIndices(indices: ${l.indices}, value: ${f}) {
    ${U(`i2o_${e}(indices)`,"value")}
  }`,ue=n<2?"":(()=>{let N=u.map(se=>`d${se}: u32`).join(", "),q=u.map(se=>`d${se}`).join(", ");return`
  fn set_${e}(${N}, value: ${f}) {
    set_${e}ByIndices(${D(q)}, value);
  }`})();return{impl:()=>{let N=[],q=!1;return _.offsetToIndices&&(N.push(S),q=!0),_.indicesToOffset&&(N.push(E),q=!0),_.broadcastedIndicesToOffset&&(Object.values(ee).forEach(se=>N.push(se)),q=!0),_.set&&(N.push(ue),q=!0),_.setByIndices&&(N.push(Z),q=!0),_.get&&(N.push(G),q=!0),_.getByIndices&&(N.push(F),q=!0),!s&&q&&N.unshift(`const ${v} = ${l.indices}(${r.join(",")});`,`const ${x} = ${l.indices}(${z.computeStrides(r).join(",")});`),N.join(`
`)},type:l,offsetToIndices:k,indicesToOffset:I,broadcastedIndicesToOffset:te,indices:D,indicesGet:M,indicesSet:W,set:(...N)=>{if(N.length!==n+1)throw new Error(`indices length must be ${n}`);let q=N[n];if(typeof q!="string")throw new Error("value must be string");let se=N.slice(0,n).map(y).join(",");return n===0?U("0u",q):n===1?U(se[0],q):(_.set=!0,_.setByIndices=!0,_.indicesToOffset=!0,`set_${e}(${se}, ${q})`)},setByOffset:U,setByIndices:(N,q)=>n<2?U(N,q):(_.setByIndices=!0,_.indicesToOffset=!0,`set_${e}ByIndices(${N}, ${q});`),get:de,getByOffset:ae,getByIndices:J,usage:i,name:e,strides:x,shape:v,rank:n}},R=(e,t,r,i=1)=>Jt(e,t,r,"input",i),H=(e,t,r,i=1)=>Jt(e,t,r,"output",i),pp=(e,t,r)=>Jt(e,t,r,"atomicOutput",1),tn=(e,t,r,i=1)=>Jt(e,t,r,"internal",i),wo=class{constructor(e,t){this.normalizedDispatchGroup=e,this.limits=t,this.internalVariables=[],this.variables=[],this.uniforms=[],this.variableIndex=0}guardAgainstOutOfBoundsWorkgroupSizes(e){return`if (global_idx >= ${typeof e=="number"?`${e}u`:e}) { return; }`}mainStart(e=Ft){let t=typeof e=="number"?e:e[0],r=typeof e=="number"?1:e[1],i=typeof e=="number"?1:e[2];if(t>this.limits.maxComputeWorkgroupSizeX||r>this.limits.maxComputeWorkgroupSizeY||i>this.limits.maxComputeWorkgroupSizeZ)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup size [${this.limits.maxComputeWorkgroupSizeX}, ${this.limits.maxComputeWorkgroupSizeY}, ${this.limits.maxComputeWorkgroupSizeZ}].`);if(t*r*i>this.limits.maxComputeInvocationsPerWorkgroup)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup invocations ${this.limits.maxComputeInvocationsPerWorkgroup}.`);let a=this.normalizedDispatchGroup[1]===1&&this.normalizedDispatchGroup[2]===1,s=a?`@builtin(global_invocation_id) global_id : vec3<u32>,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(local_invocation_id) local_id : vec3<u32>`:`@builtin(global_invocation_id) global_id : vec3<u32>,
                                             @builtin(local_invocation_id) local_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(num_workgroups) num_workgroups : vec3<u32>`,n=a?`let global_idx = global_id.x;
         let workgroup_index = workgroup_id.x;`:`let workgroup_index = workgroup_id.z * num_workgroups[0] * num_workgroups[1] +
             workgroup_id.y * num_workgroups[0] + workgroup_id.x;
         let global_idx = workgroup_index * ${t*r*i}u + local_idx;`;return`@compute @workgroup_size(${t}, ${r}, ${i})
  fn main(${s}) {
    ${n}
  `}appendVariableUniforms(e){e.rank!==0&&(e.shape.startsWith("uniforms.")&&this.uniforms.push({name:e.shape.replace("uniforms.",""),type:"u32",length:e.rank}),e.strides.startsWith("uniforms.")&&this.uniforms.push({name:e.strides.replace("uniforms.",""),type:"u32",length:e.rank}))}declareVariable(e,t){if(e.usage==="internal")throw new Error("cannot use internal variable with declareVariable(). use registerInternalVariables() instead.");this.variables.push(e),this.appendVariableUniforms(e);let r=e.usage==="input"?"read":"read_write",i=e.usage==="atomicOutput"?"atomic<i32>":e.type.storage;return`@group(0) @binding(${t}) var<storage, ${r}> ${e.name}: array<${i}>;`}declareVariables(...e){return e.map(t=>this.declareVariable(t,this.variableIndex++)).join(`
`)}registerInternalVariable(e){if(e.usage!=="internal")throw new Error("cannot use input or output variable with registerInternalVariable(). use declareVariables() instead.");this.internalVariables.push(e),this.appendVariableUniforms(e)}registerInternalVariables(...e){return e.forEach(t=>this.registerInternalVariable(t)),this}registerUniform(e,t,r=1){return this.uniforms.push({name:e,type:t,length:r}),this}registerUniforms(e){return this.uniforms=this.uniforms.concat(e),this}uniformDeclaration(){if(this.uniforms.length===0)return"";let e=[];for(let{name:t,type:r,length:i}of this.uniforms)if(i&&i>4)r==="f16"?e.push(`@align(16) ${t}:array<mat2x4<${r}>, ${Math.ceil(i/8)}>`):e.push(`${t}:array<vec4<${r}>, ${Math.ceil(i/4)}>`);else{let a=i==null||i===1?r:`vec${i}<${r}>`;e.push(`${t}:${a}`)}return`
      struct Uniforms { ${e.join(", ")} };
      @group(0) @binding(${this.variableIndex}) var<uniform> uniforms: Uniforms;`}get additionalImplementations(){return this.uniformDeclaration()+this.variables.map(e=>e.impl()).join(`
`)+this.internalVariables.map(e=>e.impl()).join(`
`)}get variablesInfo(){if(this.uniforms.length===0)return;let e=t=>[12,10,1,6][["u32","f16","f32","i32"].indexOf(t)];return this.uniforms.map(t=>[e(t.type),t.length??1])}},cp=(e,t)=>new wo(e,t)}),$o,qi,vo,xo,ko,So,Pe,hp,fp,bt=P(()=>{X(),re(),ve(),ie(),$o=(e,t)=>{if(!e||e.length!==1)throw new Error("Transpose requires 1 input.");if(t.length!==0&&t.length!==e[0].dims.length)throw new Error(`perm size ${t.length} does not match input rank ${e[0].dims.length}`)},qi=(e,t)=>t.length!==0?t:[...new Array(e).keys()].reverse(),vo=(e,t)=>z.sortBasedOnPerm(e,qi(e.length,t)),xo=(e,t,r,i)=>{let a=`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`;for(let s=0;s<t;++s)a+=`a[${e[s]}]=i[${s}];`;return a+="return a;}"},ko=(e,t)=>{let r=[],i=[];for(let a=0;a<e.length;++a)e[a]!==1&&r.push(e[a]),e[t[a]]!==1&&i.push(t[a]);return{newShape:r,newPerm:i}},So=(e,t)=>{let r=0;for(let i=0;i<e.length;++i)if(t[e[i]]!==1){if(e[i]<r)return!1;r=e[i]}return!0},Pe=(e,t)=>{let r=e.dataType,i=e.dims.length,a=qi(i,t),s=vo(e.dims,a),n=e.dims,u=s,d=i<2||So(a,e.dims),p;if(d)return p=_=>{let b=R("input",r,n,4),v=H("output",r,u,4);return`
  ${_.registerUniform("output_size","u32").declareVariables(b,v)}
  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    output[global_idx] = input[global_idx];
  }`},{name:"TransposeCopy",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let _=z.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(_/64/4)},programUniforms:[{type:12,data:Math.ceil(_/4)}]}},getShaderSource:p};let{newShape:f,newPerm:h}=ko(e.dims,a),l=z.areEqual(h,[2,3,1]),y=z.areEqual(h,[3,1,2]);if(f.length===2||l||y){n=l?[f[0],f[1]*f[2]]:y?[f[0]*f[1],f[2]]:f,u=[n[1],n[0]];let _=16;return p=b=>{let v=R("a",r,n.length),x=H("output",r,u.length);return`
  ${b.registerUniform("output_size","u32").declareVariables(v,x)}
  var<workgroup> tile : array<array<${x.type.value}, ${_+1}>, ${_}>;
  ${b.mainStart([_,_,1])}
    let stride = (uniforms.output_shape[1] - 1) / ${_} + 1;
    let workgroup_id_x = workgroup_index % stride;
    let workgroup_id_y = workgroup_index / stride;
    let input_col = workgroup_id_y * ${_}u + local_id.x;
    let input_row = workgroup_id_x * ${_}u + local_id.y;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y][local_id.x] = ${v.getByIndices(`${v.type.indices}(input_row, input_col)`)};
    }
    workgroupBarrier();

    let output_col = workgroup_id_x * ${_}u + local_id.x;
    let output_row = workgroup_id_y * ${_}u + local_id.y;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      ${x.setByIndices(`${x.type.indices}(output_row, output_col)`,"tile[local_id.x][local_id.y]")}
    }
  }`},{name:"TransposeShared",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let b=z.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(u[1]/_),y:Math.ceil(u[0]/_)},programUniforms:[{type:12,data:b},...K(n,u)]}},getShaderSource:p}}return p=_=>{let b=R("a",r,n.length),v=H("output",r,u.length);return`
  ${_.registerUniform("output_size","u32").declareVariables(b,v)}

  ${xo(a,i,b,v)}

  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${v.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${v.setByOffset("global_idx",b.getByIndices("aIndices"))}
  }`},{name:"Transpose",shaderCache:{hint:`${t}`,inputDependencies:["rank"]},getRunData:()=>{let _=z.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:[{type:12,data:_},...K(n,u)]}},getShaderSource:p}},hp=(e,t)=>{$o(e.inputs,t.perm),e.compute(Pe(e.inputs[0],t.perm))},fp=e=>fe({perm:e.perm})}),To,Co,Eo,Io,zo,Ao,Oo,Do,Ro,Bo,We,mp,gp,yp,_p,bp,wp,$p,vp,xp,kp,ug=P(()=>{X(),re(),ie(),rn(),bt(),To={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate * candidate",logSumExp:"bestValue + exp(candidate)",l1:"bestValue + abs(candidate)",l2:"bestValue + candidate * candidate",logSum:"bestValue + candidate"},Co={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate",logSumExp:"bestValue + candidate",l1:"bestValue + candidate",l2:"bestValue + candidate",logSum:"bestValue + candidate"},Eo={max:"_A[offset]",min:"_A[offset]",mean:"0",sum:"0",prod:"1",sumSquare:"0",logSumExp:"0",l1:"0",l2:"0",logSum:"0"},Io={max:"bestValue",min:"bestValue",sum:"bestValue",prod:"bestValue",sumSquare:"bestValue",logSumExp:"log(bestValue)",l1:"bestValue",l2:"sqrt(bestValue)",logSum:"log(bestValue)"},zo=(e,t)=>{let r=[];for(let i=t-e;i<t;++i)r.push(i);return r},Ao=(e,t)=>{let r=[],i=e.length;for(let s=0;s<i;s++)t.indexOf(s)===-1&&r.push(e[s]);let a=t.map(s=>e[s]);return[r,a]},Oo=(e,t)=>{let r=e.length+t.length,i=[],a=0;for(let s=0;s<r;s++)t.indexOf(s)===-1?i.push(e[a++]):i.push(1);return i},Do=(e,t)=>{for(let r=0;r<e.length;++r)if(e[e.length-r-1]!==t-1-r)return!1;return!0},Ro=(e,t)=>{let r=[];if(!Do(e,t)){for(let i=0;i<t;++i)e.indexOf(i)===-1&&r.push(i);e.forEach(i=>r.push(i))}return r},Bo=(e,t,r,i,a,s,n)=>{let u=r[0].dims,d=z.size(s),p=z.size(n),f=R("_A",r[0].dataType,u),h=H("output",a,s),l=64;d===1&&(l=256);let y=`
          var<workgroup> aBestValues : array<f32, ${l}>;
       `,_=b=>`
        ${b.registerUniform("reduceSize","u32").declareVariables(f,h)}
        ${y}
        fn DIV_CEIL(a : u32, b : u32) -> u32 {
          return ((a - 1u) / b + 1u);
         }
         ${b.mainStart(l)}

          let outputIndex = global_idx / ${l};
          let offset = outputIndex * uniforms.reduceSize;

          var bestValue = f32(${Eo[i]});
          let Length = uniforms.reduceSize;
          for (var k = local_idx; k < Length; k = k + ${l}) {
           let candidate = f32(${f.getByOffset("offset + k")});
           bestValue = ${To[i]};
          }
          aBestValues[local_idx] = bestValue;
          workgroupBarrier();

         var reduceSize = min(Length, ${l}u);
         for (var currentSize = reduceSize / 2u; reduceSize > 1u;
             currentSize = reduceSize / 2u) {
           let interval = DIV_CEIL(reduceSize, 2u);
           if (local_idx < currentSize) {
            let candidate = aBestValues[local_idx + interval];
            bestValue = ${Co[i]};
            aBestValues[local_idx] = bestValue;
           }
           reduceSize = interval;
           workgroupBarrier();
         }

         if (local_idx == 0u) {
          ${h.setByOffset("outputIndex",`${i==="mean"?`${h.type.storage}(bestValue / f32(uniforms.reduceSize))`:`${h.type.storage}(${Io[i]})`}`)};
         }
        }`;return{name:e,shaderCache:{hint:`${t};${l}`,inputDependencies:["type"]},getShaderSource:_,getRunData:()=>({outputs:[{dims:s,dataType:a}],dispatchGroup:{x:d},programUniforms:[{type:12,data:p}]})}},We=(e,t,r,i)=>{let a=e.inputs.length===1?r:Ca(e.inputs,r),s=a.axes;s.length===0&&!a.noopWithEmptyAxes&&(s=e.inputs[0].dims.map((y,_)=>_));let n=z.normalizeAxes(s,e.inputs[0].dims.length),u=n,d=e.inputs[0],p=Ro(u,e.inputs[0].dims.length);p.length>0&&(d=e.compute(Pe(e.inputs[0],p),{inputs:[0],outputs:[-1]})[0],u=zo(u.length,d.dims.length));let[f,h]=Ao(d.dims,u),l=f;a.keepDims&&(l=Oo(f,n)),e.compute(Bo(t,a.cacheKey,[d],i,e.inputs[0].dataType,l,h),{inputs:[d]})},mp=(e,t)=>{We(e,"ReduceMeanShared",t,"mean")},gp=(e,t)=>{We(e,"ReduceL1Shared",t,"l1")},yp=(e,t)=>{We(e,"ReduceL2Shared",t,"l2")},_p=(e,t)=>{We(e,"ReduceLogSumExpShared",t,"logSumExp")},bp=(e,t)=>{We(e,"ReduceMaxShared",t,"max")},wp=(e,t)=>{We(e,"ReduceMinShared",t,"min")},$p=(e,t)=>{We(e,"ReduceProdShared",t,"prod")},vp=(e,t)=>{We(e,"ReduceSumShared",t,"sum")},xp=(e,t)=>{We(e,"ReduceSumSquareShared",t,"sumSquare")},kp=(e,t)=>{We(e,"ReduceLogSumShared",t,"logSum")}}),qe,No,Zr,Ca,Le,Mo,Po,Vo,Uo,Wo,qo,Lo,Fo,Go,Ho,Fe,Sp,Tp,Cp,Ep,Ip,zp,Ap,Op,Dp,Rp,rn=P(()=>{X(),re(),ve(),ie(),ug(),qe=e=>{if(!e||e.length===0||e.length>2)throw new Error("Reduce op requires 1 or 2 inputs.");if(e.length===2&&e[1].dims.length!==1)throw new Error("Invalid axes input dims.")},No=e=>["","",`var value = ${e.getByIndices("input_indices")};`,""],Zr=(e,t,r,i,a,s,n=!1,u=!1)=>{let d=[],p=r[0].dims,f=p.length,h=z.normalizeAxes(a,f),l=!u&&h.length===0;p.forEach((b,v)=>{l||h.indexOf(v)>=0?n&&d.push(1):d.push(b)});let y=d.length,_=z.size(d);return{name:e,shaderCache:t,getShaderSource:b=>{let v=[],x=R("_A",r[0].dataType,f),$=H("output",s,y),S=i(x,$,h),k=S[2];for(let T=0,E=0;T<f;T++)l||h.indexOf(T)>=0?(n&&E++,k=`for(var j${T}: u32 = 0; j${T} < ${p[T]}; j${T}++) {
                  ${S[2].includes("last_index")?`let last_index = j${T};`:""}
                  ${x.indicesSet("input_indices",T,`j${T}`)}
                  ${k}
                }`):(v.push(`${x.indicesSet("input_indices",T,$.indicesGet("output_indices",E))};`),E++);return`

        ${b.registerUniform("output_size","u32").declareVariables(x,$)}

        ${b.mainStart()}
          ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          var input_indices: ${x.type.indices};
          let output_indices = ${$.offsetToIndices("global_idx")};

          ${v.join(`
`)}
          ${S[0]}       // init ops for reduce max/min
          ${S[1]}
          ${k}
          ${S[3]}
          ${S.length===4?$.setByOffset("global_idx","value"):S.slice(4).join(`
`)}
        }`},getRunData:()=>({outputs:[{dims:d,dataType:s}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:[{type:12,data:_},...K(p,d)]})}},Ca=(e,t)=>{let r=[];return e[1].dims[0]>0&&e[1].getBigInt64Array().forEach(i=>r.push(Number(i))),fe({axes:r,keepDims:t.keepDims,noopWithEmptyAxes:t.noopWithEmptyAxes})},Le=(e,t,r,i)=>{let a=e.inputs,s=a.length===1?r:Ca(a,r);e.compute(Zr(t,{hint:s.cacheKey,inputDependencies:["rank"]},[a[0]],s.noopWithEmptyAxes&&s.axes.length===0?No:i,s.axes,a[0].dataType,s.keepDims,s.noopWithEmptyAxes),{inputs:[0]})},Mo=(e,t)=>{qe(e.inputs),Le(e,"ReduceLogSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,"value = log(value);"])},Po=(e,t)=>{qe(e.inputs),Le(e,"ReduceL1",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += abs(${r.getByIndices("input_indices")});`,""])},Vo=(e,t)=>{qe(e.inputs),Le(e,"ReduceL2",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += (t * t);`,"value = sqrt(value);"])},Uo=(e,t)=>{qe(e.inputs),Le(e,"ReduceLogSumExp",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += exp(${r.getByIndices("input_indices")});`,"value = log(value);"])},Wo=(e,t)=>{qe(e.inputs),Le(e,"ReduceMax",t,(r,i,a)=>{let s=[];for(let n=0;n<r.rank;n++)(a.indexOf(n)>=0||a.length===0)&&s.push(r.indicesSet("input_indices",n,0));return[`${s.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = max(value, ${r.getByIndices("input_indices")});`,""]})},qo=(e,t)=>{qe(e.inputs),Le(e,"ReduceMean",t,(r,i,a)=>{let s=1;for(let n=0;n<r.rank;n++)(a.indexOf(n)>=0||a.length===0)&&(s*=e.inputs[0].dims[n]);return["var sum = f32(0);","",`sum += f32(${r.getByIndices("input_indices")});`,`let value = ${i.type.value}(sum / ${s});`]})},Lo=(e,t)=>{qe(e.inputs),Le(e,"ReduceMin",t,(r,i,a)=>{let s=[];for(let n=0;n<r.rank;n++)(a.indexOf(n)>=0||a.length===0)&&s.push(`input_indices[${n}] = 0;`);return[`${s.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = min(value, ${r.getByIndices("input_indices")});`,""]})},Fo=(e,t)=>{qe(e.inputs),Le(e,"ReduceProd",t,(r,i)=>[`var value = ${i.type.storage}(1);`,"",`value *= ${r.getByIndices("input_indices")};`,""])},Go=(e,t)=>{qe(e.inputs),Le(e,"ReduceSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,""])},Ho=(e,t)=>{qe(e.inputs),Le(e,"ReduceSumSquare",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += t * t;`,""])},Fe=(e,t,r)=>{if(t.length===0)return r;let i=1,a=1;for(let s=0;s<t.length;s++)t.indexOf(s)===-1?i*=e[s]:a*=e[s];return a<32&&i>1024},Sp=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?qo(e,t):mp(e,t)},Tp=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Po(e,t):gp(e,t)},Cp=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Vo(e,t):yp(e,t)},Ep=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Uo(e,t):_p(e,t)},Ip=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Wo(e,t):bp(e,t)},zp=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Lo(e,t):wp(e,t)},Ap=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Fo(e,t):$p(e,t)},Op=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Go(e,t):vp(e,t)},Dp=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Ho(e,t):xp(e,t)},Rp=(e,t)=>{Fe(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Mo(e,t):kp(e,t)}}),Li,Bp,Np,Ea,lg=P(()=>{X(),ve(),rn(),Li=e=>{if(!e||e.length===0||e.length>2)throw new Error("ArgMinMaxOp op requires 1 or 2 inputs.");if(e[0].dataType!==1)throw new Error("Invalid input type.")},Bp=(e,t)=>{Li(e.inputs);let r=(i,a,s)=>{let n=[];for(let u=0;u<i.rank;u++)(s.indexOf(u)>=0||s.length===0)&&n.push(`input_indices[${u}] = 0;`);return[`${n.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?"<=":"<"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(Zr("ArgMin",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},Np=(e,t)=>{Li(e.inputs);let r=(i,a,s)=>{let n=[];for(let u=0;u<i.rank;u++)(s.indexOf(u)>=0||s.length===0)&&n.push(`input_indices[${u}] = 0;`);return[`${n.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?">=":">"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(Zr("argMax",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},Ea=e=>fe(e)}),jo,Br,Ko,Zo,Yo,pr,Qo,Mp,an=P(()=>{X(),re(),en(),ie(),jo=(e,t)=>{let r=e[0],i=e[1],a=e[2],s=e[3],n=e[4],u=e[5];if(n&&u)throw new Error("Attention cannot have both past and attention_bias");if(r.dims.length!==3)throw new Error('Input "input" must have 3 dimensions');let d=r.dims[0],p=r.dims[1],f=r.dims[2];if(a.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimensions');if(i.dims.length!==2)throw new Error('Input "weights" is expected to have 2 dimensions');if(i.dims[0]!==f)throw new Error("Input 1 dimension 0 should have same length as dimension 2 of input 0");if(a.dims[0]!==i.dims[1])throw new Error('Input "bias" dimension 0 should have same length as dimension 1 of input "weights"');let h=a.dims[0]/3,l=h,y=l;if(t.qkvHiddenSizes.length>0){if(t.qkvHiddenSizes.length!==3)throw new Error("qkv_hidden_sizes attribute should have 3 elements");for(let S of t.qkvHiddenSizes)if(S%t.numHeads!==0)throw new Error("qkv_hidden_sizes should be divisible by num_heads");h=t.qkvHiddenSizes[0],l=t.qkvHiddenSizes[1],y=t.qkvHiddenSizes[2]}let _=p;if(h!==l)throw new Error("qkv_hidden_sizes first element should be same as the second");if(a.dims[0]!==h+l+y)throw new Error('Input "bias" dimension 0 should have same length as sum of Q/K/V hidden sizes');let b=0;if(n){if(l!==y)throw new Error('Input "past" expect k_hidden_size == v_hidden_size');if(n.dims.length!==5)throw new Error('Input "past" must have 5 dimensions');if(n.dims[0]!==2)throw new Error('Input "past" first dimension must be 2');if(n.dims[1]!==d)throw new Error('Input "past" second dimension must be batch_size');if(n.dims[2]!==t.numHeads)throw new Error('Input "past" third dimension must be num_heads');if(n.dims[4]!==l/t.numHeads)throw new Error('Input "past" fifth dimension must be k_hidden_size / num_heads');t.pastPresentShareBuffer||(b=n.dims[3])}let v=_+b,x=-1,$=0;if(s)throw new Error("Mask not supported");if(n)throw new Error("past is not supported");if(u){if(u.dims.length!==4)throw new Error('Input "attention_bias" must have 4 dimensions');if(u.dims[0]!==d||u.dims[1]!==t.numHeads||u.dims[2]!==p||u.dims[3]!==v)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:d,sequenceLength:p,pastSequenceLength:b,kvSequenceLength:_,totalSequenceLength:v,maxSequenceLength:x,inputHiddenSize:f,hiddenSize:h,vHiddenSize:y,headSize:Math.floor(h/t.numHeads),vHeadSize:Math.floor(y/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:$,scale:t.scale,broadcastResPosBias:!1,passPastInKv:!1,qkvFormat:1}},Br=(e,t,r)=>t&&e?`
      let total_sequence_length_input = u32(${t.getByOffset("0")});
      let present_sequence_length = max(total_sequence_length_input, uniforms.past_sequence_length);
      let is_subsequent_prompt: bool = sequence_length > 1 && sequence_length != total_sequence_length_input;
      let is_first_prompt: bool = is_subsequent_prompt == false && sequence_length == total_sequence_length_input;
      total_sequence_length = u32(${e==null?void 0:e.getByOffset("batchIdx")}) + 1;
      var past_sequence_length: u32 = 0;
      if (is_first_prompt == false) {
        past_sequence_length = total_sequence_length - sequence_length;
      }
       `:`
    ${r?"let past_sequence_length = uniforms.past_sequence_length":""};
    let present_sequence_length = total_sequence_length;
    `,Ko=(e,t,r,i,a,s,n,u)=>{let d=be(n?1:s),p=64,f=s/d;f<p&&(p=32);let h=Math.ceil(s/d/p),l=[{type:12,data:t},{type:12,data:r},{type:12,data:i},{type:12,data:a},{type:12,data:f},{type:12,data:h}],y=Te(e.dataType,d),_=Ie(1,d),b=["type"];n&&b.push("type"),u&&b.push("type");let v=x=>{let $=H("x",e.dataType,e.dims,d),S=[$],k=n?R("seq_lens",n.dataType,n.dims):void 0;k&&S.push(k);let T=u?R("total_sequence_length_input",u.dataType,u.dims):void 0;T&&S.push(T);let E=Ie(e.dataType),I=[{name:"batch_size",type:"u32"},{name:"num_heads",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"sequence_length",type:"u32"},{name:"total_sequence_length",type:"u32"},{name:"elements_per_thread",type:"u32"}];return`
  var<workgroup> thread_max: array<f32, ${p}>;
  var<workgroup> thread_sum: array<f32, ${p}>;
  ${x.registerUniforms(I).declareVariables(...S)}
  ${x.mainStart([p,1,1])}
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let sequence_length = uniforms.sequence_length;
    var total_sequence_length = uniforms.total_sequence_length;
    ${Br(k,T,!1)}
    let local_offset = local_idx * uniforms.elements_per_thread;
    let offset = (global_idx / ${p}) * uniforms.total_sequence_length + local_offset;
    let seq_causal_length = ${n?"u32(past_sequence_length + workgroup_id.y + 1)":"total_sequence_length"};
    var thread_max_vector = ${_}(-3.402823e+38f);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      thread_max_vector = max(${_}(x[offset + i]), thread_max_vector);
    }
    thread_max[local_idx] = ${(()=>{switch(d){case 1:return"thread_max_vector";case 2:return"max(thread_max_vector.x, thread_max_vector.y)";case 4:return"max(max(thread_max_vector.x, thread_max_vector.y), max(thread_max_vector.z, thread_max_vector.w))";default:throw new Error(`Unsupported components: ${d}`)}})()};
    workgroupBarrier();

    var max_value =  f32(-3.402823e+38f);
    for (var i = 0u; i < ${p}; i++) {
      max_value = max(thread_max[i], max_value);
    }

    var sum_vector = ${_}(0);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      sum_vector += exp(${_}(x[offset + i]) - max_value);
    }
    thread_sum[local_idx] = ${(()=>{switch(d){case 1:return"sum_vector";case 2:return"sum_vector.x + sum_vector.y";case 4:return"sum_vector.x + sum_vector.y + sum_vector.z + sum_vector.w";default:throw new Error(`Unsupported components: ${d}`)}})()};
    workgroupBarrier();

    var sum: f32 = 0;
    for (var i = 0u; i < ${p}; i++) {
      sum += thread_sum[i];
    }

    if (sum == 0) {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        x[offset + i] = ${$.type.value}(${E}(1.0) / ${E}(seq_causal_length));
      }
    } else {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        var f32input = ${_}(x[offset + i]);
        x[offset + i] = ${$.type.value}(exp(f32input - max_value) / sum);
      }
    }
      ${n?`
        for (var total_seq_id: u32 = seq_causal_length; total_seq_id + local_offset < uniforms.total_sequence_length; total_seq_id++) {
          x[offset + total_seq_id] = ${$.type.value}(${E}(0));
        }`:""};
  }`};return{name:"AttentionProbsSoftmax",shaderCache:{hint:`${p};${y};${d}`,inputDependencies:b},getShaderSource:v,getRunData:()=>({outputs:[],dispatchGroup:{x:Math.ceil(s/p),y:a,z:t*r},programUniforms:l})}},Zo=(e,t,r,i,a,s,n,u,d)=>{let p=n+s.kvSequenceLength,f=[s.batchSize,s.numHeads,s.sequenceLength,p],h=e>1&&i,l=s.kvNumHeads?s.kvNumHeads:s.numHeads,y=h?[s.batchSize,l,p,s.headSize]:void 0,_=s.nReps?s.nReps:1,b=s.scale===0?1/Math.sqrt(s.headSize):s.scale,v=be(s.headSize),x=s.headSize/v,$=12,S={x:Math.ceil(p/$),y:Math.ceil(s.sequenceLength/$),z:s.batchSize*s.numHeads},k=[{type:12,data:s.sequenceLength},{type:12,data:x},{type:12,data:p},{type:12,data:s.numHeads},{type:12,data:s.headSize},{type:1,data:b},{type:12,data:n},{type:12,data:s.kvSequenceLength},{type:12,data:_}],T=h&&i&&z.size(i.dims)>0,E=["type","type"];T&&E.push("type"),a&&E.push("type"),u&&E.push("type"),d&&E.push("type");let I=[{dims:f,dataType:t.dataType,gpuDataType:0}];h&&I.push({dims:y,dataType:t.dataType,gpuDataType:0});let D=M=>{let W=R("q",t.dataType,t.dims,v),ee=R("key",r.dataType,r.dims,v),te=[W,ee];if(T){let Z=R("past_key",i.dataType,i.dims,v);te.push(Z)}a&&te.push(R("attention_bias",a.dataType,a.dims));let U=u?R("seq_lens",u.dataType,u.dims):void 0;U&&te.push(U);let ae=d?R("total_sequence_length_input",d.dataType,d.dims):void 0;ae&&te.push(ae);let F=H("output",t.dataType,f),G=[F];h&&G.push(H("present_key",t.dataType,y,v));let de=Ie(1,v),J=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"alpha",type:"f32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}];return`
  const TILE_SIZE = ${$}u;

  var<workgroup> tileQ: array<${W.type.storage}, ${$*$}>;
  var<workgroup> tileK: array<${W.type.storage}, ${$*$}>;
  ${M.registerUniforms(J).declareVariables(...te,...G)}
  ${M.mainStart([$,$,1])}
    // x holds the N and y holds the M
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let kvHeadIdx = ${_===1?"headIdx":"headIdx / uniforms.n_reps"};
    let kv_num_heads = ${_===1?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let m = workgroup_id.y * TILE_SIZE;
    let n = workgroup_id.x * TILE_SIZE;
    let sequence_length = uniforms.M;
    var total_sequence_length = uniforms.N;
    ${Br(U,ae,!0)}
    let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx;
    let qOffset = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
    ${T&&h?"let pastKeyOffset = absKvHeadIdx * uniforms.past_sequence_length * uniforms.K;":""};
    let kOffset = absKvHeadIdx * uniforms.kv_sequence_length * uniforms.K;
    ${h?"let presentKeyOffset = absKvHeadIdx * uniforms.N * uniforms.K;":""}
    var value = ${de}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (global_id.y < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = q[qOffset + local_id.y * uniforms.K + w + local_id.x];
      }
      if (n + local_id.y < uniforms.N && w + local_id.x < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
      ${T&&h?`
              if (n + local_id.y < past_sequence_length) {
                tileK[idx] = past_key[pastKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
              } else if (n + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
                tileK[idx] = key[kOffset + (n + local_id.y - past_sequence_length) * uniforms.K + w + local_id.x];
              }`:`
          if (n + local_id.y < uniforms.kv_sequence_length) {
            tileK[idx] = key[kOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
          }`}
      ${h?`if (n + local_id.y < present_sequence_length) {
        present_key[presentKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x] = tileK[idx];
      }`:""}
      }
      workgroupBarrier();

      for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
          value += ${de}(tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * local_id.x + k]);
      }

      workgroupBarrier();
    }

    if (global_id.y < uniforms.M && global_id.x < total_sequence_length) {
      let headOffset = workgroup_id.z * uniforms.M * uniforms.N;
      let outputIdx = headOffset + global_id.y * uniforms.N + global_id.x;
      var sum: f32 = ${(()=>{switch(v){case 1:return"value";case 2:return"value.x + value.y";case 4:return"value.x + value.y + value.z + value.w";default:throw new Error(`Unsupported components: ${v}`)}})()};
        output[outputIdx] = ${F.type.value} (sum * uniforms.alpha) + ${a?"attention_bias[outputIdx]":"0.0"};
    }
  }`};return{name:"AttentionProbs",shaderCache:{hint:`${v};${a!==void 0};${i!==void 0};${e}`,inputDependencies:E},getRunData:()=>({outputs:I,dispatchGroup:S,programUniforms:k}),getShaderSource:D}},Yo=(e,t,r,i,a,s,n=void 0,u=void 0)=>{let d=s+a.kvSequenceLength,p=a.nReps?a.nReps:1,f=a.vHiddenSize*p,h=e>1&&i,l=a.kvNumHeads?a.kvNumHeads:a.numHeads,y=h?[a.batchSize,l,d,a.headSize]:void 0,_=[a.batchSize,a.sequenceLength,f],b=12,v={x:Math.ceil(a.vHeadSize/b),y:Math.ceil(a.sequenceLength/b),z:a.batchSize*a.numHeads},x=[{type:12,data:a.sequenceLength},{type:12,data:d},{type:12,data:a.vHeadSize},{type:12,data:a.numHeads},{type:12,data:a.headSize},{type:12,data:f},{type:12,data:s},{type:12,data:a.kvSequenceLength},{type:12,data:p}],$=h&&i&&z.size(i.dims)>0,S=["type","type"];$&&S.push("type"),n&&S.push("type"),u&&S.push("type");let k=[{dims:_,dataType:t.dataType,gpuDataType:0}];h&&k.push({dims:y,dataType:t.dataType,gpuDataType:0});let T=E=>{let I=R("probs",t.dataType,t.dims),D=R("v",r.dataType,r.dims),M=[I,D];$&&M.push(R("past_value",i.dataType,i.dims));let W=n?R("seq_lens",n.dataType,n.dims):void 0;n&&M.push(W);let ee=u?R("total_sequence_length_input",u.dataType,u.dims):void 0;u&&M.push(ee);let te=[H("output",t.dataType,_)];h&&te.push(H("present_value",t.dataType,y));let U=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"v_hidden_size",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}];return`
  const TILE_SIZE = ${b}u;
  var<workgroup> tileQ: array<${I.type.value}, ${b*b}>;
  var<workgroup> tileV: array<${I.type.value}, ${b*b}>;
  ${E.registerUniforms(U).declareVariables(...M,...te)}
  ${E.mainStart([b,b,1])}
   let headIdx = workgroup_id.z % uniforms.num_heads;
   let batchIdx = workgroup_id.z / uniforms.num_heads;
   let kvHeadIdx = ${p===1?"headIdx":"headIdx / uniforms.n_reps"};
   let kv_num_heads = ${p===1?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
   let m = global_id.y;
   let n = global_id.x;
   let sequence_length = uniforms.M;
   var total_sequence_length = uniforms.K;
   ${Br(W,ee,!0)}
   let offsetA = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
   let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx; // kvHeadIdx is relative to the batch
   ${$&&h?"let pastValueOffset = absKvHeadIdx * uniforms.N * uniforms.past_sequence_length + n;":""};
   let vOffset = absKvHeadIdx * uniforms.N * uniforms.kv_sequence_length + n;
   ${h?"let presentValueOffset = absKvHeadIdx * uniforms.N * uniforms.K + n;":""}
   var value = ${I.type.storage}(0);
   for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = probs[offsetA + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
        ${$&&h?`
        if (w + local_id.y < past_sequence_length) {
          tileV[idx] = past_value[pastValueOffset + (w + local_id.y) * uniforms.N];
        } else if (w + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
          tileV[idx] = v[vOffset + (w + local_id.y - past_sequence_length) * uniforms.N];
        }
      `:`
            if (w + local_id.y < uniforms.kv_sequence_length) {
              tileV[idx] = v[vOffset + (w + local_id.y) * uniforms.N];
            }`}
        ${h?`
            if (w + local_id.y < present_sequence_length) {
          present_value[presentValueOffset + (w + local_id.y) * uniforms.N] = tileV[idx];
        }`:""}
      }
     workgroupBarrier();
     for (var k: u32 = 0u; k < TILE_SIZE && w+k < total_sequence_length; k++) {
       value += tileQ[TILE_SIZE * local_id.y + k] * tileV[TILE_SIZE * k + local_id.x];
     }
     workgroupBarrier();
   }

   // we need to transpose output from BNSH_v to BSND_v
   if (m < uniforms.M && n < uniforms.N) {
     let outputIdx = batchIdx * uniforms.M * uniforms.v_hidden_size + m * uniforms.v_hidden_size
       + headIdx * uniforms.N + n;
     output[outputIdx] = value;
   }
  }`};return{name:"AttentionScore",shaderCache:{hint:`${i!==void 0};${e}`,inputDependencies:S},getRunData:()=>({outputs:k,dispatchGroup:v,programUniforms:x}),getShaderSource:T}},pr=(e,t,r,i,a,s,n,u,d,p,f=void 0,h=void 0)=>{let l=Math.min(e.outputCount,1+(n?1:0)+(u?1:0)),y=l>1?p.pastSequenceLength:0,_=y+p.kvSequenceLength,b=d&&z.size(d.dims)>0?d:void 0,v=[t,r];l>1&&n&&z.size(n.dims)>0&&v.push(n),b&&v.push(b),f&&v.push(f),h&&v.push(h);let x=e.compute(Zo(l,t,r,n,b,p,y,f,h),{inputs:v,outputs:l>1?[-1,1]:[-1]})[0];e.compute(Ko(x,p.batchSize,p.numHeads,y,p.sequenceLength,_,f,h),{inputs:f&&h?[x,f,h]:[x],outputs:[]});let $=[x,i];l>1&&u&&z.size(u.dims)>0&&$.push(u),f&&$.push(f),h&&$.push(h),e.compute(Yo(l,x,i,u,p,y,f,h),{inputs:$,outputs:l>1?[0,2]:[0]})},Qo=(e,t)=>{let r=[t.batchSize,t.numHeads,t.sequenceLength,t.headSize],i=t.sequenceLength,a=t.inputHiddenSize,s=t.headSize,n=12,u={x:Math.ceil(t.headSize/n),y:Math.ceil(t.sequenceLength/n),z:t.batchSize*t.numHeads},d=[e.inputs[0],e.inputs[1],e.inputs[2]],p=[{type:12,data:i},{type:12,data:a},{type:12,data:s},{type:12,data:t.numHeads},{type:12,data:t.headSize},{type:12,data:t.hiddenSize},{type:12,data:t.hiddenSize+t.hiddenSize+t.vHiddenSize}],f=h=>{let l=H("output_q",d[0].dataType,r),y=H("output_k",d[0].dataType,r),_=H("output_v",d[0].dataType,r),b=R("input",d[0].dataType,d[0].dims),v=R("weight",d[1].dataType,d[1].dims),x=R("bias",d[2].dataType,d[2].dims),$=b.type.storage,S=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"hidden_size",type:"u32"},{name:"ldb",type:"u32"}];return`
  const TILE_SIZE = ${n}u;
  var<workgroup> tileInput: array<${$}, ${n*n}>;
  var<workgroup> tileWeightQ: array<${$}, ${n*n}>;
  var<workgroup> tileWeightK: array<${$}, ${n*n}>;
  var<workgroup> tileWeightV: array<${$}, ${n*n}>;
  ${h.registerUniforms(S).declareVariables(b,v,x,l,y,_)}
  ${h.mainStart([n,n,1])}
    let batchIndex = workgroup_id.z / uniforms.num_heads;
    let headNumber = workgroup_id.z % uniforms.num_heads;
    let m = global_id.y;
    let n = global_id.x;

    let inputOffset = batchIndex * (uniforms.M * uniforms.K) + m * uniforms.K;
    let biasOffsetQ = headNumber * uniforms.head_size;
    let biasOffsetK = uniforms.hidden_size + biasOffsetQ;
    let biasOffsetV = uniforms.hidden_size + biasOffsetK;

    var valueQ = ${$}(0);
    var valueK = ${$}(0);
    var valueV = ${$}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileInput[TILE_SIZE * local_id.y + local_id.x] = input[inputOffset + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        let offset = n + (w + local_id.y) * uniforms.ldb;
        tileWeightQ[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetQ + offset];
        tileWeightK[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetK + offset];
        tileWeightV[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetV + offset];
      }
      workgroupBarrier();
      for (var k: u32 = 0u; k<TILE_SIZE && w+k < uniforms.K; k++) {
        let inputTileOffset = TILE_SIZE * local_id.y + k;
        let weightTileOffset = TILE_SIZE * k + local_id.x;
        valueQ += tileInput[inputTileOffset] * tileWeightQ[weightTileOffset];
        valueK += tileInput[inputTileOffset] * tileWeightK[weightTileOffset];
        valueV += tileInput[inputTileOffset] * tileWeightV[weightTileOffset];
      }

      workgroupBarrier();
    }

    let headOffset = (m * uniforms.N + n) % uniforms.head_size;
    valueQ += bias[headOffset + biasOffsetQ];
    valueK += bias[headOffset + biasOffsetK];
    valueV += bias[headOffset + biasOffsetV];

    let offset = workgroup_id.z * uniforms.M * uniforms.N;
    if (m < uniforms.M && n < uniforms.N) {
      let outputIdx = offset + m * uniforms.N + n;
      output_q[outputIdx] = valueQ;
      output_k[outputIdx] = valueK;
      output_v[outputIdx] = valueV;
    }
  }`};return e.compute({name:"AttentionPrepare",shaderCache:{inputDependencies:["type","type","type"]},getRunData:()=>({outputs:[{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0}],dispatchGroup:u,programUniforms:p}),getShaderSource:f},{inputs:d,outputs:[-1,-1,-1]})},Mp=(e,t)=>{let r=jo(e.inputs,t),[i,a,s]=Qo(e,r);return pr(e,i,a,s,e.inputs[4],void 0,void 0,void 0,e.inputs[5],r)}}),Jo,Xo,eu,Pp,dg=P(()=>{Ke(),X(),re(),ve(),ie(),Jo=(e,t)=>{if(!e||e.length!==5)throw new Error("BatchNormalization requires 5 inputs");let r=(i,a,s)=>{let n=a.length;if(n!==i.length)throw new Error(`${s}: num dimensions != ${n}`);a.forEach((u,d)=>{if(u!==i[d])throw new Error(`${s}: dim[${d}] do not match`)})};if(e[0].dims.length>1){let i=t.format==="NHWC"?t.spatial?e[0].dims.slice(-1):e[0].dims.slice(-1).concat(e[0].dims.slice(1,e[0].dims.length-1)):e[0].dims.slice(1,t.spatial?2:void 0);r(e[1].dims,i,"Invalid input scale"),r(e[2].dims,i,"Invalid input B"),r(e[3].dims,i,"Invalid input mean"),r(e[4].dims,i,"Invalid input var")}else r(e[1].dims,[1],"Invalid input scale"),r(e[2].dims,[1],"Invalid input B"),r(e[3].dims,[1],"Invalid input mean"),r(e[4].dims,[1],"Invalid input var")},Xo=(e,t)=>{let{epsilon:r,spatial:i,format:a}=t,s=e[0].dims,n=i?be(s[s.length-1]):1,u=a==="NHWC"&&s.length>1?n:1,d=z.size(s)/n,p=i,f=p?s.length:s,h=R("x",e[0].dataType,e[0].dims,n),l=R("scale",e[1].dataType,e[1].dims,u),y=R("bias",e[2].dataType,e[2].dims,u),_=R("inputMean",e[3].dataType,e[3].dims,u),b=R("inputVar",e[4].dataType,e[4].dims,u),v=H("y",e[0].dataType,f,n),x=()=>{let S="";if(i)S=`let cOffset = ${s.length===1?"0u":a==="NHWC"?`outputIndices[${s.length-1}] / ${n}`:"outputIndices[1]"};`;else if(a==="NCHW")S=`
            ${v.indicesSet("outputIndices","0","0")}
            let cOffset = ${v.indicesToOffset("outputIndices")};`;else{S=`var cIndices = ${l.type.indices}(0);
                       cIndices[0] = outputIndices[${s.length-1}];`;for(let k=1;k<l.rank;k++)S+=`cIndices[${k}] = outputIndices[${k}];`;S+=`let cOffset = ${l.indicesToOffset("cIndices")};`}return S},$=S=>`
  const epsilon = ${r};
  ${S.registerUniform("outputSize","u32").declareVariables(h,l,y,_,b,v)}
  ${S.mainStart()}
  ${S.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
    var outputIndices = ${v.offsetToIndices(`global_idx * ${n}`)};
    ${x()}
    let scale = ${l.getByOffset("cOffset")};
    let bias = ${y.getByOffset("cOffset")};
    let inputMean = ${_.getByOffset("cOffset")};
    let inputVar = ${b.getByOffset("cOffset")};
    let x = ${h.getByOffset("global_idx")};
    let value = (x - inputMean) * inverseSqrt(inputVar + epsilon) * scale + bias;
    ${v.setByOffset("global_idx","value")}
  }`;return{name:"BatchNormalization",shaderCache:{hint:`${t.epsilon}_${t.format}_${i}_${n}`,inputDependencies:p?["rank","type","type","type","type"]:void 0},getShaderSource:$,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p?[{type:12,data:d},...K(s)]:[{type:12,data:d}]})}},eu=e=>fe(e),Pp=(e,t)=>{let{inputs:r,outputCount:i}=e,a=eu({...t,outputCount:i});if(ge.webgpu.validateInputContent&&Jo(r,a),t.trainingMode)throw new Error("BatchNormalization trainingMode is not supported yet.");e.compute(Xo(r,a))}}),tu,ru,Vp,pg=P(()=>{re(),ie(),tu=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![320,640,1280].includes(e[0].dims[2]))throw new Error("number of channels should be 320, 640 or 1280");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},ru=e=>{let t=e[0].dims,r=e[0].dims[2],i=z.size(t)/4,a=e[0].dataType,s=R("input",a,t,4),n=R("bias",a,[r],4),u=R("residual",a,t,4),d=H("output",a,t,4);return{name:"BiasAdd",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(i/64)}}),getShaderSource:p=>`
  const channels = ${r}u / 4;
  ${p.declareVariables(s,n,u,d)}

  ${p.mainStart()}
    ${p.guardAgainstOutOfBoundsWorkgroupSizes(i)}
    let value = ${s.getByOffset("global_idx")}
      + ${n.getByOffset("global_idx % channels")} + ${u.getByOffset("global_idx")};
    ${d.setByOffset("global_idx","value")}
  }`}},Vp=e=>{tu(e.inputs),e.compute(ru(e.inputs))}}),iu,le,Up,Wp,qp,Lp,Fp,Gp,Hp,jp,Kp,au,Zp,Yp,Qp,Jp,ur,Xp,Lr,ec,tc,rc,ic,ac,nc,sc,oc,uc,lc,dc,pc,cc,hc,fc,mc,Fi,gc,Ia,za,yc,_c,bc,nu,su,wc,nn=P(()=>{X(),re(),ve(),ie(),iu=(e,t,r,i,a,s,n)=>{let u=Math.ceil(t/4),d="";typeof a=="string"?d=`${a}(a)`:d=a("a");let p=R("inputData",r,[u],4),f=H("outputData",i,[u],4),h=[{name:"vec_size",type:"u32"}];return n&&h.push(...n),`
      ${e.registerUniforms(h).declareVariables(p,f)}

  ${s??""}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}

    let a = ${p.getByOffset("global_idx")};
    ${f.setByOffset("global_idx",d)}
  }`},le=(e,t,r,i,a,s=e.dataType,n,u)=>{let d=[{type:12,data:Math.ceil(z.size(e.dims)/4)}];return n&&d.push(...n),{name:t,shaderCache:{hint:a,inputDependencies:["type"]},getShaderSource:p=>iu(p,z.size(e.dims),e.dataType,s,r,i,u),getRunData:p=>({outputs:[{dims:e.dims,dataType:s}],dispatchGroup:{x:Math.ceil(z.size(p[0].dims)/64/4)},programUniforms:d})}},Up=e=>{e.compute(le(e.inputs[0],"Abs","abs"))},Wp=e=>{e.compute(le(e.inputs[0],"Acos","acos"))},qp=e=>{e.compute(le(e.inputs[0],"Acosh","acosh"))},Lp=e=>{e.compute(le(e.inputs[0],"Asin","asin"))},Fp=e=>{e.compute(le(e.inputs[0],"Asinh","asinh"))},Gp=e=>{e.compute(le(e.inputs[0],"Atan","atan"))},Hp=e=>{e.compute(le(e.inputs[0],"Atanh","atanh"))},jp=e=>fe(e),Kp=(e,t)=>{let r;switch(t.to){case 10:r="vec4<f16>";break;case 1:r="vec4<f32>";break;case 12:r="vec4<u32>";break;case 6:r="vec4<i32>";break;case 9:r="vec4<bool>";break;default:throw new RangeError(`not supported type (specified in attribute 'to' from 'Cast' operator): ${t.to}`)}e.compute(le(e.inputs[0],"Cast",r,void 0,t.cacheKey,t.to))},au=e=>{let t,r,i=e.length>=2&&e[1].data!==0,a=e.length>=3&&e[2].data!==0;switch(e[0].dataType){case 1:t=i?e[1].getFloat32Array()[0]:-34028234663852886e22,r=a?e[2].getFloat32Array()[0]:34028234663852886e22;break;case 10:t=i?e[1].getUint16Array()[0]:64511,r=a?e[2].getUint16Array()[0]:31743;break;default:throw new Error("Unsupport data type")}return fe({min:t,max:r})},Zp=(e,t)=>{let r=t||au(e.inputs),i=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"Clip",a=>`clamp(${a}, vec4<${i}>(uniforms.min), vec4<${i}>(uniforms.max))`,void 0,r.cacheKey,void 0,[{type:e.inputs[0].dataType,data:r.min},{type:e.inputs[0].dataType,data:r.max}],[{name:"min",type:i},{name:"max",type:i}]),{inputs:[0]})},Yp=e=>{e.compute(le(e.inputs[0],"Ceil","ceil"))},Qp=e=>{e.compute(le(e.inputs[0],"Cos","cos"))},Jp=e=>{e.compute(le(e.inputs[0],"Cosh","cosh"))},ur=e=>fe(e),Xp=(e,t)=>{let r=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"Elu",i=>`elu_vf32(${i})`,`
  const elu_alpha_ = ${r}(${t.alpha});

  fn elu_f32(a: ${r}) -> ${r} {
  return select((exp(a) - 1.0) * elu_alpha_, a, a >= 0.0);
  }

  fn elu_vf32(v: vec4<${r}>) -> vec4<${r}> {
  return vec4(elu_f32(v.x), elu_f32(v.y), elu_f32(v.z), elu_f32(v.w));
  }`,t.cacheKey))},Lr=(e="f32")=>`
const r0: ${e} = 0.3275911;
const r1: ${e} = 0.254829592;
const r2: ${e} = -0.284496736;
const r3: ${e} = 1.421413741;
const r4: ${e} = -1.453152027;
const r5: ${e} = 1.061405429;

fn erf_vf32(v: vec4<${e}>) -> vec4<${e}> {
  let absv = abs(v);
  let x = 1.0 / (1.0 + r0 * absv);
  return sign(v) * (1.0 - ((((r5 * x + r4) * x + r3) * x + r2) * x + r1) * x * exp(-absv * absv));
}`,ec=e=>{let t=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"Erf",r=>`erf_vf32(${r})`,Lr(t)))},tc=e=>{e.compute(le(e.inputs[0],"Exp","exp"))},rc=e=>{e.compute(le(e.inputs[0],"Floor","floor"))},ic=e=>{let t=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"Gelu",r=>`0.5 * ${r} * (1.0 + erf_vf32(${r} * 0.7071067811865475))`,Lr(t)))},ac=(e,t)=>{let r=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"LeakyRelu",i=>`select(leaky_relu_alpha_ * ${i}, ${i}, ${i} >= vec4<${r}>(0.0))`,`const leaky_relu_alpha_ = ${r}(${t.alpha});`,t.cacheKey))},nc=e=>{e.compute(le(e.inputs[0],"Not",t=>`!${t}`))},sc=e=>{e.compute(le(e.inputs[0],"Neg",t=>`-${t}`))},oc=e=>{e.compute(le(e.inputs[0],"Reciprocal",t=>`1.0/${t}`))},uc=e=>{let t=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"Relu",r=>`select(vec4<${t}>(0.0), ${r}, ${r} > vec4<${t}>(0.0))`))},lc=e=>{e.compute(le(e.inputs[0],"Sigmoid",t=>`(1.0 / (1.0 + exp(-${t})))`))},dc=e=>fe(e),pc=(e,t)=>{let r=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"HardSigmoid",i=>`max(vec4<${r}>(0.0), min(vec4<${r}>(1.0), ${t.alpha} * ${i} + vec4<${r}>(${t.beta})))`,void 0,t.cacheKey))},cc=e=>{e.compute(le(e.inputs[0],"Sin","sin"))},hc=e=>{e.compute(le(e.inputs[0],"Sinh","sinh"))},fc=e=>{e.compute(le(e.inputs[0],"Sqrt","sqrt"))},mc=e=>{e.compute(le(e.inputs[0],"Tan","tan"))},Fi=e=>`sign(${e}) * (1 - exp(-2 * abs(${e}))) / (1 + exp(-2 * abs(${e})))`,gc=e=>{e.compute(le(e.inputs[0],"Tanh",Fi))},Ia=(e="f32")=>`
const fast_gelu_a: ${e} = 0.5;
const fast_gelu_b: ${e} = 0.7978845608028654;
const fast_gelu_c: ${e} = 0.035677408136300125;

fn tanh_v(v: vec4<${e}>) -> vec4<${e}> {
  return ${Fi("v")};
}
`,za=e=>`(fast_gelu_a + fast_gelu_a * tanh_v(${e} * (fast_gelu_c * ${e} * ${e} + fast_gelu_b))) * ${e}`,yc=e=>{let t=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"FastGelu",za,Ia(t),void 0,e.inputs[0].dataType))},_c=(e,t)=>{let r=Ie(e.inputs[0].dataType);return e.compute(le(e.inputs[0],"ThresholdedRelu",i=>`select(vec4<${r}>(0.0), ${i}, ${i} > thresholded_relu_alpha_)`,`const thresholded_relu_alpha_ = vec4<${r}>(${t.alpha});`,t.cacheKey)),0},bc=e=>{e.compute(le(e.inputs[0],"Log","log"))},nu=(e,t)=>`
const alpha = vec4<${e}>(${t});
const one = ${e}(1.0);
const zero = ${e}(0.0);

fn quick_gelu_impl(x: vec4<${e}>) -> vec4<${e}> {
  let v = x *alpha;
  var x1 : vec4<${e}>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return x * x1;
}
`,su=e=>`quick_gelu_impl(${e})`,wc=(e,t)=>{let r=Ie(e.inputs[0].dataType);e.compute(le(e.inputs[0],"QuickGelu",su,nu(r,t.alpha),t.cacheKey,e.inputs[0].dataType))}}),ou,uu,$c,cg=P(()=>{re(),ie(),nn(),ou=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![2560,5120,10240].includes(e[0].dims[2]))throw new Error("hidden state should be 2560, 5120 or 10240");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},uu=e=>{let t=e[0].dims.slice();t[2]=t[2]/2;let r=R("input",e[0].dataType,e[0].dims,4),i=R("bias",e[0].dataType,[e[0].dims[2]],4),a=H("output",e[0].dataType,t,4),s=z.size(t)/4,n=Te(e[0].dataType);return{name:"BiasSplitGelu",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)}}),getShaderSource:u=>`
  const M_SQRT2 = sqrt(2.0);
  const halfChannels = ${e[0].dims[2]/4/2}u;

  ${u.declareVariables(r,i,a)}

  ${Lr(n)}

  ${u.mainStart()}
    ${u.guardAgainstOutOfBoundsWorkgroupSizes(s)}
    let biasIdx = global_idx % halfChannels;
    let batchIndex = global_idx / halfChannels;
    let inputOffset = biasIdx + batchIndex * halfChannels * 2;
    let valueLeft = input[inputOffset] + bias[biasIdx];
    let valueRight = input[inputOffset + halfChannels] + bias[biasIdx + halfChannels];
    let geluRight = valueRight * 0.5 * (erf_vf32(valueRight / M_SQRT2) + 1);

    ${a.setByOffset("global_idx","valueLeft * geluRight")}
  }`}},$c=e=>{ou(e.inputs),e.compute(uu(e.inputs))}}),lu,du,Ge,vc,xc,kc,Sc,Tc,Cc,Ec,Ic,zc,Ac,hg=P(()=>{X(),re(),ie(),lu=(e,t,r,i,a,s,n,u,d,p,f,h)=>{let l,y;typeof u=="string"?l=y=($,S)=>`${u}((${$}),(${S}))`:typeof u=="function"?l=y=u:(l=u.scalar,y=u.vector);let _=H("outputData",f,i.length,4),b=R("aData",d,t.length,4),v=R("bData",p,r.length,4),x;if(a)if(s){let $=z.size(t)===1,S=z.size(r)===1,k=t.length>0&&t[t.length-1]%4===0,T=r.length>0&&r[r.length-1]%4===0;$||S?x=_.setByOffset("global_idx",y($?`${b.type.value}(${b.getByOffset("0")}.x)`:b.getByOffset("global_idx"),S?`${v.type.value}(${v.getByOffset("0")}.x)`:v.getByOffset("global_idx"))):x=`
            let outputIndices = ${_.offsetToIndices("global_idx * 4u")};
            let offsetA = ${b.broadcastedIndicesToOffset("outputIndices",_)};
            let offsetB = ${v.broadcastedIndicesToOffset("outputIndices",_)};
            ${_.setByOffset("global_idx",y(n||k?b.getByOffset("offsetA / 4u"):`${b.type.value}(${b.getByOffset("offsetA / 4u")}[offsetA % 4u])`,n||T?v.getByOffset("offsetB / 4u"):`${v.type.value}(${v.getByOffset("offsetB / 4u")}[offsetB % 4u])`))}
          `}else x=_.setByOffset("global_idx",y(b.getByOffset("global_idx"),v.getByOffset("global_idx")));else{if(!s)throw new Error("no necessary to use scalar implementation for element-wise binary op implementation.");let $=(S,k,T="")=>{let E=`aData[indexA${k}][componentA${k}]`,I=`bData[indexB${k}][componentB${k}]`;return`
            let outputIndices${k} = ${_.offsetToIndices(`global_idx * 4u + ${k}u`)};
            let offsetA${k} = ${b.broadcastedIndicesToOffset(`outputIndices${k}`,_)};
            let offsetB${k} = ${v.broadcastedIndicesToOffset(`outputIndices${k}`,_)};
            let indexA${k} = offsetA${k} / 4u;
            let indexB${k} = offsetB${k} / 4u;
            let componentA${k} = offsetA${k} % 4u;
            let componentB${k} = offsetB${k} % 4u;
            ${S}[${k}] = ${T}(${l(E,I)});
          `};f===9?x=`
            var data = vec4<u32>(0);
            ${$("data",0,"u32")}
            ${$("data",1,"u32")}
            ${$("data",2,"u32")}
            ${$("data",3,"u32")}
            outputData[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:x=`
            ${$("outputData[global_idx]",0)}
            ${$("outputData[global_idx]",1)}
            ${$("outputData[global_idx]",2)}
            ${$("outputData[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(b,v,_)}

        ${h??""}

        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${x}
      }`},du=(e,t,r,i,a,s,n=r.dataType)=>{let u=r.dims.map(b=>Number(b)??1),d=i.dims.map(b=>Number(b)??1),p=!z.areEqual(u,d),f=u,h=z.size(u),l=!1,y=!1,_=[p];if(p){let b=Lt.calcShape(u,d,!1);if(!b)throw new Error("Can't perform binary op on the given tensors");f=b.slice(),h=z.size(f);let v=z.size(u)===1,x=z.size(d)===1,$=u.length>0&&u[u.length-1]%4===0,S=d.length>0&&d[d.length-1]%4===0;_.push(v),_.push(x),_.push($),_.push(S);let k=1;for(let T=1;T<f.length;T++){let E=u[u.length-T],I=d[d.length-T];if(E===I)k*=E;else break}k%4===0?(y=!0,l=!0):(v||x||$||S)&&(l=!0)}else l=!0;return _.push(l),{name:e,shaderCache:{hint:t+_.map(b=>b.toString()).join("_"),inputDependencies:["rank","rank"]},getShaderSource:b=>lu(b,u,d,f,l,p,y,a,r.dataType,i.dataType,n,s),getRunData:()=>({outputs:[{dims:f,dataType:n}],dispatchGroup:{x:Math.ceil(h/64/4)},programUniforms:[{type:12,data:Math.ceil(z.size(f)/4)},...K(u,d,f)]})}},Ge=(e,t,r,i,a,s)=>{e.compute(du(t,a??"",e.inputs[0],e.inputs[1],r,i,s))},vc=e=>{Ge(e,"Add",(t,r)=>`${t}+${r}`)},xc=e=>{Ge(e,"Div",(t,r)=>`${t}/${r}`)},kc=e=>{Ge(e,"Equal",{scalar:(t,r)=>`u32(${t}==${r})`,vector:(t,r)=>`vec4<u32>(${t}==${r})`},void 0,void 0,9)},Sc=e=>{Ge(e,"Mul",(t,r)=>`${t}*${r}`)},Tc=e=>{let t=R("input",e.inputs[0].dataType,e.inputs[0].dims).type.value;Ge(e,"Pow",{scalar:(r,i)=>`pow_custom(${r},${i})`,vector:(r,i)=>`pow_vector_custom(${r},${i})`},`
    fn pow_custom(a : ${t}, b : ${t}) -> ${t} {
      if (b == ${t}(0.0)) {
        return ${t}(1.0);
      } else if (a < ${t}(0.0) && f32(b) != floor(f32(b))) {
        return ${t}(pow(f32(a), f32(b))); // NaN
      }
      return select(sign(a), ${t}(1.0), round(f32(abs(b) % ${t}(2.0))) != 1.0) * ${t}(${t==="i32"?"round":""}(pow(f32(abs(a)), f32(b))));
    }
    fn pow_vector_custom(a : vec4<${t}>, b : vec4<${t}>) -> vec4<${t}> {
      // TODO: implement vectorized pow
      return vec4<${t}>(pow_custom(a.x, b.x), pow_custom(a.y, b.y), pow_custom(a.z, b.z), pow_custom(a.w, b.w));
    }
      `)},Cc=e=>{Ge(e,"Sub",(t,r)=>`${t}-${r}`)},Ec=e=>{Ge(e,"Greater",{scalar:(t,r)=>`u32(${t}>${r})`,vector:(t,r)=>`vec4<u32>(${t}>${r})`},void 0,void 0,9)},Ic=e=>{Ge(e,"Less",{scalar:(t,r)=>`u32(${t}<${r})`,vector:(t,r)=>`vec4<u32>(${t}<${r})`},void 0,void 0,9)},zc=e=>{Ge(e,"GreaterOrEqual",{scalar:(t,r)=>`u32(${t}>=${r})`,vector:(t,r)=>`vec4<u32>(${t}>=${r})`},void 0,void 0,9)},Ac=e=>{Ge(e,"LessOrEqual",{scalar:(t,r)=>`u32(${t}<=${r})`,vector:(t,r)=>`vec4<u32>(${t}<=${r})`},void 0,void 0,9)}}),pu,cu,hu,fu,Oc,Dc,fg=P(()=>{X(),re(),ve(),ie(),pu=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");let r=0,i=e[r],a=i.dataType,s=i.dims.length;e.forEach((n,u)=>{if(u!==r){if(n.dataType!==a)throw new Error("input tensors should be one type");if(n.dims.length!==s)throw new Error("input tensors should have the same shape");n.dims.forEach((d,p)=>{if(p!==t&&d!==i.dims[p])throw new Error("non concat dimensions must match")})}})},cu=(e,t)=>`
  fn calculateInputIndex(index: u32) -> u32 {
    let sizeInConcatAxis = array<u32, ${e}u>(${t});
    for (var i: u32 = 0u; i < ${e}; i += 1u ) {
      if (index < sizeInConcatAxis[i]) {
        return i;
      }
    }
    return ${e}u;
  }`,hu=(e,t)=>{let r=e.length,i=[];for(let a=0;a<r;++a){let s=t.setByOffset("global_idx",e[a].getByIndices("indices"));r===1?i.push(s):a===0?i.push(`if (inputIndex == ${a}u) { ${s} }`):a===r-1?i.push(`else { ${s} }`):i.push(`else if (inputIndex == ${a}) { ${s} }`)}return i.join(`
`)},fu=(e,t,r,i)=>{let a=z.size(r),s=new Array(e.length),n=new Array(e.length),u=0,d=[],p=[],f=[{type:12,data:a}];for(let b=0;b<e.length;++b)u+=e[b].dims[t],s[b]=u,p.push(e[b].dims.length),n[b]=R(`input${b}`,i,p[b]),d.push("rank"),f.push({type:12,data:s[b]});for(let b=0;b<e.length;++b)f.push(...K(e[b].dims));f.push(...K(r));let h=H("output",i,r.length),l=h.indicesGet("indices",t),y=Array.from(Array(s.length).keys()).map(b=>`uniforms.sizeInConcatAxis${b}`).join(","),_=b=>`

  ${(()=>{b.registerUniform("outputSize","u32");for(let v=0;v<e.length;v++)b.registerUniform(`sizeInConcatAxis${v}`,"u32");return b.declareVariables(...n,h)})()}

  ${cu(s.length,y)}

  ${b.mainStart()}
    ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

    var indices = ${h.offsetToIndices("global_idx")};

    let inputIndex = calculateInputIndex(${l});
    if (inputIndex != 0u) {
      let sizeInConcatAxis = array<u32, ${s.length}u>(${y});
      ${l} -= sizeInConcatAxis[inputIndex - 1u];
    }

    ${hu(n,h)}
  }`;return{name:"Concat",shaderCache:{hint:`${t}`,inputDependencies:d},getRunData:()=>({outputs:[{dims:r,dataType:i}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:f}),getShaderSource:_}},Oc=(e,t)=>{let r=e.inputs,i=r[0].dims,a=z.normalizeAxis(t.axis,i.length);pu(r,a);let s=i.slice();s[a]=r.reduce((u,d)=>u+(d.dims.length>a?d.dims[a]:0),0);let n=r.filter(u=>z.size(u.dims)>0);e.compute(fu(n,a,s,r[0].dataType),{inputs:n})},Dc=e=>fe({axis:e.axis})}),zt,At,Ot,sn,Rt=P(()=>{X(),re(),zt=(e,t,r="f32")=>{switch(e.activation){case"Relu":return`value = max(value, ${t}(0.0));`;case"Sigmoid":return`value = (${t}(1.0) / (${t}(1.0) + exp(-value)));`;case"Clip":return`value = clamp(value, ${t}(${r}(uniforms.clip_min)), ${t}(${r}(uniforms.clip_max)));`;case"HardSigmoid":return`value = max(${t}(0.0), min(${t}(1.0), ${r}(uniforms.alpha) * value + ${r}(uniforms.beta)));`;case"LeakyRelu":return`value = select(${r}(uniforms.alpha) * value, value, value >= ${t}(0.0));`;case"Tanh":return`let e2x = exp(-2.0 * abs(value));
              value = sign(value) * (1.0 - e2x) / (1.0 + e2x);
        `;case"":return"";default:throw new Error(`Unsupported activation ${e.activation}`)}},At=(e,t)=>{e.activation==="Clip"?t.push({type:1,data:e.clipMax},{type:1,data:e.clipMin}):e.activation==="HardSigmoid"?t.push({type:1,data:e.alpha},{type:1,data:e.beta}):e.activation==="LeakyRelu"&&t.push({type:1,data:e.alpha})},Ot=(e,t)=>{e.activation==="Clip"?t.push({name:"clip_max",type:"f32"},{name:"clip_min",type:"f32"}):e.activation==="HardSigmoid"?t.push({name:"alpha",type:"f32"},{name:"beta",type:"f32"}):e.activation==="LeakyRelu"&&t.push({name:"alpha",type:"f32"})},sn=e=>{let t=(e==null?void 0:e.activation)||"";if(t==="HardSigmoid"){let[r,i]=(e==null?void 0:e.activation_params)||[.2,.5];return{activation:t,alpha:r,beta:i}}else if(t==="Clip"){let[r,i]=(e==null?void 0:e.activation_params)||[lp,dp];return{activation:t,clipMax:i,clipMin:r}}else if(t==="LeakyRelu"){let[r]=(e==null?void 0:e.activation_params)||[.01];return{activation:t,alpha:r}}return{activation:t}}}),Ce,Rc,on=P(()=>{Ce=(e,t)=>{switch(e){case 1:return t;case 2:return`vec2<${t}>`;case 3:return`vec3<${t}>`;case 4:return`vec4<${t}>`;default:throw new Error(`${e}-component is not supported.`)}},Rc=e=>`
      ${e?"value = value + getBiasByOutputCoords(coords);":""}
      `}),Bc,mg=P(()=>{Bc=e=>`
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
      shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
    i32(${e}.x), i32(${e}.y), i32(${e}.z), 1));
}
`}),dr,un,ln=P(()=>{X(),re(),ie(),Rt(),dr=(e,t,r,i,a)=>{let s=i-r;return`
      ${Array.from({length:r}).map((n,u)=>`
      if (${j(t.shape,u,t.rank)} != 1) {
        ${t.indicesSet(e,u,j(a,u+s,i))}
      } else {
        ${t.indicesSet(e,u,0)}
      }`).join("")}
`},un=(e,t,r,i,a=!1,s)=>{let n=e[0].dims,u=e[1].dims,d=n[n.length-2],p=u[u.length-1],f=n[n.length-1],h=be(p),l=be(f),y=be(d),_=z.size(r)/h/y,b=e.length>2,v=i?i.slice(0,-2):r.slice(0,-2),x=[z.size(v),d,p],$=[{type:12,data:_},{type:12,data:d},{type:12,data:p},{type:12,data:f}];At(t,$),$.push(...K(v,n,u)),b&&$.push(...K(e[2].dims)),$.push(...K(x));let S=k=>{let T=tn("batch_dims",e[0].dataType,v.length),E=R("a",e[0].dataType,n.length,l),I=R("b",e[1].dataType,u.length,h),D=H("output",e[0].dataType,x.length,h),M=Te(D.type.tensor),W=zt(t,D.type.value,M),ee=[E,I],te="";if(b){let F=a?h:1;ee.push(R("bias",e[2].dataType,e[2].dims.length,F)),te=`${a?`value += bias[col / ${F}];`:`value += ${D.type.value}(bias[row + i]);`}`}let U=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"}];Ot(t,U);let ae=()=>{let F=`var a_data: ${E.type.value};`;for(let G=0;G<l;G++)F+=`
              let b_data${G} = b[(b_offset + (k + ${G}) * uniforms.N + col) / ${h}];`;for(let G=0;G<y;G++){F+=`a_data = a[(a_offset + (row + ${G}) * uniforms.K + k) / ${l}];`;for(let de=0;de<l;de++)F+=`
            values[${G}] = fma(${I.type.value}(a_data${l===1?"":`[${de}]`}), b_data${de}, values[${G}]);
`}return F};return`
  ${k.registerUniforms(U).registerInternalVariables(T).declareVariables(...ee,D)}
  ${k.mainStart()}
    ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let col = (global_idx % (uniforms.N / ${h})) * ${h};
    var index1 = global_idx / (uniforms.N / ${h});
    let stride1 = uniforms.M / ${y};
    let row = (index1 % stride1) * ${y};
    let batch = index1 / stride1;

    ${r.length===2?"":`let batch_indices = ${T.offsetToIndices("batch")};`}

    var a_indices: ${E.type.indices};
    ${dr("a_indices",E,E.rank-2,T.rank,"batch_indices")}
    ${E.indicesSet("a_indices",E.rank-2,0)}
    ${E.indicesSet("a_indices",E.rank-1,0)}
    let a_offset = ${E.indicesToOffset("a_indices")};

    var b_indices: ${I.type.indices};
    ${dr("b_indices",I,I.rank-2,T.rank,"batch_indices")}
    ${I.indicesSet("b_indices",I.rank-2,0)}
    ${I.indicesSet("b_indices",I.rank-1,0)}
    let b_offset = ${I.indicesToOffset("b_indices")};
    var values: array<${D.type.value}, ${y}>;
    for (var k: u32 = 0u; k < uniforms.K; k = k + ${l}) {
      ${ae()}
    }
    for (var i = 0u; i < ${y}u; i++) {
      var value = values[i];
      ${te}
      ${W}
      let cur_indices = ${D.type.indices}(batch, row + i, col);
      let offset = ${D.indicesToOffset("cur_indices")};
      ${D.setByOffset(`offset / ${h}`,"value")};
    }
  }
  `};return{name:"MatMulNaive",shaderCache:{hint:`${t.activation};${h};${l};${y};${a}`,inputDependencies:b?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:s?s(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:$}),getShaderSource:S}}}),mu,gu,Aa,Gi,yu,Oa,_u,Yr,dn=P(()=>{X(),re(),ie(),Rt(),ln(),on(),mu=(e,t)=>e?`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          kStart + inputRow,
          globalRowStart / innerElementSize + inputCol${t?", batchIndices":""});
        `:`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          globalRow + innerRow,
          kStart / innerElementSize + inputCol${t?", batchIndices":""});
        `,gu=(e,t)=>e?`
        let ACached0 = mm_Asub[k * innerElementSize][localRow];
        let ACached1 = mm_Asub[k * innerElementSize + 1][localRow];
        let ACached2 = mm_Asub[k * innerElementSize + 2][localRow];
        ${t===3?"":"let ACached3 = mm_Asub[k * innerElementSize + 3][localRow];"}
        for (var i = 0; i < rowPerThread; i = i + 1) {
          acc[i] = BCached0 * ACached0[i] + acc[i];
          acc[i] = BCached1 * ACached1[i] + acc[i];
          acc[i] = BCached2 * ACached2[i] + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached3[i] + acc[i];"}
        }`:`
        for (var i = 0; i < rowPerThread; i = i + 1) {
          let ACached = mm_Asub[tileRow + i][k];
          acc[i] = BCached0 * ACached.x + acc[i];
          acc[i] = BCached1 * ACached.y + acc[i];
          acc[i] = BCached2 * ACached.z + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached.w + acc[i];"}
        }`,Aa=(e,t,r="f32",i,a=!1,s=32,n=!1,u=32)=>{let d=t[1]*e[1],p=t[0]*e[0],f=a?d:s,h=a?s:d,l=f/t[0],y=s/t[1];if(!((a&&l===4&&e[1]===4||!a&&(l===3||l===4))&&f%t[0]===0&&s%t[1]===0&&e[0]===4))throw new Error(`If transposeA ${a} is true, innerElementSize ${l} and workPerThread[1] ${e[1]} must be 4.
      Otherwise, innerElementSize ${l} must be 3 or 4.
  tileAWidth ${f} must be divisible by workgroupSize[0]${t[0]}. tileInner ${s} must be divisible by workgroupSize[1] ${t[1]}. colPerThread ${e[0]} must be 4.`);return`
var<workgroup> mm_Asub: array<array<vec${l}<${r}>, ${f/l}>, ${h}>;
var<workgroup> mm_Bsub: array<array<vec4<${r}>, ${p/e[0]}>, ${s}>;

const rowPerThread = ${e[1]};
const colPerThread = ${e[0]};
const innerElementSize = ${l};
const tileInner = ${s};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
  let localRow = i32(localId.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(localId.x);

  let globalRow =i32(globalId.y) * rowPerThread;
  let globalCol = i32(globalId.x);
  let batch = ${n?"0":"i32(globalId.z)"};
  ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
  let globalRowStart = i32(workgroupId.y) * ${d};

  let num_tiles = ${n?`${Math.ceil(u/s)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
  var kStart = ${n?`i32(globalId.z) * ${u}`:"0"};

  var acc: array<vec4<${r}>, rowPerThread>;

  // Loop over shared dimension.
  let tileRowB = localRow * ${y};
  for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let inputRow = tileRow + innerRow;
          let inputCol = tileCol;
          ${mu(a,i)}
      }

      // Load one tile of B into local memory.
      for (var innerRow = 0; innerRow < ${y}; innerRow = innerRow + 1) {
          let inputRow = tileRowB + innerRow;
          let inputCol = tileCol;
          mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol${i?", batchIndices":""});
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
          let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
          let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
          let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
          ${l===3?"":"let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];"}

          ${gu(a,l)}
      }

      workgroupBarrier();
  }

  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }
}`},Gi=(e,t)=>e?`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              kStart + inputRow,
              globalRowStart + inputCol${t?", batchIndices":""});
            `:`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              globalRowStart + inputRow,
              kStart + inputCol${t?", batchIndices":""});
            `,yu=e=>e?"let ACached = mm_Asub[k][tileRow + innerRow];":"let ACached = mm_Asub[tileRow + innerRow][k];",Oa=(e,t,r="f32",i,a=!1,s=32,n=!1,u=32,d=!1)=>{let p=e[1]*t[1],f=e[0]*t[0],h=a?p:s,l=a?s:p;if(!(l%t[1]===0&&h%t[0]===0&&s%t[1]===0))throw new Error(`tileAHight ${l} must be divisible by workgroupSize[1]${t[1]}, tileAWidth ${h} must be divisible by workgroupSize[0]${t[0]}, tileInner ${s} must be divisible by workgroupSize[1]${t[1]}`);let y=l/t[1],_=h/t[0],b=s/t[1],v=d?`
    let localRow = i32(localId.y);
    let localCol = i32(localId.x);
    let globalRowStart = i32(workgroupId.y) * ${p};
    let globalColStart = i32(workgroupId.x) * ${f};

    // Loop over shared dimension.
    for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var inputRow = localRow; inputRow < ${l}; inputRow = inputRow + ${t[1]}) {
        for (var inputCol = localCol; inputCol < ${h}; inputCol = inputCol + ${t[0]}) {
          ${Gi(a,i)}
        }
      }
      // Load one tile of B into local memory.
      for (var inputRow = localRow; inputRow < ${s}; inputRow = inputRow + ${t[1]}) {
            for (var inputCol = localCol; inputCol < ${f}; inputCol = inputCol + ${t[0]}) {
          mm_Bsub[inputRow][inputCol] = mm_readB(batch,
            kStart + inputRow,
            globalColStart + inputCol${i?", batchIndices":""});
        }
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      var BCached : array<${r}, colPerThread>;
      for (var k = 0; k < tileInner; k = k + 1) {
        for (var inner = 0; inner < colPerThread; inner = inner + 1) {
          BCached[inner] = mm_Bsub[k][localCol + inner * ${t[0]}];
        }
        for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let ACached = ${a?`mm_Asub[k][localRow + innerRow * ${t[1]}];`:`mm_Asub[localRow + innerRow * ${t[1]}][k];`}
          for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
            acc[innerRow][innerCol] = acc[innerRow][innerCol] +
                ACached * BCached[innerCol];
          }
        }
      }
      workgroupBarrier();
    }
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let gRow = globalRowStart + localRow + innerRow * ${t[1]};
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        let gCol = globalColStart + localCol + innerCol * ${t[0]};
        mm_write(batch, gRow, gCol, acc[innerRow][innerCol]);
      }
    }
    `:`
let tileRow = i32(localId.y) * rowPerThread;
let tileCol = i32(localId.x) * colPerThread;

let globalRow = i32(globalId.y) * rowPerThread;
let globalCol = i32(globalId.x) * colPerThread;
let globalRowStart = i32(workgroupId.y) * ${p};

let tileRowA = i32(localId.y) * ${y};
let tileColA = i32(localId.x) * ${_};
let tileRowB = i32(localId.y) * ${b};
// Loop over shared dimension.
for (var t = 0; t < num_tiles; t = t + 1) {
  // Load one tile of A into local memory.
  for (var innerRow = 0; innerRow < ${y}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < ${_}; innerCol = innerCol + 1) {
      let inputRow = tileRowA + innerRow;
      let inputCol = tileColA + innerCol;
      ${Gi(a,i)}
    }
  }

  // Load one tile of B into local memory.
  for (var innerRow = 0; innerRow < ${b}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol + innerCol;
      mm_Bsub[inputRow][inputCol] = mm_readB(batch,
        kStart + inputRow,
        globalCol + innerCol${i?", batchIndices":""});
    }
  }
  kStart = kStart + tileInner;
  workgroupBarrier();

  // Compute acc values for a single thread.
  var BCached : array<${r}, colPerThread>;
  for (var k = 0; k < tileInner; k = k + 1) {
    for (var inner = 0; inner < colPerThread; inner = inner + 1) {
      BCached[inner] = mm_Bsub[k][tileCol + inner];
    }

    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      ${yu(a)}
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        acc[innerRow][innerCol] = acc[innerRow][innerCol] + ACached * BCached[innerCol];
      }
    }
  }

  workgroupBarrier();
}

for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
  for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
    mm_write(batch, globalRow + innerRow, globalCol + innerCol,
        acc[innerRow][innerCol]);
  }
}
`;return`
  var<workgroup> mm_Asub : array<array<${r}, ${h}>, ${l}>;
  var<workgroup> mm_Bsub : array<array<${r}, ${f}>, ${s}>;
  const rowPerThread = ${e[1]};
  const colPerThread = ${e[0]};
  const tileInner = ${s};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
    let batch = ${n?"0":"i32(globalId.z)"};
    ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
    let num_tiles = ${n?`${Math.ceil(u/s)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
    var kStart = ${n?`i32(globalId.z) * ${u}`:"0"};

    var acc : array<array<${r}, colPerThread>, rowPerThread>;
    ${v}
  }
`},_u=(e,t,r,i,a=!1)=>{let[s,n,u,d]=i,p=Te(i[0].type.tensor);return`
    fn mm_readA(batch: i32, row: i32, colIn: i32, batchIndices: ${s.type.indices}) -> ${Ce(e,p)} {
      var value = ${Ce(e,p)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_a_outer && col < uniforms.dim_inner)
      {
        var aIndices: ${n.type.indices};
        ${dr("aIndices",n,n.rank-2,s.rank,"batchIndices")}
        ${n.indicesSet("aIndices",n.rank-2,"u32(row)")}
        ${n.indicesSet("aIndices",n.rank-1,"u32(colIn)")}
        value = ${n.getByIndices("aIndices")};
      }
      return value;
    }

    fn mm_readB(batch: i32, row: i32, colIn: i32, batchIndices: ${s.type.indices}) -> ${Ce(e,p)} {
      var value = ${Ce(e,p)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_inner && col < uniforms.dim_b_outer)
      {
        var bIndices: ${u.type.indices};
        ${dr("bIndices",u,u.rank-2,s.rank,"batchIndices")}
        ${u.indicesSet("bIndices",u.rank-2,"u32(row)")}
        ${u.indicesSet("bIndices",u.rank-1,"u32(colIn)")}
        value = ${u.getByIndices("bIndices")};
      }
      return value;
    }

    fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: ${Ce(e,p)}) {
      let col = colIn * ${e};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
        var value = valueIn;
        let coords = vec3<i32>(batch, row, colIn);
        ${t?`value = value + ${a?"bias[colIn]":`${Ce(e,p)}(bias[row])`};`:""}
        ${r}
        ${d.setByIndices("vec3<u32>(coords)","value")}
      }
    }
    `},Yr=(e,t,r,i,a=!1,s)=>{let n=e[0].dims,u=e[1].dims,d=n.slice(0,-2),p=u.slice(0,-2),f=i?i.slice(0,-2):r.slice(0,-2),h=z.size(f),l=n[n.length-2],y=n[n.length-1],_=u[u.length-1],b=y%4===0&&_%4===0,v=l<=8?[4,1,1]:[4,4,1],x=[8,8,1],$=[Math.ceil(_/x[0]/v[0]),Math.ceil(l/x[1]/v[1]),Math.ceil(h/x[2]/v[2])],S=b?4:1,k=[...d,l,y/S],T=k.length,E=[...p,y,_/S],I=E.length,D=[h,l,_/S],M=[{type:6,data:l},{type:6,data:_},{type:6,data:y}];At(t,M),M.push(...K(f,k,E));let W=["rank","rank"],ee=e.length>2;ee&&(M.push(...K(e[2].dims)),W.push("rank")),M.push(...K(D));let te=U=>{let ae=f.length,F=tn("batchDims",e[0].dataType,ae,1),G=Te(e[0].dataType),de=R("a",e[0].dataType,T,S),J=R("b",e[1].dataType,I,S),Z=H("result",e[0].dataType,D.length,S),ue=[de,J];if(ee){let Ae=a?S:1;ue.push(R("bias",e[2].dataType,e[2].dims.length,Ae))}let N=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"}];Ot(t,N);let q=Te(Z.type.tensor),se=zt(t,Z.type.value,q),we=_u(S,ee,se,[F,de,J,Z],a);return`
  ${U.registerUniforms(N).registerInternalVariables(F).declareVariables(...ue,Z)}
  ${we}
  ${b?Aa(v,x,G,F):Oa(v,x,G,F)}
                   `};return{name:"MatMul",shaderCache:{hint:`${v};${t.activation};${b};${a}`,inputDependencies:W},getRunData:()=>({outputs:[{dims:s?s(r):r,dataType:e[0].dataType}],dispatchGroup:{x:$[0],y:$[1],z:$[2]},programUniforms:M}),getShaderSource:te}}}),bu,Nc,gg=P(()=>{X(),st(),ie(),Rt(),on(),mg(),dn(),bu=(e,t,r,i,a=!1,s,n=4,u=4,d=4,p="f32")=>{let f=M=>{switch(M){case 1:return"resData = x[xIndex];";case 3:return`resData = vec3<${p}>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);`;case 4:return"resData = x[xIndex / 4];";default:throw new Error(`innerElementSize ${M} is not supported.`)}},h=M=>{switch(M){case 1:return"return w[row * i32(uniforms.w_shape[3]) + colIn];";case 4:return"return w[row * i32(uniforms.w_shape[3]) / 4 + colIn];";default:throw new Error(`innerElementSize ${M} is not supported.`)}},l=e?`
    let coord = vec4<i32>(batch, xRow, xCol, xCh);
    `:`
    let coord = vec4<i32>(batch, xCh, xRow, xCol);
    `,y=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,_=e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])",b=e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])",v=e?"row":"col",x=e?"col":"row",$=`
    let inChannels = i32(uniforms.w_shape[2]);
    let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
    let outRow = ${v} / outWidth;
    let outCol = ${v} % outWidth;

    let WRow = ${x} / (i32(uniforms.w_shape[1]) * inChannels);
    let WCol = ${x} / inChannels % i32(uniforms.w_shape[1]);
    let xRow = outRow * uniforms.stride[0] + uniforms.dilation[0] * WRow - uniforms.pad[0];
    let xCol = outCol * uniforms.stride[1] + uniforms.dilation[1] * WCol - uniforms.pad[1];
    let xCh = ${x} % inChannels;
    var resData = ${Ce(n,p)}(0.0);
    // The bounds checking is always needed since we use it to pad zero for
    // the 'same' padding type.
    if (xRow >= 0 && xRow < ${_} && xCol >= 0 && xCol < ${b}) {
      ${l}
      let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
      ${f(n)}
    }
    return resData;`,S=e?t&&i?`
    let col = colIn * ${n};
    ${$}`:`
    let col = colIn * ${n};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
      ${$}
    }
    return ${Ce(n,p)}(0.0);`:i&&r?`
    let col = colIn * ${n};
    ${$}`:`
    let col = colIn * ${n};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${$}
    }
    return ${Ce(n,p)}(0.0);`,k=e?i&&r?h(u):`
    let col = colIn * ${u};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${h(u)}
    }
    return ${Ce(u,p)}(0.0);`:`
    let col = colIn * ${u};
    if (row < uniforms.dim_inner && col < uniforms.dim_a_outer) {
      ${h(u)}
    }
    return ${Ce(u,p)}(0.0);`,T=Ce(d,p),E=Ce(e?n:u,p),I=Ce(e?u:n,p),D=zt(s,T,p);return`
    fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${E} {
      ${e?S:k}
    }

    fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${I} {
      ${e?k:S}
    }

    fn mm_write(batch: i32, row : i32, colIn : i32, valueIn : ${T}) {
      let col = colIn * ${d};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer)
      {
      var value = valueIn;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${y}
      ${Rc(a)}
      ${D}
      setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
      }
    }`},Nc=(e,t,r,i,a,s,n,u,d)=>{let p=t.format==="NHWC",f=p?e[0].dims[3]:e[0].dims[1],h=r[0],l=p?r[2]:r[3],y=p?r[1]:r[2],_=p?r[3]:r[1],b=p&&(f%4===0||f%3===0)&&_%4===0,v=p?_:l*y,x=p?l*y:_,$=[8,8,1],S=i<=8?[4,1,1]:[4,4,1],k=[Math.ceil(v/$[0]/S[0]),Math.ceil(x/$[1]/S[1]),Math.ceil(h/$[2]/S[2])];he("verbose",()=>`[conv2d_mm_webgpu] dispatch = ${k}`);let T=b?p&&f%4!==0?3:4:1,E=$[1]*S[1],I=$[0]*S[0],D=Math.max($[0]*T,$[1]),M=i%E===0,W=a%I===0,ee=s%D===0,te=b?[T,4,4]:[1,1,1],U=[{type:6,data:i},{type:6,data:a},{type:6,data:s},{type:6,data:[t.pads[0],t.pads[1]]},{type:6,data:t.strides},{type:6,data:t.dilations}];At(t,U),U.push(...K(e[0].dims,e[1].dims));let ae=["rank","rank"];n&&(U.push(...K(e[2].dims)),ae.push("rank")),U.push(...K(r));let F=G=>{let de=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"pad",type:"i32",length:2},{name:"stride",type:"i32",length:2},{name:"dilation",type:"i32",length:2}];Ot(t,de);let J=b?4:1,Z=Te(e[0].dataType),ue=`
      fn setOutputAtIndex(flatIndex : i32, value : ${b?`vec4<${Z}>`:Z}) {
        result[flatIndex] = ${b?`vec4<${Z}>`:Z}(value);
      }
      fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : ${b?`vec4<${Z}>`:Z}) {
        let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
        setOutputAtIndex(flatIndex ${b?"/ 4":""}, value);
      }`,N=R("x",e[0].dataType,e[0].dims.length,T===3?1:T),q=R("w",e[1].dataType,e[1].dims.length,J),se=[N,q],we=H("result",e[0].dataType,r.length,J);if(n){let Ae=R("bias",e[2].dataType,e[2].dims.length,J);se.push(Ae),ue+=`
        fn getBiasByOutputCoords(coords : vec4<i32>) -> ${b?`vec4<${Z}>`:Z} {
          return bias[coords.${p?"w":"y"}${b?"/ 4":""}];
        }`}return`
        ${Bc("uniforms.result_strides")}
        //struct Uniforms { xShape : vec4<i32>, wShape : vec4<i32>, outShape : vec4<i32>,
        //  outShapeStrides: vec3<i32>, filterDims : vec2<i32>, pad : vec2<i32>, stride : vec2<i32>,
        //  dilation : vec2<i32>, dimAOuter : i32, dimBOuter : i32, dimInner : i32 };
        ${G.registerUniforms(de).declareVariables(...se,we)}
        ${ue}
        ${bu(p,M,W,ee,n,t,te[0],te[1],te[2],Z)}
        ${b?Aa(S,$,Z,void 0,!p,D):Oa(S,$,Z,void 0,!p,D,!1,void 0,u)}`};return{name:"Conv2DMatMul",shaderCache:{hint:`${t.cacheKey};${T};${b};${M};${W};${ee};${E};${I};${D}`,inputDependencies:ae},getRunData:()=>({outputs:[{dims:d?d(r):r,dataType:e[0].dataType}],dispatchGroup:{x:k[0],y:k[1],z:k[2]},programUniforms:U}),getShaderSource:F}}}),wu,Hi,Xt,$u,ji,vu,Mc,Pc,yg=P(()=>{X(),st(),re(),ie(),Rt(),on(),wu=e=>{let t=1;for(let r=0;r<e.length;r++)t*=e[r];return t},Hi=e=>typeof e=="number"?[e,e,e]:e,Xt=(e,t)=>t<=1?e:e+(e-1)*(t-1),$u=(e,t,r,i=1)=>{let a=Xt(t,i);return Math.floor((e[0]*(r-1)-r+a)/2)},ji=(e,t,r,i,a)=>{a==null&&(a=$u(e,t[0],i[0]));let s=[0,0,0,r];for(let n=0;n<3;n++)e[n]+2*a>=t[n]&&(s[n]=Math.trunc((e[n]-t[n]+2*a)/i[n]+1));return s},vu=(e,t,r,i,a,s,n,u,d,p)=>{let f,h,l,y;if(e==="VALID"&&(e=0),typeof e=="number"){f={top:e,bottom:e,left:e,right:e,front:e,back:e};let _=ji([t,r,i,1],[u,d,p],1,[a,s,n],e);h=_[0],l=_[1],y=_[2]}else if(Array.isArray(e)){if(!e.every((b,v,x)=>b===x[0]))throw Error(`Unsupported padding parameter: ${e}`);f={top:e[0],bottom:e[1],left:e[2],right:e[3],front:e[4],back:e[5]};let _=ji([t,r,i,1],[u,d,p],1,[a,s,n],e[0]);h=_[0],l=_[1],y=_[2]}else if(e==="SAME_UPPER"){h=Math.ceil(t/a),l=Math.ceil(r/s),y=Math.ceil(i/n);let _=(h-1)*a+u-t,b=(l-1)*s+d-r,v=(y-1)*n+p-i,x=Math.floor(_/2),$=_-x,S=Math.floor(b/2),k=b-S,T=Math.floor(v/2),E=v-T;f={top:S,bottom:k,left:T,right:E,front:x,back:$}}else throw Error(`Unknown padding parameter: ${e}`);return{padInfo:f,outDepth:h,outHeight:l,outWidth:y}},Mc=(e,t,r,i,a,s=!1,n="channelsLast")=>{let u,d,p,f,h;if(n==="channelsLast")[u,d,p,f,h]=e;else if(n==="channelsFirst")[u,h,d,p,f]=e;else throw new Error(`Unknown dataFormat ${n}`);let[l,,y,_,b]=t,[v,x,$]=Hi(r),[S,k,T]=Hi(i),E=Xt(y,S),I=Xt(_,k),D=Xt(b,T),{padInfo:M,outDepth:W,outHeight:ee,outWidth:te}=vu(a,d,p,f,v,x,$,E,I,D),U=s?l*h:l,ae=[0,0,0,0,0];return n==="channelsFirst"?ae=[u,U,W,ee,te]:n==="channelsLast"&&(ae=[u,W,ee,te,U]),{batchSize:u,dataFormat:n,inDepth:d,inHeight:p,inWidth:f,inChannels:h,outDepth:W,outHeight:ee,outWidth:te,outChannels:U,padInfo:M,strideDepth:v,strideHeight:x,strideWidth:$,filterDepth:y,filterHeight:_,filterWidth:b,effectiveFilterDepth:E,effectiveFilterHeight:I,effectiveFilterWidth:D,dilationDepth:S,dilationHeight:k,dilationWidth:T,inShape:e,outShape:ae,filterShape:t}},Pc=(e,t,r,i,a,s)=>{let n=s==="channelsLast";n?e[0].dims[3]:e[0].dims[1];let u=[64,1,1],d={x:r.map((v,x)=>x)},p=[Math.ceil(wu(d.x.map(v=>r[v]))/u[0]),1,1];he("verbose",()=>`[conv3d_naive_webgpu] dispatch = ${p}`);let f=1,h=z.size(r),l=[{type:12,data:h},{type:12,data:i},{type:12,data:a},{type:12,data:t.strides},{type:12,data:t.dilations}];At(t,l),l.push(...K(e[0].dims,e[1].dims));let y=["rank","rank"],_=e.length===3;_&&(l.push(...K(e[2].dims)),y.push("rank")),l.push(...K(r));let b=v=>{let x=[{name:"output_size",type:"u32"},{name:"filter_dims",type:"u32",length:i.length},{name:"pads",type:"u32",length:a.length},{name:"strides",type:"u32",length:t.strides.length},{name:"dilations",type:"u32",length:t.dilations.length}];Ot(t,x);let $=1,S=Te(e[0].dataType),k=R("x",e[0].dataType,e[0].dims.length,f),T=R("W",e[1].dataType,e[1].dims.length,$),E=[k,T],I=H("result",e[0].dataType,r.length,$),D="";if(_){let ee=R("bias",e[2].dataType,e[2].dims.length,$);E.push(ee),D+=`
        fn getBiasByOutputCoords(coords : array<u32, 5>) -> ${S} {
          return bias[${n?j("coords",4,5):j("coords",1,5)}];
        }`}let M=Ce(f,S),W=zt(t,M,S);return`
            ${D}
            fn getX(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${k.getByIndices("aIndices")};
            }
            fn getW(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${T.getByIndices("aIndices")};
            }
          ${v.registerUniforms(x).declareVariables(...E,I)}
          ${v.mainStart()}
          ${v.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
              let coords = ${I.offsetToIndices("global_idx")};
              let batch = ${j("coords",0,k.rank)};
              let d2 = ${n?j("coords",k.rank-1,k.rank):j("coords",1,k.rank)};
              let xFRCCorner = vec3<u32>(${n?j("coords",1,k.rank):j("coords",2,k.rank)},
              ${n?j("coords",2,k.rank):j("coords",3,k.rank)},
              ${n?j("coords",3,k.rank):j("coords",4,k.rank)}) * uniforms.strides - uniforms.pads;
              let xFCorner = xFRCCorner.x;
              let xRCorner = xFRCCorner.y;
              let xCCorner = xFRCCorner.z;
              let xShapeY = ${n?j("uniforms.x_shape",1,k.rank):j("uniforms.x_shape",2,k.rank)};
              let xShapeZ = ${n?j("uniforms.x_shape",2,k.rank):j("uniforms.x_shape",3,k.rank)};
              let xShapeW = ${n?j("uniforms.x_shape",3,k.rank):j("uniforms.x_shape",4,k.rank)};
              let xShapeU = ${n?j("uniforms.x_shape",4,k.rank):j("uniforms.x_shape",1,k.rank)};
              let inputDepthNearestVec4 = (xShapeU / 4) * 4;
              let inputDepthVec4Remainder = xShapeU % 4;

              var value = 0.0;
              for (var wF = 0u; wF < uniforms.filter_dims[0]; wF++) {
                let xF = xFCorner + wF * uniforms.dilations[0];
                if (xF < 0 || xF >= xShapeY) {
                  continue;
                }

                for (var wR = 0u; wR < uniforms.filter_dims[1]; wR++) {
                  let xR = xRCorner + wR * uniforms.dilations[1];
                  if (xR < 0 || xR >= xShapeZ) {
                    continue;
                  }

                  for (var wC = 0u; wC < uniforms.filter_dims[2]; wC++) {
                    let xC = xCCorner + wC * uniforms.dilations[2];
                    if (xC < 0 || xC >= xShapeW) {
                      continue;
                    }

                    for (var d1 = 0u; d1 < inputDepthNearestVec4; d1 += 4) {
                      ${n?`let xValues = vec4<f32>(
                               getX(batch, xF, xR, xC, d1),
                               getX(batch, xF, xR, xC, d1 + 1),
                               getX(batch, xF, xR, xC, d1 + 2),
                               getX(batch, xF, xR, xC, d1 + 3));
                            `:`let xValues = vec4<f32>(
                               getX(batch, d1, xF, xR, xC),
                               getX(batch, d1 + 1, xF, xR, xC),
                               getX(batch, d1 + 2, xF, xR, xC),
                               getX(batch, d1 + 3, xF, xR, xC));
                            `}
                            let wValues = vec4<f32>(
                              getW(d2, d1, wF, wR, wC),
                              getW(d2, d1 + 1, wF, wR, wC),
                              getW(d2, d1 + 2, wF, wR, wC),
                              getW(d2, d1 + 3, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                    if (inputDepthVec4Remainder == 1) {
                        ${n?`value += getX(batch, xF, xR, xC, inputDepthNearestVec4)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`:`value += getX(batch, inputDepthNearestVec4, xF, xR, xC)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`}
                    } else if (inputDepthVec4Remainder == 2) {
                      ${n?`let xValues = vec2<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1));
                      `:`let xValues = vec2<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC));
                    `}
                    let wValues = vec2<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC));
                      value += dot(xValues, wValues);
                    } else if (inputDepthVec4Remainder == 3) {
                      ${n?`let xValues = vec3<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 2));
                      `:`let xValues = vec3<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 2, xF, xR, xC));
                    `}
                    let wValues = vec3<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 2, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                  }
                }
              }
              ${_?"value = value + getBiasByOutputCoords(coords)":""};
              ${W}
              result[global_idx] = f32(value);
          }`};return{name:"Conv3DNaive",shaderCache:{hint:`${t.cacheKey};${n};${f};${_}`,inputDependencies:y},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:p[0],y:p[1],z:p[2]},programUniforms:l}),getShaderSource:b}}}),Vc,Uc,_g=P(()=>{X(),re(),ie(),Rt(),Vc=(e,t,r,i)=>{let a=e.length>2,s=a?"value += b[output_channel];":"",n=e[0].dims,u=e[1].dims,d=t.format==="NHWC",p=d?r[3]:r[1],f=p/t.group,h=d&&f>=4?be(p):1,l=z.size(r)/h,y=[{type:12,data:l},{type:12,data:t.dilations},{type:12,data:[t.strides[0],t.strides[1]]},{type:12,data:[t.pads[0],t.pads[1]]},{type:12,data:f}];At(t,y),y.push(...K(n,[u[0],u[1],u[2],u[3]/h]));let _=a?["rank","rank","rank"]:["rank","rank"];y.push(...K([r[0],r[1],r[2],r[3]/h]));let b=v=>{let x=H("output",e[0].dataType,r.length,h),$=Te(x.type.tensor),S=zt(t,x.type.value,$),k=R("x",e[0].dataType,n.length),T=R("w",e[1].dataType,u.length,h),E=[k,T];a&&E.push(R("b",e[2].dataType,e[2].dims,h));let I=[{name:"output_size",type:"u32"},{name:"dilations",type:"u32",length:t.dilations.length},{name:"strides",type:"u32",length:2},{name:"pads",type:"u32",length:2},{name:"output_channels_per_group",type:"u32"}];Ot(t,I);let D=d?`
      for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
        let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

        if (xHeight < 0u || xHeight >= uniforms.x_shape[1]) {
          continue;
        }

        for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
          let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
          if (xWidth < 0u || xWidth >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[2]; wInChannel++) {
            let input_channel = in_channel_offset + wInChannel;
            let xVal = ${k.get("batch","xHeight","xWidth","input_channel")};
            let wVal = ${T.get("wHeight","wWidth","wInChannel","output_channel")};
            value += xVal * wVal;
          }
        }
      }
      `:`
      for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[1]; wInChannel++) {
        let input_channel = in_channel_offset + wInChannel;
        for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[2]; wHeight++) {
          let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

          if (xHeight < 0u || xHeight >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[3]; wWidth++) {
            let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
            if (xWidth < 0u || xWidth >= uniforms.x_shape[3]) {
              continue;
            }

            let xVal = ${k.get("batch","input_channel","xHeight","xWidth")};
            let wVal = ${T.get("output_channel","wInChannel","wHeight","wWidth")};
            value += xVal * wVal;
          }
        }
      }
      `;return`
  ${v.registerUniforms(I).declareVariables(...E,x)}

  ${v.mainStart()}
    ${v.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let outputIndices = ${x.offsetToIndices("global_idx")};
    let batch: u32 = outputIndices[0];
    let output_channel: u32 = outputIndices[${d?3:1}];
    let xRCCorner: vec2<u32> = vec2<u32>(outputIndices[${d?1:2}], outputIndices[${d?2:3}]) * uniforms.strides - uniforms.pads;
    let group_id: u32 = output_channel * ${h} / uniforms.output_channels_per_group;
    var in_channel_offset = group_id * uniforms.w_shape[${d?2:1}];

    var value: ${x.type.value} = ${x.type.value}(0);
    ${D}
    ${s}
    ${S}
    ${x.setByOffset("global_idx","value")}
  }`};return{name:"GroupedConv",shaderCache:{hint:`${t.cacheKey}_${h}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:y}),getShaderSource:b}},Uc=(e,t,r,i)=>{let a=e.length>2,s=be(r[3]),n=be(r[2]),u=z.size(r)/s/n,d=[e[0].dims[0],e[0].dims[1],e[0].dims[2],e[0].dims[3]/s],p=[e[1].dims[0],e[1].dims[1],e[1].dims[2],e[1].dims[3]/s],f=[r[0],r[1],r[2],r[3]/s],h=[{type:12,data:u},{type:6,data:[t.strides[0],t.strides[1]]},{type:6,data:[t.pads[0],t.pads[1]]}];At(t,h),h.push(...K(d,p,f));let l=(n-1)*t.strides[1]+p[1],y=_=>{let b=H("output",e[0].dataType,f.length,s),v=Te(b.type.tensor),x=zt(t,b.type.value,v),$=R("x",e[0].dataType,d.length,s),S=R("w",e[1].dataType,p.length,s),k=[$,S];a&&k.push(R("b",e[2].dataType,e[2].dims,s));let T=a?"value += b[output_channel];":"",E=[{name:"output_size",type:"u32"},{name:"strides",type:"i32",length:2},{name:"pads",type:"i32",length:2}];return Ot(t,E),`
  ${_.registerUniforms(E).declareVariables(...k,b)}
  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let width0 = uniforms.output_shape[3];
    let output_channel = global_idx % width0;
    var index1 = global_idx / width0;
    let width1 = uniforms.output_shape[2] / ${n}u;
    let col = (index1 % width1) * ${n}u;
    index1 = index1 / width1;
    let row = index1 % uniforms.output_shape[1];
    let batch = index1 / uniforms.output_shape[1];

    let x_corner = vec2<i32>(i32(row), i32(col)) * uniforms.strides - uniforms.pads;

    var x_vals: array<${$.type.value}, ${l}>;
    var values: array<${b.type.value}, ${n}>;
    let input_channel = output_channel;
    // Use constant instead of uniform can give better performance for w's height/width.
    for (var w_height: u32 = 0u; w_height < ${p[0]}; w_height++) {
      let x_height = x_corner.x + i32(w_height);
      if (x_height >= 0 && u32(x_height) < uniforms.x_shape[1]) {
        for (var i = 0; i < ${l}; i++) {
          let x_width = x_corner.y + i;
          if (x_width >= 0 && u32(x_width) < uniforms.x_shape[2]) {
            x_vals[i] = ${$.get("batch","u32(x_height)","u32(x_width)","input_channel")};
          } else {
            x_vals[i] = ${$.type.value}(0);
          }
        }
        for (var w_width: u32 = 0u; w_width < ${p[1]}; w_width++) {
          let w_val = ${S.get("w_height","w_width","0","output_channel")};
          for (var i = 0u; i < ${n}u; i++) {
            values[i] = fma(x_vals[i * u32(uniforms.strides[1]) + w_width], w_val, values[i]);
          }
        }
      }
    }

    for (var i = 0u; i < ${n}u; i++) {
      var value = values[i];
      ${T}
      ${x}
      ${b.set("batch","row","col + i","output_channel","value")};
    }
  }`};return{name:"GroupedConv-Vectorize",shaderCache:{hint:`${t.cacheKey};${s};${n};${l};${p[0]};${p[1]}`,inputDependencies:a?["rank","rank","type"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:h}),getShaderSource:y}}}),xu,Nr,ku,Mr,Da,Ki,Su,Tu,Ra,bg=P(()=>{re(),gg(),yg(),dn(),_g(),Rt(),ln(),bt(),xu=(e,t,r,i,a,s)=>{let n=e[0],u=e.slice(s?1:2,s?3:4),d=u.length,p=t[0],f=t.slice(2).map((l,y)=>l+(l-1)*(r[y]-1)),h=u.map((l,y)=>l+i[y]+i[y+d]).map((l,y)=>Math.floor((l-f[y]+a[y])/a[y]));return h.splice(0,0,n),h.splice(s?3:1,0,p),h},Nr=[2,3,1,0],ku=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length>5)throw new Error("greater than 5D is not supported");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[1]*t.group;if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(e.length===3&&(e[2].dims.length!==1||e[1].dims[0]!==e[2].dims[0]))throw new Error("invalid bias");let a=e[0].dims.length-2;if(t.dilations.length!==a)throw new Error(`dilations should be ${a}D`);if(t.strides.length!==a)throw new Error(`strides should be ${a}D`);if(t.pads.length!==a*2)throw new Error(`pads should be ${a*2}D`);if(t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape")},Mr=(e,t)=>{let r=e.kernelShape.slice();r.length<t[1].dims.length-2&&r.push(...Array(t[1].dims.length-2-r.length).fill(0));for(let s=2;s<t[1].dims.length;++s)r[s-2]===0&&(r[s-2]=t[1].dims[s]);let i=e.pads.slice();Kr.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,i,e.format==="NHWC",e.autoPad);let a=Object.assign({},e);return Object.assign(a,{kernelShape:r,pads:i}),a},Da=e=>{let t=sn(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],a=e.dilations,s=e.group,n=e.kernel_shape,u=e.pads,d=e.strides,p=e.w_is_const();return{autoPad:i,format:r,dilations:a,group:s,kernelShape:n,pads:u,strides:d,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},Ki=(e,t,r,i)=>{let a=r.format==="NHWC",s=xu(t[0].dims,t[1].dims,r.dilations,r.pads,r.strides,a);if(r.group!==1){let E=[t[0]];if(a){let I=e.kernelCustomData.wT??e.compute(Pe(t[1],Nr),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=I),E.push(I)}else E.push(t[1]);t.length===3&&E.push(t[2]),!e.adapterInfo.isArchitecture("ampere")&&a&&t[1].dims[0]===r.group&&t[1].dims[1]===1&&r.dilations[0]===1&&r.dilations[1]===1?e.compute(Uc(E,r,s,i),{inputs:E}):e.compute(Vc(E,r,s,i),{inputs:E});return}let n=t.length===3,u=t[0].dims[a?1:2],d=t[0].dims[a?2:3],p=t[0].dims[a?3:1],f=t[1].dims[2],h=t[1].dims[3],l=s[a?1:2],y=s[a?2:3],_=s[a?3:1],b=a&&f===u&&h===d&&r.pads[0]===0&&r.pads[1]===0;if(b||f===1&&h===1&&r.dilations[0]===1&&r.dilations[1]===1&&r.strides[0]===1&&r.strides[1]===1&&r.pads[0]===0&&r.pads[1]===0){let E=s[0],I,D,M,W=[];if(a){let U=e.kernelCustomData.wT??e.compute(Pe(t[1],Nr),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];if(r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=U),b){let ae=u*d*p;I=t[0].reshape([1,E,ae]),D=U.reshape([1,ae,_]),M=[1,E,_]}else I=t[0].reshape([E,u*d,p]),D=U.reshape([1,p,_]),M=[E,l*y,_];W.push(I),W.push(D)}else I=t[0].reshape([E,p,u*d]),D=t[1].reshape([1,_,p]),M=[E,_,l*y],W.push(D),W.push(I);n&&W.push(t[2]);let ee=M[2],te=W[0].dims[W[0].dims.length-1];ee<8&&te<8?e.compute(un(W,r,s,M,a,i),{inputs:W}):e.compute(Yr(W,r,s,M,a,i),{inputs:W});return}let v=!0,x=e.kernelCustomData.wT??e.compute(Pe(t[1],Nr),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=x);let $=[t[0],x];n&&$.push(t[2]);let S=a?l*y:_,k=a?_:l*y,T=f*h*p;e.compute(Nc($,r,s,S,k,T,n,v,i),{inputs:$})},Su=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=[0,t.pads[0],0,t.pads[1]],s=[1].concat(t.strides),n=[1].concat(t.dilations),u=[1].concat(t.kernelShape),d=Mr({...t,pads:a,strides:s,dilations:n,kernelShape:u},i);Ki(e,i,d,p=>r?[p[0],p[2],p[3]]:[p[0],p[1],p[3]])},Tu=(e,t,r)=>{let i=r.format==="NHWC"?"channelsLast":"channelsFirst",a=Mr(r,t),s=r.autoPad==="NOTSET"?r.pads:r.autoPad,n=Mc(t[0].dims,t[1].dims,r.strides,r.dilations,s,!1,i);e.compute(Pc(t,a,n.outShape,[n.filterDepth,n.filterHeight,n.filterWidth],[n.padInfo.front,n.padInfo.top,n.padInfo.left],i))},Ra=(e,t)=>{if(ku(e.inputs,t),e.inputs[0].dims.length===3)Su(e,t);else if(e.inputs[0].dims.length===5)Tu(e,e.inputs,t);else{let r=Mr(t,e.inputs);Ki(e,e.inputs,r)}}}),Wc,wg=P(()=>{X(),st(),re(),ie(),Wc=(e,t,r)=>{let i=e.length>2,a=t.outputShape,s=t.format==="NHWC",n=t.group,u=e[1].dims,d=u[2]/n,p=u[3],f=s?be(d):1,h=s?be(p):1,l=s?p===1?f:h:1,y=z.size(a)/h,_=[Math.ceil(y/64),1,1];he("verbose",()=>`[conv2d_backprop_webgpu] dispatch = ${_}`);let b=["rank","rank"],v=[t.strides[0],t.strides[1]],x=[t.kernelShape[s?1:2],t.kernelShape[s?2:3]],$=[t.dilations[0],t.dilations[1]],S=[x[0]+(t.dilations[0]<=1?0:(t.kernelShape[s?1:2]-1)*(t.dilations[0]-1)),x[1]+(t.dilations[1]<=1?0:(t.kernelShape[s?2:3]-1)*(t.dilations[1]-1))],k=[S[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),S[1]-1-Math.floor((t.pads[1]+t.pads[3])/2)],T=[{type:12,data:y},{type:12,data:v},{type:12,data:x},{type:12,data:$},{type:12,data:S},{type:6,data:k},{type:12,data:d},{type:12,data:p},...K(e[0].dims,e[1].dims)];i&&(T.push(...K(e[2].dims)),b.push("rank")),T.push(...K(a));let E=I=>{let D=[{name:"output_size",type:"u32"},{name:"strides",type:"u32",length:v.length},{name:"filter_dims",type:"u32",length:x.length},{name:"dilations",type:"u32",length:x.length},{name:"effective_filter_dims",type:"u32",length:S.length},{name:"pads",type:"i32",length:k.length},{name:"input_channels_per_group",type:"u32"},{name:"output_channels_per_group",type:"u32"}],M=Te(e[0].dataType),W=s?1:2,ee=s?2:3,te=s?3:1,U=R("W",e[1].dataType,e[1].dims.length,l),ae=R("Dy",e[0].dataType,e[0].dims.length,f),F=[ae,U];i&&F.push(R("bias",e[2].dataType,[a[te]].length,h));let G=H("result",e[0].dataType,a.length,h),de=()=>{let Z="";if(f===1)Z+=`
        let w_offset = ${U.indicesToOffset(`${U.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)};
        let wValue = ${U.getByOffset(`w_offset / ${l}`)};
        dotProd = dotProd + xValue * wValue;`;else if(p===1)Z+=`
          let wValue = ${U.getByOffset(`${U.indicesToOffset(`${U.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)} / ${l}`)};
          dotProd = dotProd + dot(xValue, wValue);`;else for(let ue=0;ue<f;ue++)Z+=`
            let wValue${ue} = ${U.getByOffset(`${U.indicesToOffset(`${U.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel + ${ue}, wOutChannel)`)} / ${l}`)};
            dotProd = dotProd + xValue[${ue}] * wValue${ue};`;return Z},J=`
            let outputIndices = ${G.offsetToIndices(`global_idx * ${h}`)};
            let batch = ${G.indicesGet("outputIndices",0)};
            let d1 = ${G.indicesGet("outputIndices",te)};
            let r = ${G.indicesGet("outputIndices",W)};
            let c = ${G.indicesGet("outputIndices",ee)};
            let dyCorner = vec2<i32>(i32(r), i32(c)) - uniforms.pads;
            let dyRCorner = dyCorner.x;
            let dyCCorner = dyCorner.y;
            let groupId = d1 / uniforms.output_channels_per_group;
            let wOutChannel = d1 - groupId * uniforms.output_channels_per_group;
            // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
            // ? = to be determined. : = across all values in that axis.
            var dotProd = ${G.type.value}(0.0);
            for (var wR: u32 = 0; wR < uniforms.effective_filter_dims.x; wR = wR + 1) {
              if (wR % uniforms.dilations.x != 0) {
                continue;
              }
              let dyR = (${M}(dyRCorner) + ${M}(wR)) / ${M}(uniforms.strides[0]);
              let wRPerm = uniforms.filter_dims.x - 1 - wR / uniforms.dilations.x;
              if (dyR < 0.0 || dyR >= ${M}(uniforms.Dy_shape[${W}]) || fract(dyR) > 0.0 ||
                  wRPerm < 0) {
                continue;
              }
              wR = wR + uniforms.strides[0] - 1;
              let idyR: u32 = u32(dyR);

              for (var wC: u32 = 0; wC < uniforms.effective_filter_dims.y; wC = wC + 1) {
                if (wC % uniforms.dilations.y != 0) {
                  continue;
                }
                let dyC = (${M}(dyCCorner) + ${M}(wC)) / ${M}(uniforms.strides.y);
                let wCPerm = uniforms.filter_dims.y - 1 - wC / uniforms.dilations.y;
                if (dyC < 0.0 || dyC >= ${M}(uniforms.Dy_shape[${ee}]) ||
                    fract(dyC) > 0.0 || wCPerm < 0) {
                  continue;
                }
                wC = wC + uniforms.strides.y - 1;
                let idyC: u32 = u32(dyC);
                var inputChannel = groupId * uniforms.input_channels_per_group;
                for (var d2: u32 = 0; d2 < uniforms.input_channels_per_group; d2 = d2 + ${f}) {
                  let xValue = ${s?ae.getByOffset(`${ae.indicesToOffset(`${ae.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${f}`):ae.get("batch","inputChannel","idyR","idyC")};
                  ${de()}
                  inputChannel = inputChannel + ${f};
                }
              }
            }
            let value = dotProd${i?` + bias[d1 / ${h}]`:""};
            ${G.setByOffset("global_idx","value")};
          `;return`
    ${I.registerUniforms(D).declareVariables(...F,G)}
      ${I.mainStart()}
      ${I.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")};
    ${J}}`};return{name:"ConvTranspose2D",shaderCache:{hint:`${t.cacheKey};${f}${l}${h}${p===1}`,inputDependencies:b},getRunData:()=>({dispatchGroup:{x:_[0],y:_[1],z:_[2]},outputs:[{dims:r?r(a):a,dataType:e[0].dataType}],programUniforms:T}),getShaderSource:E}}}),Cu,Eu,Iu,Zi,qc,zu,Yi,Au,Lc,$g=P(()=>{wg(),Rt(),bt(),Cu=(e,t,r,i,a,s)=>(e-1)*t+r+(i-1)*a+1-s,Eu=(e,t,r,i,a)=>{let s=Math.floor(e/2);t==="SAME_UPPER"?(r[i]=s,r[a]=e-s):t==="SAME_LOWER"&&(r[i]=e-s,r[a]=s)},Iu=(e,t,r,i,a,s,n,u,d,p)=>{let f=e.length-2,h=p.length===0;d.length<f&&d.push(...Array(f-d.length).fill(0));let l=e[0],y=t[u?3:1]*a;for(let _=0,b=e.length-f-(u?1:0);_<f;++_,++b){let v=e[b],x=h?v*n[_]:p[_],$=Cu(v,n[_],s[_],t[b],r[_],x);Eu($,i,s,_,_+f),h&&p.push(n[_]*(v-1)+d[_]+(t[b]-1)*r[_]+1-s[_]-s[_+f])}p.splice(0,0,l),p.splice(u?3:1,0,y)},Zi=(e,t)=>{let r=e.kernelShape.slice();if(e.kernelShape.length===0||e.kernelShape.reduce((h,l)=>h*l,1)===0){r.length=0;for(let h=2;h<t[1].dims.length;++h)r.push(t[1].dims[h])}let i=e.format==="NHWC";r.splice(0,0,t[1].dims[0]),r.splice(i?3:1,0,t[1].dims[1]);let a=e.pads.slice(),s=e.outputShape.slice(),n=e.outputPadding.slice(),u=t[0].dims,d=e.dilations.slice();if(d.reduce((h,l)=>h+l,0)===0){let h=t[0].dims.length-2;d=new Array(h).fill(1)}let p=e.strides.slice();if(p.reduce((h,l)=>h+l,0)===0){let h=t[0].dims.length-2;p=new Array(h).fill(1)}Iu(u,r,d,e.autoPad,e.group,a,p,i,n,s);let f=Object.assign({},e);return Object.assign(f,{kernelShape:r,pads:a,outputPadding:n,outputShape:s,dilations:d,strides:p}),f},qc=e=>{let t=sn(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][typeof e.autoPad>"u"?0:e.autoPad],a=e.dilations,s=e.group,n=e.kernelShape,u=e.pads,d=e.strides,p=e.wIsConst(),f=e.outputPadding,h=e.outputShape;return{autoPad:i,format:r,dilations:a,group:s,kernelShape:n,outputPadding:f,outputShape:h,pads:u,strides:d,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},zu=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length!==4&&e[0].dims.length!==3)throw new Error("currently only support 2-dimensional conv");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[0];if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let a=e[1].dims[1]*t.group;if(e.length===3&&(e[2].dims.length!==1||e[2].dims[0]!==a))throw new Error("invalid bias");let s=e[0].dims.length-2;if(t.dilations.reduce((n,u)=>n+u,0)>0&&t.dilations.length!==s)throw new Error(`dilations should be ${s}D`);if(t.strides.reduce((n,u)=>n+u,0)>0&&t.strides.length!==s)throw new Error(`strides should be ${s}D`);if(t.pads.reduce((n,u)=>n+u,0)>0&&t.pads.length!==s*2)throw new Error(`pads should be ${s*2}D`);if(t.outputPadding.length!==s&&t.outputPadding.length!==0)throw new Error(`output_padding should be ${s}D`);if(t.kernelShape.reduce((n,u)=>n+u,0)>0&&t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape");if(t.outputShape.length!==0&&t.outputShape.length!==e[0].dims.length-2)throw new Error("invalid output shape")},Yi=(e,t,r,i)=>{let a=e.kernelCustomData.wT??e.compute(Pe(t[1],[2,3,0,1]),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=a);let s=[t[0],a];t.length===3&&s.push(t[2]),e.compute(Wc(s,r,i),{inputs:s})},Au=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=t.kernelShape;(a.length===0||a[0]===0)&&(a=[e.inputs[1].dims[2]]);let s=t.dilations;(s.length===0||s[0]===0)&&(s=[1]);let n=t.strides;(n.length===0||n[0]===0)&&(n=[1]);let u=t.pads;u.length===0&&(u=[0,0]),u=[0,u[0],0,u[1]],n=[1].concat(n),s=[1].concat(s),a=[1].concat(a);let d=Zi({...t,pads:u,strides:n,dilations:s,kernelShape:a},i);Yi(e,i,d,p=>r?[p[0],p[2],p[3]]:[p[0],p[1],p[3]])},Lc=(e,t)=>{if(zu(e.inputs,t),e.inputs[0].dims.length===3)Au(e,t);else{let r=Zi(t,e.inputs);Yi(e,e.inputs,r)}}}),Ou,Fc,Gc,vg=P(()=>{X(),re(),ve(),ie(),Ou=(e,t,r,i)=>{let a=z.size(t),s=t.length,n=R("input",e,s),u=H("output",e,s),d=r.dataType===6?r.getInt32Array()[0]:Number(r.getBigInt64Array()[0]),p=z.normalizeAxis(d,s),f=h=>{let l=` i32(${n.indicesGet("inputIndices","uniforms.axis")}) `,y=j("uniforms.input_shape","uniforms.axis",s),_=i.reverse?l+(i.exclusive?" + 1":""):"0",b=i.reverse?y:l+(i.exclusive?"":" + 1");return`
                ${h.registerUniform("outputSize","u32").registerUniform("axis","u32").declareVariables(n,u)}
                ${h.mainStart()}
                  ${h.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
                  var inputIndices = ${u.offsetToIndices("global_idx")};
                  var sum = ${u.type.value}(0);
                  let first : i32 = ${_};
                  let last : i32 = ${b};
                  for (var i : i32 = first; i < last; i++) {
                    ${n.indicesSet("inputIndices","uniforms.axis","u32(i)")};
                    sum = sum + ${n.getByIndices("inputIndices")};
                  }
                  ${u.setByOffset("global_idx","sum")};
                }`};return{name:"CumSum",shaderCache:{hint:i.cacheKey,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:t,dataType:e}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:[{type:12,data:a},{type:12,data:p},...K(t,t)]}),getShaderSource:f}},Fc=(e,t)=>{let r=e.inputs[0].dims,i=e.inputs[0].dataType,a=e.inputs[1];e.compute(Ou(i,r,a,t),{inputs:[0]})},Gc=e=>{let t=e.exclusive===1,r=e.reverse===1;return fe({exclusive:t,reverse:r})}}),Du,Ru,Bu,Hc,jc,xg=P(()=>{X(),re(),ve(),ie(),Du=e=>{if(!e||e.length!==1)throw new Error("DepthToSpace requires 1 input.");if(e[0].dims.length!==4)throw new Error("DepthToSpace requires 4D input.")},Ru=(e,t,r,i)=>{let a=[];a.push(`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`);for(let s=0;s<t;++s)a.push(r.indicesSet("a",e[s],`i[${s}]`));return a.push("return a;}"),a.join(`
`)},Bu=(e,t)=>{let r,i,a,s,n,u,d=t.format==="NHWC",p=t.blocksize,f=t.mode==="DCR";d?([r,i,a,s]=e.dims,n=f?[r,i,a,p,p,s/p**2]:[r,i,a,s/p**2,p,p],u=f?[0,1,3,2,4,5]:[0,1,4,2,5,3]):([r,i,a,s]=[e.dims[0],e.dims[2],e.dims[3],e.dims[1]],n=f?[r,p,p,s/p**2,i,a]:[r,s/p**2,p,p,i,a],u=f?[0,3,4,1,5,2]:[0,1,4,2,5,3]);let h=e.reshape(n),l=h.dims.length,y=e.dataType,_=R("a",y,l),b=H("output",y,l),v=x=>`
  ${x.registerUniform("output_size","u32").declareVariables(_,b)}

  ${Ru(u,l,_,b)}

  ${x.mainStart()}
    ${x.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${b.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${b.setByOffset("global_idx",_.getByIndices("aIndices"))}
  }`;return{name:"DepthToSpace",shaderCache:{hint:`${e.dims};${t.blocksize};${t.mode}`,inputDependencies:["rank"]},getRunData:x=>{let $=d?[r,i*p,a*p,s/p**2]:[r,s/p**2,i*p,a*p],S=z.size($),k=h.dims,T=z.sortBasedOnPerm(k,u);return{outputs:[{dims:$,dataType:x[0].dataType}],dispatchGroup:{x:Math.ceil(S/64)},programUniforms:[{type:12,data:S},...K(k,T)]}},getShaderSource:v}},Hc=(e,t)=>{Du(e.inputs),e.compute(Bu(e.inputs[0],t))},jc=e=>fe({blocksize:e.blocksize,mode:e.mode,format:e.format})}),Pr,er,Qi,Nu,Mu,Pu,Vu,Ji,Uu,Kc,Zc,kg=P(()=>{X(),re(),ve(),ie(),Pr="[a-zA-Z]|\\.\\.\\.",er="("+Pr+")+",Qi="^"+er+"$",Nu="("+er+",)*"+er,Mu="^"+Nu+"$",Pu=class{constructor(e=-1){this.symbolToIndices=new Map,this.inputIndex=e}addSymbol(e,t){let r=this.symbolToIndices.get(e);r===void 0?r=[t]:r.push(t),this.symbolToIndices.set(e,r)}},Vu=class{constructor(e,t){var a;this.equation=t,this.hasEllipsis=!1,this.symbolToInfo=new Map,this.lhs=new Array,this.outputDims=[];let[r,i]=t.includes("->")?t.split("->",2):[t,""];if(!r.match(RegExp(Mu)))throw new Error("Invalid LHS term");if(r.split(",").forEach((s,n)=>{let u=e[n].dims.slice();if(!s.match(RegExp(Qi)))throw new Error("Invalid LHS term");let d=this.processTerm(s,!0,u,n);this.lhs.push(d)}),i==="")i+=[...this.symbolToInfo.entries()].filter(([s,n])=>n.count===1||s==="...").map(([s])=>s).join("");else if(!i.match(RegExp(er)))throw new Error("Invalid RHS");(a=i.match(RegExp(Pr,"g")))==null||a.forEach(s=>{if(s==="...")this.outputDims=this.outputDims.concat(this.ellipsisDims);else{let n=this.symbolToInfo.get(s);if(n===void 0)throw new Error("Invalid RHS symbol");this.outputDims.push(n.dimValue)}}),this.rhs=this.processTerm(i,!1,this.outputDims)}addSymbol(e,t,r){let i=this.symbolToInfo.get(e);if(i!==void 0){if(i.dimValue!==t&&i.count!==1)throw new Error("Dimension mismatch");i.count++,i.inputIndices.push(r)}else i={count:1,dimValue:t,inputIndices:[r]};this.symbolToInfo.set(e,i)}processTerm(e,t,r,i=-1){let a=r.length,s=!1,n=[],u=0;if(!e.match(RegExp(Qi))&&!t&&e!=="")throw new Error("Invalid LHS term");let d=e.match(RegExp(Pr,"g")),p=new Pu(i);return d==null||d.forEach((f,h)=>{if(f==="..."){if(s)throw new Error("Only one ellipsis is allowed per input term");s=!0;let l=a-d.length+1;if(l<0)throw new Error("Ellipsis out of bounds");if(n=r.slice(u,u+l),this.hasEllipsis){if(this.ellipsisDims.length!==n.length||this.ellipsisDims.toString()!==n.toString())throw new Error("Ellipsis dimensions mismatch")}else if(t)this.hasEllipsis=!0,this.ellipsisDims=n;else throw new Error("Ellipsis must be specified in the LHS");for(let y=0;y<n.length;y++){let _=String.fromCharCode(48+y);p.addSymbol(_,h+y),this.addSymbol(_,r[u++],i)}}else p.addSymbol(f,h+(this.hasEllipsis?this.ellipsisDims.length-1:0)),this.addSymbol(f,r[u++],i)}),p}},Ji=e=>e+"_max",Uu=(e,t,r,i)=>{let a=e.map(p=>p.length).map((p,f)=>R(`input${f}`,t,p)),s=z.size(i),n=H("output",t,i.length),u=[...r.symbolToInfo.keys()].filter(p=>!r.rhs.symbolToIndices.has(p)),d=p=>{let f=[],h="var prod = 1.0;",l="var sum = 0.0;",y="sum += prod;",_=[],b=[],v=[],x=[],$=r.symbolToInfo.size===r.rhs.symbolToIndices.size;r.symbolToInfo.forEach((k,T)=>{var E;if(r.rhs.symbolToIndices.has(T)){let I=(E=r.rhs.symbolToIndices.get(T))==null?void 0:E[0];I!==void 0&&r.lhs.forEach((D,M)=>{if(k.inputIndices.includes(M)){let W=D.symbolToIndices.get(T);if(W===void 0)throw new Error("Invalid symbol error");W.forEach(ee=>{f.push(`${a[M].indicesSet(`input${M}Indices`,ee,n.indicesGet("outputIndices",I))}`)})}})}else r.lhs.forEach((I,D)=>{if(k.inputIndices.includes(D)){let M=I.symbolToIndices.get(T);if(M===void 0)throw new Error("Invalid symbol error");M.forEach(W=>{_.push(`${a[D].indicesSet(`input${D}Indices`,W,`${T}`)}`)}),x.push(`prod *= ${a[D].getByIndices(`input${D}Indices`)};`)}}),b.push(`for(var ${T}: u32 = 0; ${T} < uniforms.${Ji(T)}; ${T}++) {`),v.push("}")});let S=$?[...f,`let sum = ${a.map((k,T)=>k.getByIndices(`input${T}Indices`)).join(" * ")};`]:[...f,l,...b,..._,h,...x,y,...v];return`
            ${p.registerUniforms(u.map(k=>({name:`${Ji(k)}`,type:"u32"}))).registerUniform("outputSize","u32").declareVariables(...a,n)}

            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
            var outputIndices = ${n.offsetToIndices("global_idx")};
            ${a.map((k,T)=>`var input${T}Indices: ${a[T].type.indices};`).join(`
`)}
            ${S.join(`
`)};
            ${n.setByOffset("global_idx","sum")};
          }`};return{name:"Einsum",shaderCache:{hint:r.equation,inputDependencies:e.map(()=>"rank")},getRunData:()=>{let p=u.filter(h=>r.symbolToInfo.has(h)).map(h=>{var l;return{type:12,data:((l=r.symbolToInfo.get(h))==null?void 0:l.dimValue)||0}});p.push({type:12,data:s});let f=e.map((h,l)=>[...K(h)]).reduce((h,l)=>h.concat(l),p);return f.push(...K(i)),{outputs:[{dims:i,dataType:t}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:f}},getShaderSource:d}},Kc=(e,t)=>{let r=new Vu(e.inputs,t.equation),i=r.outputDims,a=e.inputs.map((s,n)=>s.dims);e.compute(Uu(a,e.inputs[0].dataType,r,i))},Zc=e=>{let t=e.equation.replace(/\s+/g,"");return fe({equation:t})}}),Wu,Xi,qu,Lu,Yc,Sg=P(()=>{X(),re(),ie(),Wu=e=>{if(!e||e.length!==2)throw new Error("Expand requires 2 input.");let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=r.length<t.length?0:r.length-t.length,a=t.length<r.length?0:t.length-r.length;for(;i<r.length&&a<t.length;++i,++a)if(r[i]!==t[a]&&r[i]!==1&&t[a]!==1)throw new Error("Expand requires shape to be broadcastable to input")},Xi=(e,t)=>{let r=e.length-t.length,i=[];for(let a=0;a<r;++a)i.push(e[a]);for(let a=0;a<t.length;++a)i.push(t[a]===1?e[a+r]:t[a]);return i},qu=(e,t)=>e.length>t.length?Xi(e,t):Xi(t,e),Lu=e=>{let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=qu(t,r),a=e[0].dataType,s=a===9||z.size(t)===1,n=a===9||t.length>0&&t[t.length-1]%4===0?4:1,u=s||i.length>0&&i[i.length-1]%4===0?4:1,d=Math.ceil(z.size(i)/u),p=h=>{let l=R("input",a,t.length,n),y=H("output",a,i.length,u),_;if(a===9){let b=(v,x,$="")=>`
          let outputIndices${x} = ${y.offsetToIndices(`outputOffset + ${x}u`)};
          let offset${x} = ${l.broadcastedIndicesToOffset(`outputIndices${x}`,y)};
          let index${x} = offset${x} / 4u;
          let component${x} = offset${x} % 4u;
          ${v}[${x}] = ${$}(${l.getByOffset(`index${x}`)}[component${x}]);
        `;_=`
        let outputOffset = global_idx * ${u};
        var data = vec4<u32>(0);
        ${b("data",0,"u32")}
        ${b("data",1,"u32")}
        ${b("data",2,"u32")}
        ${b("data",3,"u32")}
        ${y.setByOffset("global_idx","data")}
      }`}else _=`
        let outputIndices = ${y.offsetToIndices(`global_idx * ${u}`)};
        let inputOffset = ${l.broadcastedIndicesToOffset("outputIndices",y)};
        let data = ${y.type.value}(${l.getByOffset(`inputOffset / ${n}`)});
        ${y.setByOffset("global_idx","data")}
      }`;return`
    ${h.registerUniform("vec_size","u32").declareVariables(l,y)}
    ${h.mainStart()}
    ${h.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
    ${_}`},f=[{type:12,data:d},...K(t,i)];return{name:"Expand",shaderCache:{hint:`${i.length};${n}${u}`,inputDependencies:["rank"]},getShaderSource:p,getRunData:()=>({outputs:[{dims:i,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:f})}},Yc=e=>{Wu(e.inputs),e.compute(Lu(e.inputs),{inputs:[0]})}}),Fu,Qc,Tg=P(()=>{X(),re(),ie(),nn(),Fu=e=>{let t=e[0].dataType,r=z.size(e[0].dims),i=z.size(e[1].dims),a=i%4===0,s=n=>{let u=R("x",t,[1],4),d=R("bias",t,[1],4),p=H("y",t,[1],4),f=[{name:"output_vec_size",type:"u32"},{name:"bias_size",type:"u32"}],h=y=>`
      let bias${y}_offset: u32 = (global_idx * 4 + ${y}) % uniforms.bias_size;
      let bias${y} = ${d.getByOffset(`bias${y}_offset / 4`)}[bias${y}_offset % 4];`,l=a?`
      let bias = ${d.getByOffset("global_idx % (uniforms.bias_size / 4)")};`:`${h(0)}${h(1)}${h(2)}${h(3)}
      let bias = ${u.type.value}(bias0, bias1, bias2, bias3);`;return`${n.registerUniforms(f).declareVariables(u,d,p)}

    ${Ia(Ie(t))}

    ${n.mainStart(Ft)}
      ${n.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_vec_size")}

      let x = ${u.getByOffset("global_idx")};
      ${l}
      let x_in = x + bias;
      ${p.setByOffset("global_idx",za("x_in"))}
    }`};return{name:"FastGeluWithBias",shaderCache:{hint:`${a}`,inputDependencies:["type","type"]},getShaderSource:s,getRunData:n=>({outputs:[{dims:n[0].dims,dataType:n[0].dataType}],programUniforms:[{type:12,data:Math.ceil(r/4)},{type:12,data:i}],dispatchGroup:{x:Math.ceil(r/Ft/4)}})}},Qc=e=>{e.inputs.length<2||z.size(e.inputs[1].dims)===0?yc(e):e.compute(Fu(e.inputs))}}),Gu,Hu,Jc,Xc,Cg=P(()=>{X(),re(),ve(),ie(),Gu=e=>{if(!e||e.length!==2)throw new Error("Gather requires 2 inputs.")},Hu=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,s=z.normalizeAxis(t.axis,a),n=r.slice(0);n.splice(s,1,...i);let u=r[s],d=e[0].dataType===9?4:1,p=Math.ceil(z.size(n)/d),f=[{type:12,data:p},{type:6,data:u},{type:12,data:s},...K(e[0].dims,e[1].dims,n)],h=l=>{let y=R("data",e[0].dataType,e[0].dims.length,d),_=R("inputIndices",e[1].dataType,e[1].dims.length),b=H("output",e[0].dataType,n.length,d),v=$=>{let S=i.length,k=`var indicesIndices${$}  = ${_.type.indices}(0);`;for(let T=0;T<S;T++)k+=`${S>1?`indicesIndices${$}[${T}]`:`indicesIndices${$}`} = ${n.length>1?`outputIndices${$}[uniforms.axis + ${T}]`:`outputIndices${$}`};`;k+=`
          var idx${$} = ${_.getByIndices(`indicesIndices${$}`)};
          if (idx${$} < 0) {
            idx${$} = idx${$} + uniforms.axisDimLimit;
          }
          var dataIndices${$} : ${y.type.indices};
        `;for(let T=0,E=0;T<a;T++)T===s?(k+=`${a>1?`dataIndices${$}[${T}]`:`dataIndices${$}`} = u32(idx${$});`,E+=S):(k+=`${a>1?`dataIndices${$}[${T}]`:`dataIndices${$}`} = ${n.length>1?`outputIndices${$}[${E}]`:`outputIndices${$}`};`,E++);return k},x;if(e[0].dataType===9){let $=(S,k,T="")=>`
          let outputIndices${k} = ${b.offsetToIndices(`outputOffset + ${k}u`)};
          ${v(k)};
          let offset${k} = ${y.indicesToOffset(`dataIndices${k}`)};
          let index${k} = offset${k} / 4u;
          let component${k} = offset${k} % 4u;
          ${S}[${k}] = ${T}(${y.getByOffset(`index${k}`)}[component${k}]);
        `;x=`
        let outputOffset = global_idx * ${d};
        var value = vec4<u32>(0);
        ${$("value",0,"u32")}
        ${$("value",1,"u32")}
        ${$("value",2,"u32")}
        ${$("value",3,"u32")}
        ${b.setByOffset("global_idx","value")}
      `}else x=`
      let outputIndices = ${b.offsetToIndices("global_idx")};
      ${v("")};
      let value = ${y.getByIndices("dataIndices")};
      ${b.setByOffset("global_idx","value")};
      `;return`
      ${l.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(y,_,b)}
      ${l.mainStart()}
        ${l.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        ${x}
      }`};return{name:"Gather",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:n,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:f}),getShaderSource:h}},Jc=e=>fe({axis:e.axis}),Xc=(e,t)=>{let r=e.inputs;Gu(r),e.compute(Hu(e.inputs,t))}}),ju,eh,th,Eg=P(()=>{X(),re(),ie(),ju=(e,t,r,i,a,s,n,u,d)=>{let p=[{type:12,data:s},{type:12,data:i},{type:12,data:a},{type:12,data:r},{type:12,data:n},{type:12,data:u},{type:12,data:d}],f=[s];p.push(...K(t.dims,f));let h=l=>{let y=R("indices_data",t.dataType,t.dims.length),_=H("input_slice_offsets_data",12,1,1),b=[y,_],v=[{name:"output_size",type:"u32"},{name:"batch_dims",type:"u32"},{name:"input_dims",type:"u32",length:a.length},{name:"sizes_from_slice_dims_data",type:"u32",length:r.length},{name:"num_slices_per_batch",type:"u32"},{name:"input_batch_stride",type:"u32"},{name:"num_slice_dims",type:"u32"}];return`
  ${l.registerUniforms(v).declareVariables(...b)}
  ${l.mainStart()}
    ${l.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let batch_idx = global_idx / uniforms.num_slices_per_batch;
    let base_offset = batch_idx * uniforms.input_batch_stride;

    let slice_indices_base_offset = global_idx * uniforms.num_slice_dims;
    var relative_slice_offset = 0;
    for (var dim_idx = 0u; dim_idx < uniforms.num_slice_dims; dim_idx ++) {
      var index = i32(indices_data[dim_idx + slice_indices_base_offset].x);
      let input_dim_idx = uniforms.batch_dims + dim_idx;
      if (index < 0) {
        ${a.length===1?"index += i32(uniforms.input_dims);":"index += i32(uniforms.input_dims[input_dim_idx]);"}
      }
      ${r.length===1?"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data);":"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data[dim_idx]);"}
    }

    input_slice_offsets_data[global_idx] =  base_offset + u32(relative_slice_offset);
  }`};return e.compute({name:"computeSliceOffsets",shaderCache:{hint:`${a.length}_${r.length}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:f,dataType:e.inputs[1].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:p}),getShaderSource:h},{inputs:[t],outputs:[-1]})[0]},eh=(e,t)=>{let r=e.inputs,i=r[0].dims,a=r[0].dataType,s=r[1].dims,n=s[s.length-1],u=z.sizeToDimension(s,s.length-1),d=z.sizeFromDimension(i,t.batchDims+n),p=z.sizeToDimension(i,t.batchDims),f=z.sizeFromDimension(i,t.batchDims),h=u/p,l=new Array(n),y=d;for(let k=0;k<n;++k)l[n-1-k]=y,y*=i[t.batchDims+n-1-k];let _=ju(e,r[1],l,t.batchDims,i,u,h,f,n),b=t.batchDims+n;if(b>i.length)throw new Error("last dimension of indices must not be larger than rank of input tensor");let v=s.slice(0,-1).concat(i.slice(b)),x=z.size(v),$=[{type:12,data:x},{type:12,data:d},...K(r[0].dims,_.dims,v)],S=k=>{let T=R("data",r[0].dataType,r[0].dims.length),E=R("slice_offsets",12,_.dims.length),I=H("output",r[0].dataType,v.length);return`
          ${k.registerUniform("output_size","u32").registerUniform("slice_size","u32").declareVariables(T,E,I)}
            ${k.mainStart()}
            ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let slice_offset = slice_offsets[global_idx / uniforms.slice_size];
          output[global_idx] = data[u32(slice_offset) + global_idx % uniforms.slice_size];
        }`};e.compute({name:"GatherND",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:v,dataType:a}],dispatchGroup:{x:Math.ceil(x/64)},programUniforms:$}),getShaderSource:S},{inputs:[r[0],_]})},th=e=>({batchDims:e.batch_dims,cacheKey:""})}),Ku,Zu,rh,ih,Ig=P(()=>{X(),re(),ve(),ie(),Ku=(e,t)=>{if(e.length<3||e.length>4)throw new Error("GatherBlockQuantized requires 3 or 4 inputs.");let r=z.normalizeAxis(t.quantizeAxis,e[0].dims.length),i=t.blockSize,a=e[0],s=e[2],n=e.length===4?e[3]:void 0;if(s.dims.length!==a.dims.length||!a.dims.map((u,d)=>d===r?Math.ceil(u/i)===s.dims[d]:u===s.dims[d]).reduce((u,d)=>u&&d,!0))throw new Error("Scales must have the same rank as the input tensor and the dims should match except on gatherAxis.");if(n){if(n.dataType!==a.dataType)throw new Error("Zero point must have the same data type as the input tensor.");if(n.dims.length!==s.dims.length||!n.dims.map((u,d)=>u===s.dims[d]).reduce((u,d)=>u&&d,!0))throw new Error("Zero point must have the same rank as the input tensor and the dims should match except on quantizeAxis.")}},Zu=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,s=z.normalizeAxis(t.gatherAxis,a),n=z.normalizeAxis(t.quantizeAxis,a),u=r.slice(0);u.splice(s,1,...i);let d=z.size(u),p=e[2].dataType,f=e[0].dataType===22,h=[{type:12,data:d},{type:12,data:n},{type:12,data:s},{type:12,data:t.blockSize},...K(...e.map((y,_)=>y.dims),u)],l=y=>{let _=R("data",e[0].dataType,e[0].dims.length),b=R("inputIndices",e[1].dataType,e[1].dims.length),v=R("scales",e[2].dataType,e[2].dims.length),x=e.length>3?R("zeroPoint",e[3].dataType,e[3].dims.length):void 0,$=H("output",p,u.length),S=[_,b,v];x&&S.push(x);let k=[{name:"output_size",type:"u32"},{name:"quantize_axis",type:"u32"},{name:"gather_axis",type:"u32"},{name:"block_size",type:"u32"}];return`
        ${y.registerUniforms(k).declareVariables(...S,$)}
        ${y.mainStart()}
        let output_indices = ${$.offsetToIndices("global_idx")};
        var indices_indices = ${b.type.indices}(0);
        ${i.length>1?`
          for (var i: u32 = 0; i < ${i.length}; i++) {
            let index = ${$.indicesGet("output_indices","uniforms.gather_axis + i")};
            ${b.indicesSet("indices_indices","i","index")};
          }`:`indices_indices = ${$.indicesGet("output_indices","uniforms.gather_axis")};`};
        var data_indices = ${_.type.indices}(0);
        for (var i: u32 = 0; i < uniforms.gather_axis; i++) {
          let index = ${$.indicesGet("output_indices","i")};
          ${_.indicesSet("data_indices","i","index")};
        }
        var index_from_indices = ${b.getByIndices("indices_indices")};
        if (index_from_indices < 0) {
          index_from_indices += ${r[s]};
        }
        ${_.indicesSet("data_indices","uniforms.gather_axis","u32(index_from_indices)")};
        for (var i = uniforms.gather_axis + 1; i < ${u.length}; i++) {
          let index = ${$.indicesGet("output_indices",`i + ${i.length} - 1`)};
          ${_.indicesSet("data_indices","i","index")};
        }
        let data_offset = ${_.indicesToOffset("data_indices")};
        let data_index = data_offset % 8;
        // Convert 4-bit packed data to 8-bit packed data.
        let packed_4bit_quantized_data = ${_.getByOffset("data_offset / 8")};
        let packed_8bit_quantized_data = (packed_4bit_quantized_data >> (4 * (data_index % 2))) & 0x0f0f0f0f;
        let quantized_data_vec = ${f?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_quantized_data));
        let quantized_data = quantized_data_vec[data_index / 2];
        var scale_indices = data_indices;
        let quantize_axis_index = ${v.indicesGet("data_indices","uniforms.quantize_axis")} / uniforms.block_size;
        ${v.indicesSet("scale_indices","uniforms.quantize_axis","quantize_axis_index")};
        var scale = ${v.getByIndices("scale_indices")};
        ${x?`
              let zero_point_indices = scale_indices;
              let zero_point_offset = ${x.indicesToOffset("zero_point_indices")};
              let zero_point_index = zero_point_offset % 8;
              let packed_4bit_zero_points = ${x.getByOffset("zero_point_offset / 8")};
              let packed_8bit_zero_points = (packed_4bit_zero_points >> (4 * (zero_point_index % 2))) & 0x0f0f0f0f;
              let zero_point_vec = ${f?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_zero_points));
              let zero_point = zero_point_vec[zero_point_index / 2];`:"var zero_point = 0"};
        let dequantized_data = ${Ie(p)}(quantized_data - zero_point) * scale;
        ${$.setByOffset("global_idx","dequantized_data")};
    }`};return{name:"GatherBlockQuantized",shaderCache:{hint:`${t.cacheKey};${e.filter((y,_)=>_!==1).map(y=>y.dims.join("_")).join(";")}`,inputDependencies:Array.from({length:e.length},(y,_)=>"rank")},getRunData:()=>({outputs:[{dims:u,dataType:p}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:h}),getShaderSource:l}},rh=(e,t)=>{let r=e.inputs;Ku(r,t),e.compute(Zu(e.inputs,t))},ih=e=>fe({blockSize:e.blockSize,gatherAxis:e.gatherAxis,quantizeAxis:e.quantizeAxis})}),Yu,Qu,ah,nh,zg=P(()=>{X(),re(),ve(),ie(),Yu=e=>{if(!e||e.length!==2)throw new Error("GatherElements requires 2 inputs.");if(e[0].dims.length<1)throw new Error("GatherElements requires that the data input be rank >= 1.");if(e[0].dims.length!==e[1].dims.length)throw new Error(`GatherElements requires that the data input and
                     indices input tensors be of same rank.`)},Qu=(e,t)=>{let r=e[0].dims,i=e[0].dataType,a=r.length,s=e[1].dims,n=e[1].dataType,u=z.normalizeAxis(t.axis,a),d=r[u],p=s.slice(0),f=z.size(p),h=R("input",i,a),l=R("indicesInput",n,s.length),y=H("output",i,p.length),_=[{type:12,data:f},{type:6,data:d},{type:12,data:u}];return _.push(...K(r,s,p)),{name:"GatherElements",shaderCache:{inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:p,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:_}),getShaderSource:b=>`
      ${b.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(h,l,y)}
      ${b.mainStart()}
      ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

      let outputIndices = ${y.offsetToIndices("global_idx")};

      var idx = ${l.getByOffset("global_idx")};
      if (idx < 0) {
        idx = idx + uniforms.axisDimLimit;
      }
      var inputIndices = ${h.type.indices}(outputIndices);
      ${h.indicesSet("inputIndices","uniforms.axis","u32(idx)")};
      let value = ${h.getByIndices("inputIndices")};

      ${y.setByOffset("global_idx","value")};
  }`}},ah=e=>fe({axis:e.axis}),nh=(e,t)=>{let r=e.inputs;Yu(r),e.compute(Qu(e.inputs,t))}}),Ju,Xu,sh,oh,Ag=P(()=>{X(),re(),ie(),Ju=e=>{if(!e)throw new Error("Input is missing");if(e.length<2||e.length>3)throw new Error("Invaid input number.");if(e.length===3&&e[2].dims.length>2)throw new Error("Invalid input shape of C");if(e[0].dataType!==e[1].dataType||e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("Input types are mismatched")},Xu=(e,t)=>{let r=e[0].dims.slice(),i=e[1].dims.slice(),[a,s,n]=up.getShapeOfGemmResult(r,t.transA,i,t.transB,e.length===3?e[2].dims:void 0),u=[a,s];if(!u)throw new Error("Can't use gemm on the given tensors");let d=16,p=Math.ceil(s/d),f=Math.ceil(a/d),h=!0,l=z.size(u),y=[{type:12,data:h?p:l},{type:12,data:a},{type:12,data:s},{type:12,data:n},{type:1,data:t.alpha},{type:1,data:t.beta}],_=["type","type"];e.length===3&&(y.push(...K(e[2].dims)),_.push("rank")),y.push(...K(u));let b=x=>{let $="";t.transA&&t.transB?$="value += a[k * uniforms.M + m] * b[n * uniforms.K + k];":t.transA&&!t.transB?$="value += a[k * uniforms.M + m] * b[k * uniforms.N + n];":!t.transA&&t.transB?$="value += a[m * uniforms.K + k] * b[n * uniforms.K + k];":!t.transA&&!t.transB&&($="value += a[m * uniforms.K + k] * b[k * uniforms.N + n];");let S=t.alpha===1?"":"value *= uniforms.alpha;",k=R("a",e[0].dataType,e[0].dims),T=R("b",e[1].dataType,e[1].dims),E=k.type.value,I=null,D=[k,T];e.length===3&&(I=R("c",e[2].dataType,e[2].dims.length),D.push(I));let M=H("output",e[0].dataType,u.length);D.push(M);let W=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}];return`
  ${x.registerUniforms(W).declareVariables(...D)}

  ${x.mainStart()}
    ${x.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let m = global_idx / uniforms.N;
    let n = global_idx % uniforms.N;

    var value = ${E}(0);
    for (var k: u32 = 0u; k < uniforms.K; k++) {
      ${$}
    }

    ${S}
    ${I!=null?`let cOffset = ${I.broadcastedIndicesToOffset("vec2(m, n)",M)}; value += ${E}(uniforms.beta) * ${I.getByOffset("cOffset")};`:""}
    output[global_idx] = value;
  }`},v=x=>{let $=R("a",e[0].dataType,e[0].dims),S=R("b",e[1].dataType,e[1].dims),k=null,T=[$,S];e.length===3&&(k=R("c",e[2].dataType,e[2].dims.length),T.push(k));let E=H("output",e[0].dataType,u.length);T.push(E);let I=[{name:"num_tile_n",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}],D="",M="";t.transA&&t.transB?(M=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${$.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,D="value += tile_a[k][local_id.y] * tile_b[local_id.x][k];"):t.transA&&!t.transB?(M=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${$.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,D="value += tile_a[k][local_id.y] * tile_b[k][local_id.x];"):!t.transA&&t.transB?(M=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${$.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,D="value += tile_a[local_id.y][k] * tile_b[local_id.x][k];"):!t.transA&&!t.transB&&(M=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${$.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,D="value += tile_a[local_id.y][k] * tile_b[k][local_id.x];");let W=t.alpha===1?"":"value *= uniforms.alpha;";return`
  ${x.registerUniforms(I).declareVariables(...T)}
  var<workgroup> tile_a: array<array<${$.type.storage}, ${d}>, ${d}>;
  var<workgroup> tile_b: array<array<${S.type.storage}, ${d}>, ${d}>;
  ${x.mainStart([d,d,1])}
    let tile_col_start = (workgroup_index % uniforms.num_tile_n) * ${d};
    let tile_row_start = (workgroup_index / uniforms.num_tile_n) * ${d};
    let num_tiles = (uniforms.K - 1) / ${d} + 1;
    var k_start = 0u;
    var value = ${E.type.value}(0);
    for (var t: u32 = 0u; t < num_tiles; t++) {
      ${M}
      k_start = k_start + ${d};
      workgroupBarrier();

      for (var k: u32 = 0u; k < ${d}; k++) {
        ${D}
      }
      workgroupBarrier();
    }

    ${W}
    let m = tile_row_start + local_id.y;
    let n = tile_col_start + local_id.x;
    ${k!=null?`let cOffset = ${k.broadcastedIndicesToOffset("vec2(m, n)",E)}; value += ${E.type.value}(uniforms.beta) * ${k.getByOffset("cOffset")};`:""}
    if (m < uniforms.M && n < uniforms.N) {
      output[m * uniforms.N + n] = value;
    }
  }`};return h?{name:"GemmShared",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:u,dataType:e[0].dataType}],dispatchGroup:{x:p*f},programUniforms:y}),getShaderSource:v}:{name:"Gemm",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:u,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:y}),getShaderSource:b}},sh=e=>{let t=e.transA,r=e.transB,i=e.alpha,a=e.beta;return{transA:t,transB:r,alpha:i,beta:a,cacheKey:`${e.transA};${e.transB};${e.alpha===1}`}},oh=(e,t)=>{Ju(e.inputs),e.compute(Xu(e.inputs,t))}}),et,at,kt,St,el,tl,rl,il,al,nl,sl,ol,uh,lh,Og=P(()=>{X(),re(),ve(),ie(),[et,at,kt,St]=[0,1,2,3],el=e=>{if(e[0].dims.length!==4)throw new Error("only 4-D tensor is supported.");if(e[0].dims.length!==e[1].dims.length)throw new Error("input dimensions must be equal to grid dimensions");if(e[0].dims.length-2!==e[1].dims[e[1].dims.length-1])throw new Error(`last dimension of grid must be equal to ${e[0].dims.length-2}`);if(e[0].dims[0]!==e[1].dims[0])throw new Error("grid batch size must match input batch size")},tl=`
  fn gs_get_cubic_coeffs(x: f32) -> vec4<f32> {
    let cubic_alpha = -0.75f;
    let x_abs = abs(x);
    var coeffs: vec4<f32>;
    coeffs[0] = (((cubic_alpha * (x_abs + 1) - 5 * cubic_alpha) * (x_abs + 1) + 8 * cubic_alpha) * (x_abs + 1) - 4 * cubic_alpha);
    coeffs[1] = (((cubic_alpha + 2) * x_abs - (cubic_alpha + 3)) * x_abs * x_abs + 1);
    coeffs[2] = (((cubic_alpha + 2) * (1 - x_abs) - (cubic_alpha + 3)) * (1 - x_abs) * (1 - x_abs) + 1);
    coeffs[3] = (((cubic_alpha * (2 - x_abs) - 5 * cubic_alpha) * (2 - x_abs) + 8 * cubic_alpha) * (2 - x_abs) - 4 * cubic_alpha);
    return coeffs;
  }
`,rl=e=>`
  fn gs_bicubic_interpolate(p: mat4x4<${e}>, x: f32, y: f32) -> ${e} {
    var v: vec4<f32>;
    var coeffs = gs_get_cubic_coeffs(x);
    for (var i = 0; i < 4; i++) {
      v[i] = coeffs[0] * p[i][0] + coeffs[1] * p[i][1] + coeffs[2] * p[i][2] + coeffs[3] * p[i][3];
    }
    coeffs = gs_get_cubic_coeffs(y);
    let pixel = ${e}(coeffs[0] * v[0] + coeffs[1] * v[1] + coeffs[2] * v[2] + coeffs[3] * v[3]);
    return pixel;
  }
`,il=e=>`
  fn gs_denormalize(n: f32, length: i32) -> f32 {
    ${e.alignCorners===0?`
    // alignCorners: false => [-1, 1] to [-0.5, length - 0.5]
    return ((n + 1.0) * f32(length) - 1.0) / 2.0;
    `:`
    // alignCorners: true => [-1, 1] to [0, length - 1]
    return (n + 1.0) / 2.0 * (f32(length - 1));
    `}
  }
`,al=e=>`
  ${e.paddingMode==="reflection"?`
      fn gs_reflect(x: i32, x_min: f32, x_max: f32) -> u32 {
        var dx = 0.0;
        var fx = f32(x);
        let range = x_max - x_min;
        if (fx < x_min) {
          dx = x_min - fx;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_min + r;
          } else {
            fx = x_max - r;
          }
        } else if (fx > x_max) {
          dx = fx - x_max;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_max - r;
          } else {
            fx = x_min + r;
          }
        }
        return u32(fx);
      }`:""}
`,nl=(e,t,r)=>`
  fn pixel_at_grid(r: i32, c: i32, H: i32, W: i32, batch: u32, channel: u32, border: vec4<f32>) -> ${t} {
     var pixel = ${t}(0);
     var indices = vec4<u32>(0);
     indices[${et}] = batch;
     indices[${at}] = channel;`+(()=>{switch(r.paddingMode){case"zeros":return`
          if (r >= 0 && r < H && c >=0 && c < W) {
            indices[${kt}] = u32(r);
            indices[${St}] = u32(c);
          }
        `;case"border":return`
          indices[${kt}] = u32(clamp(r, 0, H - 1));
          indices[${St}] = u32(clamp(c, 0, W - 1));
        `;case"reflection":return`
          indices[${kt}] = gs_reflect(r, border[1], border[3]);
          indices[${St}] = gs_reflect(c, border[0], border[2]);
        `;default:throw new Error(`padding mode ${r.paddingMode} is not supported`)}})()+`
    return ${e.getByIndices("indices")};
  }
`,sl=(e,t,r)=>(()=>{switch(r.mode){case"nearest":return`
          let result = pixel_at_grid(i32(round(y)), i32(round(x)), H_in, W_in, indices[${et}], indices[${at}], border);
        `;case"bilinear":return`
          let x1 = i32(floor(x));
          let y1 = i32(floor(y));
          let x2 = x1 + 1;
          let y2 = y1 + 1;

          let p11 = pixel_at_grid(y1, x1, H_in, W_in, indices[${et}], indices[${at}], border);
          let p12 = pixel_at_grid(y1, x2, H_in, W_in, indices[${et}], indices[${at}], border);
          let p21 = pixel_at_grid(y2, x1, H_in, W_in, indices[${et}], indices[${at}], border);
          let p22 = pixel_at_grid(y2, x2, H_in, W_in, indices[${et}], indices[${at}], border);

          let dx2 = ${t}(f32(x2) - x);
          let dx1 = ${t}(x - f32(x1));
          let dy2 = ${t}(f32(y2) - y);
          let dy1 = ${t}(y - f32(y1));
          let result = dy2 * (dx2 * p11 + dx1 * p12) + dy1 * (dx2 * p21 + dx1 * p22);
        `;case"bicubic":return`
          let x0 = i32(floor(x)) - 1;
          let y0 = i32(floor(y)) - 1;
          var p: mat4x4<${t}>;
          for (var h = 0; h < 4; h++) {
            for (var w = 0; w < 4; w++) {
              p[h][w] = pixel_at_grid(h + y0, w + x0, H_in, W_in, indices[${et}], indices[${at}], border);
            }
          }

          let dx = x - f32(x0 + 1);
          let dy = y - f32(y0 + 1);
          let result = gs_bicubic_interpolate(p, dx, dy);
        `;default:throw new Error(`mode ${r.mode} is not supported`)}})()+`${e.setByOffset("global_idx","result")}`,ol=(e,t)=>{let r=R("x",e[0].dataType,e[0].dims.length),i=[e[1].dims[0],e[1].dims[1],e[1].dims[2]],a=R("grid",e[1].dataType,i.length,2),s=[e[0].dims[0],e[0].dims[1],e[1].dims[1],e[1].dims[2]];t.format==="NHWC"&&(s=[e[0].dims[0],e[1].dims[1],e[1].dims[2],e[0].dims[3]],[et,at,kt,St]=[0,3,1,2]);let n=H("output",e[0].dataType,s.length),u=r.type.value,d=z.size(s),p=[{type:12,data:d},...K(e[0].dims,i,s)],f=h=>`
  ${h.registerUniform("output_size","u32").declareVariables(r,a,n)}
  ${tl}
  ${rl(u)}
  ${il(t)}
  ${al(t)}
  ${nl(r,u,t)}

  ${h.mainStart()}
    ${h.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let H_in = i32(uniforms.x_shape[${kt}]);
      let W_in = i32(uniforms.x_shape[${St}]);

      ${t.alignCorners===0?`
      let x_min = -0.5;
      let x_max = f32(W_in) - 0.5;
      let y_min = -0.5;
      let y_max = f32(H_in) - 0.5;
      `:`
      let x_min = 0.0;
      let x_max = f32(W_in) - 1.0;
      let y_min = 0.0;
      let y_max = f32(H_in) - 1.0;
      `};
      let border = vec4<f32>(x_min, y_min, x_max, y_max);

      let indices = ${n.offsetToIndices("global_idx")};
      var grid_indices = vec3<u32>(indices[${et}], indices[${kt}], indices[${St}]);
      let nxy = ${a.getByIndices("grid_indices")};
      var x = gs_denormalize(f32(nxy[0]), W_in);
      var y = gs_denormalize(f32(nxy[1]), H_in);

      ${sl(n,u,t)}
  }`;return{name:"GridSample",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:["type","type"]},getRunData:h=>{let l=z.size(s);return{outputs:[{dims:s,dataType:h[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:p}},getShaderSource:f}},uh=(e,t)=>{el(e.inputs),e.compute(ol(e.inputs,t))},lh=e=>fe({alignCorners:e.align_corners,mode:e.mode,paddingMode:e.padding_mode,format:e.format})}),ze,ul,dh,ea,ll,lr,ph,ch=P(()=>{X(),re(),ve(),en(),an(),ie(),bt(),ze=(e,t)=>e.length>t&&e[t].dims.length>0?e[t]:void 0,ul=(e,t)=>{let r=e[0],i=ze(e,1),a=ze(e,2),s=ze(e,3),n=ze(e,4),u=ze(e,5),d=ze(e,6),p=ze(e,7);if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let f=r.dims[0],h=r.dims[1],l=r.dims.length===3?r.dims[2]:t.numHeads*r.dims[4],y=h,_=0,b=0,v=Math.floor(l/t.numHeads);if(d&&p&&z.size(d.dims)&&z.size(p.dims)){if(d.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(d.dims[0]!==f||d.dims[1]!==t.numHeads||d.dims[3]!==v)throw new Error('Input "past_key" shape (batch_size, num_heads, past_sequence_length, head_size)');if(p.dims[0]!==f||p.dims[1]!==t.numHeads||p.dims[3]!==v)throw new Error('Input "past_value" shape (batch_size, num_heads, past_sequence_length, head_size)');if(d.dims[2]!==p.dims[2])throw new Error('Input "past_key" and "past_value" shall have same dim 2 (past_sequence_length)');if(p.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');_=d.dims[2],b=d.dims[2]}else if(d&&z.size(d.dims)||p&&z.size(p.dims))throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let x;if(i&&z.size(i.dims)>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(i.dims[2]!==r.dims[2])throw new Error('Input "query" and "key" shall have same dim 2 (hidden_size)');x=2,y=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==v)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');x=5,y=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==v)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');x=0,y=i.dims[2]}}else{if(r.dims.length!==5)throw new Error('Input "query" is expected to have 5 dimensions when key is empty');if(r.dims[2]!==t.numHeads||r.dims[3]!==3)throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');x=3}if(s&&z.size(s.dims)>0){if(s.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimension');if(i&&i.dims.length===5&&i.dims[3]===2)throw new Error("bias is not allowed for packed kv.")}let $=_+y,S=0;if(n&&z.size(n.dims)>0){S=8;let I=n.dims;throw I.length===1?I[0]===f?S=1:I[0]===3*f+2&&(S=3):I.length===2&&I[0]===f&&I[1]===$&&(S=5),S===8?new Error('Input "key_padding_mask" shape shall be (batch_size) or (batch_size, total_sequence_length)'):new Error("Mask not supported")}let k=!1,T=l;if(a&&z.size(a.dims)>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(y!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');T=a.dims[2]}else{if(y!==a.dims[2])throw new Error('Input "key" and "value" shall have the same dim 2 (kv_sequence_length)');T=a.dims[1]*a.dims[3],k=!0}}let E=!1;if(n&&z.size(n.dims)>0)throw new Error("Key padding mask is not supported");if(u&&z.size(u.dims)>0){if(u.dims.length!==4)throw new Error('Input "attention_bias" is expected to have 4 dimensions');if(u.dims[0]!==f||u.dims[1]!==t.numHeads||u.dims[2]!==h||u.dims[3]!==$)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:f,sequenceLength:h,pastSequenceLength:_,kvSequenceLength:y,totalSequenceLength:$,maxSequenceLength:b,inputHiddenSize:0,hiddenSize:l,vHiddenSize:T,headSize:v,vHeadSize:Math.floor(T/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:S,scale:t.scale,broadcastResPosBias:E,passPastInKv:k,qkvFormat:x}},dh=e=>fe({...e}),ea=fe({perm:[0,2,1,3]}),ll=(e,t,r,i,a,s,n)=>{let u=[i,a,s],d=z.size(u),p=[{type:12,data:d},{type:12,data:n},{type:12,data:s}],f=h=>{let l=H("qkv_with_bias",t.dataType,u),y=R("qkv",t.dataType,u),_=R("bias",r.dataType,u),b=[{name:"output_size",type:"u32"},{name:"bias_offset",type:"u32"},{name:"hidden_size",type:"u32"}];return`
  ${h.registerUniforms(b).declareVariables(y,_,l)}
  ${h.mainStart()}
    ${h.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let bias_offset_idx = (global_idx % uniforms.hidden_size) + uniforms.bias_offset;

    qkv_with_bias[global_idx] = qkv[global_idx] + bias[bias_offset_idx];
  }`};return e.compute({name:"MultiHeadAttentionAddBias",shaderCache:{inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:u,dataType:t.dataType,gpuDataType:0}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p}),getShaderSource:f},{inputs:[t,r],outputs:[-1]})[0]},lr=(e,t,r,i,a,s,n,u)=>{let d=s;if(n&&z.size(n.dims)>0){if(i===1)throw new Error("AddBiasReshape is not implemented. Please export your model with packed QKV or KV");return d=ll(e,s,n,t,i,r*a,u),d=d.reshape([t,i,r,a]),r===1||i===1?d:e.compute(Pe(d,ea.perm),{inputs:[d],outputs:[-1]})[0]}else return s.dims.length===3&&(d=s.reshape([t,i,r,a])),r===1||i===1?d:e.compute(Pe(d,ea.perm),{inputs:[d],outputs:[-1]})[0]},ph=(e,t)=>{let r=ul(e.inputs,t),i=e.inputs[0],a=ze(e.inputs,1),s=ze(e.inputs,2),n=ze(e.inputs,3),u=ze(e.inputs,4),d=ze(e.inputs,5),p=ze(e.inputs,6),f=ze(e.inputs,7);if(i.dims.length===5)throw new Error("Packed QKV is not implemented");if((a==null?void 0:a.dims.length)===5)throw new Error("Packed KV is not implemented");let h=a&&s&&a.dims.length===4&&s.dims.length===4,l=lr(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,i,n,0);if(h)return pr(e,l,a,s,u,void 0,p,f,d,r);if(!a||!s)throw new Error("key and value must be provided");let y=lr(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.headSize,a,n,r.hiddenSize),_=lr(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.vHeadSize,s,n,2*r.hiddenSize);pr(e,l,y,_,u,void 0,p,f,d,r)}}),dl,pl,cl,hl,Ba,hh,fh,mh=P(()=>{X(),re(),ve(),ie(),dl=e=>{if(!e||e.length<1)throw new Error("too few inputs")},pl=(e,t)=>{let r=[],i=t.numOutputs;return e[1].dims[0]>0&&(e[1].getBigInt64Array().forEach(a=>r.push(Number(a))),i=r.length),fe({numOutputs:i,axis:t.axis,splitSizes:r})},cl=e=>`
fn calculateOutputIndex(index: u32) -> u32 {
    for (var i: u32 = 0u; i < ${e}u; i += 1u ) {
    if (index < ${j("uniforms.size_in_split_axis","i",e)}) {
        return i;
    }
    }
    return ${e}u;
}`,hl=e=>{let t=e.length,r=[];for(let i=0;i<t;++i){let a=e[i].setByIndices("indices","input[global_idx]");t===1?r.push(a):i===0?r.push(`if (output_number == ${i}u) { ${a} }`):i===t-1?r.push(`else { ${a} }`):r.push(`else if (output_number == ${i}) { ${a} }`)}return`
      fn writeBufferData(output_number: u32, indices: ${e[0].type.indices}, global_idx: u32) {
        ${r.join(`
`)}
      }`},Ba=(e,t)=>{let r=e[0].dims,i=z.size(r),a=e[0].dataType,s=z.normalizeAxis(t.axis,r.length),n=new Array(t.numOutputs),u=R("input",a,r.length),d=new Array(t.numOutputs),p=[],f=[],h=0,l=[{type:12,data:i}];for(let _=0;_<t.numOutputs;_++){h+=t.splitSizes[_],d[_]=h;let b=r.slice();b[s]=t.splitSizes[_],f.push(b),n[_]=H(`output${_}`,a,b.length),p.push({dims:f[_],dataType:e[0].dataType})}l.push({type:12,data:d},...K(r,...f));let y=_=>`
  ${_.registerUniform("input_size","u32").registerUniform("size_in_split_axis","u32",d.length).declareVariables(u,...n)}
  ${cl(d.length)}
  ${hl(n)}

  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.input_size")}

    var indices = ${u.offsetToIndices("global_idx")};
    var index = ${u.indicesGet("indices",s)};
    let output_number = calculateOutputIndex(index);
    if (output_number != 0) {
      index -= ${j("uniforms.size_in_split_axis","output_number - 1u",d.length)};
      ${u.indicesSet("indices",s,"index")};
    }
    writeBufferData(output_number, indices, global_idx);
  }`;return{name:"Split",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getShaderSource:y,getRunData:()=>({outputs:p,dispatchGroup:{x:Math.ceil(i/64)},programUniforms:l})}},hh=(e,t)=>{dl(e.inputs);let r=e.inputs.length===1?t:pl(e.inputs,t);e.compute(Ba(e.inputs,r),{inputs:[0]})},fh=e=>{let t=e.axis,r=e.splitSizes,i=e.numOutputs<0?r.length:e.numOutputs;if(i!==r.length)throw new Error("numOutputs and splitSizes lengh must be equal");return fe({axis:t,numOutputs:i,splitSizes:r})}}),fl,ml,ta,gh,Dg=P(()=>{ve(),an(),ch(),mh(),bt(),fl=(e,t)=>{if(t.doRotary)throw new Error("GroupQuerryAttention do_rotary attribute is not supported");if(t.doRotary&&e.length<=7)throw new Error("cos_cache and sin_cache inputs are required if do_rotary is specified");let r=e[0],i=e[1],a=e[2],s=e[3],n=e[4];if(t.localWindowSize!==-1)throw new Error("Local attention is not supported");if(t.softcap!==0)throw new Error("Softcap is not supported");if(t.rotaryInterleaved!==0)throw new Error("Rotary interleaved is not supported");if(t.smoothSoftmax)throw new Error("Smooth softmax is not supported");if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let u=!1,d=r.dims[0],p=r.dims[1],f=r.dims.length===3?u?r.dims[2]/3:r.dims[2]:t.numHeads*r.dims[4],h=p,l=0,y=!i||i.dims.length===0,_=Math.floor(y?f/(t.numHeads+2*t.kvNumHeads):f/t.numHeads);y&&(f=_*t.numHeads);let b=s&&s.dims.length!==0,v=n&&n.dims.length!==0;if(b&&s.dims.length===4&&s.dims[0]===d&&s.dims[1]!==t.kvNumHeads&&s.dims[2]===t.kvNumHeads&&s.dims[3]===_)throw new Error("BSNH pastKey/pastValue is not supported");if(b&&v){if(s.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(n.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');l=s.dims[2]}else if(b||v)throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let x=1;if(i&&i.dims.length>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(r.dims[2]%i.dims[2]!==0)throw new Error('Dimension 2 of "query" should be a multiple of "key"');h=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==_)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');h=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==_)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');h=i.dims[2]}}else{if(r.dims.length!==3&&r.dims.length!==5)throw new Error('Input "query" is expected to have 3 or 5 dimensions when key is empty');if(r.dims.length===5&&(r.dims[2]!==t.numHeads||r.dims[3]!==3))throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');x=3}let $=0,S=!1,k=t.kvNumHeads?_*t.kvNumHeads:f;if(a&&a.dims.length>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(h!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');k=a.dims[2]}else{if(h!==a.dims[2])throw new Error('Input "past_key" and "past_value" shall have the same dim 2 (kv_sequence_length)');k=a.dims[1]*a.dims[3],S=!0}}let T=e.length>4?e[5]:void 0;if(T&&T.dims.length!==1&&T.dims[0]!==d)throw new Error('Input "seqlens" is expected to have 1 dimension and the same dim 0 as batch_size');return{batchSize:d,sequenceLength:p,pastSequenceLength:l,kvSequenceLength:h,totalSequenceLength:-1,maxSequenceLength:-1,inputHiddenSize:0,hiddenSize:f,vHiddenSize:k,headSize:_,vHeadSize:Math.floor(k/t.kvNumHeads),numHeads:t.numHeads,kvNumHeads:t.kvNumHeads,nReps:t.numHeads/t.kvNumHeads,pastPresentShareBuffer:!1,maskType:$,scale:t.scale,broadcastResPosBias:!1,passPastInKv:S,qkvFormat:x}},ml=fe({perm:[0,2,1,3]}),ta=(e,t,r)=>{let i=t,a=r.kvNumHeads;return t.dims.length===3&&r.kvSequenceLength!==0&&(i=t.reshape([r.batchSize,r.kvSequenceLength,a,r.headSize]),i=e.compute(Pe(i,ml.perm),{inputs:[i],outputs:[-1]})[0]),i},gh=(e,t)=>{var v;let r=fl(e.inputs,t);if(e.inputs[0].dims.length===5)throw new Error("Packed QKV is not implemented");if(((v=e.inputs[1])==null?void 0:v.dims.length)===5)throw new Error("Packed KV is not implemented");let i=e.inputs[0],a=e.inputs[1]&&e.inputs[1].dims.length>0?e.inputs[1]:void 0,s=e.inputs[2]&&e.inputs[2].dims.length>0?e.inputs[2]:void 0,n=e.inputs[3]&&e.inputs[3].dims.length!==0?e.inputs[3]:void 0,u=e.inputs[4]&&e.inputs[4].dims.length!==0?e.inputs[4]:void 0,d=e.inputs.length>4?e.inputs[5]:void 0,p=e.inputs.length>5?e.inputs[6]:void 0,f=r.kvNumHeads?r.kvNumHeads:r.numHeads,h=fe({axis:2,numOutputs:3,splitSizes:[r.numHeads*r.headSize,f*r.headSize,f*r.headSize]}),[l,y,_]=!a&&!s?e.compute(Ba([i],h),{inputs:[i],outputs:[-1,-1,-1]}):[i,a,s],b=lr(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,l,void 0,0);pr(e,b,ta(e,y,r),ta(e,_,r),void 0,void 0,n,u,void 0,r,d,p)}}),ra,gl,yl,yh,Rg=P(()=>{X(),re(),bt(),ie(),ra=(e,t,r,i,a,s,n,u)=>{let d=be(s),p=d===1?"f32":`vec${d}f`,f=d===1?"vec2f":`mat2x${d}f`,h=a*n,l=64;h===1&&(l=256);let y=[a,n,s/d],_=[a,n,2],b=["rank","type","type"],v=[];v.push(...K(y,_));let x=$=>{let S=R("x",t.dataType,3,d),k=R("scale",r.dataType,r.dims),T=R("bias",i.dataType,i.dims),E=H("output",1,3,2),I=[S,k,T,E];return`
  var<workgroup> workgroup_shared : array<${f}, ${l}>;
  const workgroup_size = ${l}u;
  ${$.declareVariables(...I)}
  ${$.mainStart(l)}
    let batch = workgroup_index / uniforms.x_shape[1];
    let channel = workgroup_index % uniforms.x_shape[1];
    let hight = uniforms.x_shape[2];
    // initialize workgroup memory
    var sum = ${p}(0);
    var squared_sum = ${p}(0);
    for (var h = local_idx; h < hight; h += workgroup_size) {
      let value = ${p}(${S.get("batch","channel","h")});
      sum += value;
      squared_sum += value * value;
    }
    workgroup_shared[local_idx] = ${f}(sum, squared_sum);
    workgroupBarrier();

    for (var currSize = workgroup_size >> 1;  currSize > 0; currSize = currSize >> 1) {
      if (local_idx < currSize) {
        workgroup_shared[local_idx] = workgroup_shared[local_idx] + workgroup_shared[local_idx + currSize];
      }
      workgroupBarrier();
    }
    if (local_idx == 0) {
      let sum_final = ${yt("workgroup_shared[0][0]",d)} / f32(hight * ${d});
      let squared_sum_final = ${yt("workgroup_shared[0][1]",d)} / f32(hight * ${d});

      let inv_std_dev = inverseSqrt(squared_sum_final - sum_final * sum_final + f32(${u}));
      let channel_scale = inv_std_dev * f32(scale[channel]);
      let channel_shift = f32(bias[channel]) - sum_final * channel_scale;
      output[workgroup_index] = vec2f(channel_scale, channel_shift);
    }
  }`};return e.compute({name:"InstanceNormComputeChannelScaleShift",shaderCache:{hint:`${d};${u};${l}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:_,dataType:1}],dispatchGroup:{x:h},programUniforms:v}),getShaderSource:x},{inputs:[t,r,i],outputs:[-1]})[0]},gl=(e,t,r)=>{let i=t[0].dims,a=i,s=2,n=i[0],u=i[1],d=z.sizeFromDimension(i,s),p=be(d),f=z.size(a)/p,h=ra(e,t[0],t[1],t[2],n,d,u,r.epsilon),l=[n,u,d/p],y=[n,u],_=["type","none"],b=v=>{let x=R("x",t[0].dataType,l.length,p),$=R("scale_shift",1,y.length,2),S=H("output",t[0].dataType,l.length,p),k=[x,$,S];return`
  ${v.registerUniform("output_size","u32").declareVariables(...k)}
  ${v.mainStart()}
  ${v.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let outputIndices = ${S.offsetToIndices("global_idx")};
      let batch = outputIndices[0];
      let channel = outputIndices[1];
      let scale_shift = ${$.getByIndices("vec2<u32>(batch, channel)")};
      let value = ${x.getByOffset("global_idx")} * ${S.type.value}(scale_shift.x) + ${S.type.value}(scale_shift.y);
      ${S.setByOffset("global_idx","value")};
  }`};e.compute({name:"InstanceNormalization",shaderCache:{hint:`${p}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:[{type:12,data:f},...K(l,y,l)]}),getShaderSource:b},{inputs:[t[0],h]})},yl=(e,t,r)=>{let i=t[0].dims,a=i,s=i[0],n=i[i.length-1],u=z.sizeFromDimension(i,1)/n,d=be(n),p=z.size(a)/d,f=[{type:12,data:u},{type:12,data:Math.floor(n/d)}],h=["type","type"],l=!1,y=[0,i.length-1];for(let x=0;x<i.length-2;x++)l=l||i[x+1]!==1,y.push(x+1);l=l&&i[i.length-1]!==1;let _=l?e.compute(Pe(e.inputs[0],y),{inputs:[e.inputs[0]],outputs:[-1]})[0]:e.inputs[0].reshape(Array.from({length:i.length},(x,$)=>i[y[$]])),b=ra(e,_,t[1],t[2],s,u,n,r.epsilon),v=x=>{let $=Te(t[0].dataType),S=d===1?"vec2f":`mat${d}x2f`,k=I=>{let D=I===0?"x":"y",M=d===1?"f32":`vec${d}f`;switch(d){case 1:return`${$}(${M}(scale.${D}))`;case 2:return`vec2<${$}>(${M}(scale[0].${D}, scale[1].${D}))`;case 4:return`vec4<${$}>(${M}(scale[0].${D}, scale[1].${D}, scale[2].${D}, scale[3].${D}))`;default:throw new Error(`Not supported compoents ${d}`)}},T=R("input",t[0].dataType,t[0].dims,d),E=H("output",t[0].dataType,a,d);return`
  @group(0) @binding(0) var<storage, read> input : array<${T.type.storage}>;
  @group(0) @binding(1) var<storage, read> scale_input : array<${S}>;
  @group(0) @binding(2) var<storage, read_write> output : array<${E.type.storage}>;
  struct Uniforms {H: u32, C : u32};
  @group(0) @binding(3) var<uniform> uniforms: Uniforms;

  ${x.mainStart()}
    let current_image_number = global_idx / (uniforms.C * uniforms.H);
    let current_channel_number = global_idx % uniforms.C;

    let scale_offset = current_image_number * uniforms.C + current_channel_number;
    let scale = scale_input[scale_offset];
    output[global_idx] = fma(input[global_idx], ${k(0)}, ${k(1)});
  }`};e.compute({name:"InstanceNormalizationNHWC",shaderCache:{hint:`${d}`,inputDependencies:h},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:f}),getShaderSource:v},{inputs:[t[0],b]})},yh=(e,t)=>{t.format==="NHWC"?yl(e,e.inputs,t):gl(e,e.inputs,t)}}),_l,bl,_h,Bg=P(()=>{X(),re(),ie(),_l=e=>{if(!e||e.length<2)throw new Error("layerNorm requires at least 2 inputs.")},bl=(e,t,r)=>{let i=t.simplified,a=e[0].dims,s=e[1],n=!i&&e[2],u=a,d=z.normalizeAxis(t.axis,a.length),p=z.sizeToDimension(a,d),f=z.sizeFromDimension(a,d),h=z.size(s.dims),l=n?z.size(n.dims):0;if(h!==f||n&&l!==f)throw new Error(`Size of X.shape()[axis:] == ${f}.
       Size of scale and bias (if provided) must match this.
       Got scale size of ${h} and bias size of ${l}`);let y=[];for(let T=0;T<a.length;++T)T<d?y.push(a[T]):y.push(1);let _=be(f),b=["type","type"],v=[{type:12,data:p},{type:1,data:f},{type:12,data:Math.floor(f/_)},{type:1,data:t.epsilon}];n&&b.push("type");let x=r>1,$=r>2,S=T=>{let E=Te(e[0].dataType),I=[R("x",e[0].dataType,e[0].dims,_),R("scale",s.dataType,s.dims,_)];n&&I.push(R("bias",n.dataType,n.dims,_)),I.push(H("output",e[0].dataType,u,_)),x&&I.push(H("mean_data_output",1,y)),$&&I.push(H("inv_std_output",1,y));let D=[{name:"norm_count",type:"u32"},{name:"norm_size",type:"f32"},{name:"norm_size_vectorized",type:"u32"},{name:"epsilon",type:"f32"}];return`
  ${T.registerUniforms(D).declareVariables(...I)}
  ${T.mainStart()}
    ${T.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.norm_count")}
    let offset = global_idx * uniforms.norm_size_vectorized;
    var mean_vector = ${Ta("f32",_)};
    var mean_square_vector = ${Ta("f32",_)};

    for (var h: u32 = 0u; h < uniforms.norm_size_vectorized; h++) {
      let value = ${Wt(E,_,"x[h + offset]")};
      mean_vector += value;
      mean_square_vector += value * value;
    }
    let mean = ${yt("mean_vector",_)} / uniforms.norm_size;
    let inv_std_dev = inverseSqrt(${yt("mean_square_vector",_)} / uniforms.norm_size ${i?"":"- mean * mean"} + uniforms.epsilon);

    for (var j: u32 = 0; j < uniforms.norm_size_vectorized; j++) {
      let f32input = ${Wt(E,_,"x[j + offset]")};
      let f32scale = ${Wt(E,_,"scale[j]")};
      output[j + offset] = ${I[0].type.value}((f32input ${i?"":"- mean"}) * inv_std_dev * f32scale
        ${n?`+ ${Wt(E,_,"bias[j]")}`:""}
      );
    }

    ${x?"mean_data_output[global_idx] = mean":""};
    ${$?"inv_std_output[global_idx] = inv_std_dev":""};
  }`},k=[{dims:u,dataType:e[0].dataType}];return x&&k.push({dims:y,dataType:1}),$&&k.push({dims:y,dataType:1}),{name:"LayerNormalization",shaderCache:{hint:`${_};${r};${i}`,inputDependencies:b},getRunData:()=>({outputs:k,dispatchGroup:{x:Math.ceil(p/64)},programUniforms:v}),getShaderSource:S}},_h=(e,t)=>{_l(e.inputs),e.compute(bl(e.inputs,t,e.outputCount))}}),wl,bh,Ng=P(()=>{re(),ln(),dn(),wl=e=>{if(!e||e.length!==2)throw new Error("MatMul requires 2 inputs.");if(e[0].dims[e[0].dims.length-1]!==e[1].dims[e[1].dims.length-2])throw new Error("shared dimension does not match.")},bh=e=>{wl(e.inputs);let t=Lt.calcShape(e.inputs[0].dims,e.inputs[1].dims,!0);if(!t)throw new Error("Can't use matmul on the given tensors");let r=t[t.length-1],i=e.inputs[0].dims[e.inputs[0].dims.length-1];if(r<8&&i<8)e.compute(un(e.inputs,{activation:""},t));else{let a=t[t.length-2],s=z.size(e.inputs[0].dims.slice(0,-2)),n=z.size(e.inputs[1].dims.slice(0,-2));if(s!==1&&a===1&&n===1){let u=e.inputs[0].reshape([1,s,i]),d=e.inputs[1].reshape([1,i,r]),p=[1,s,r],f=[u,d];e.compute(Yr(f,{activation:""},t,p),{inputs:f})}else e.compute(Yr(e.inputs,{activation:""},t))}}}),$l,vl,xl,wh,$h,Mg=P(()=>{X(),re(),ve(),ie(),$l=(e,t)=>{if(e.length<3||e.length>4)throw new Error("MatMulNBits requires 3 or 4 inputs");let r=e[0],i=r.dims.length;if(r.dims[i-1]!==t.k)throw new Error("The last dim of input shape does not match the k value");let a=Math.floor((t.k+t.blockSize-1)/t.blockSize),s=t.blockSize/8*t.bits,n=e[1];if(!z.areEqual(n.dims,[t.n,a,s]))throw new Error("The second inputs must be 3D tensor with shape N X nBlocksPerCol X blobSize");let u=e[2].dims;if(z.size(u)!==t.n*a)throw new Error("scales input size error.");if(e.length===4){let d=e[3].dims,p=t.bits>4?t.n*a:t.n*Math.floor((a+1)/2);if(z.size(d)!==p)throw new Error("zeroPoints input size error.")}},vl=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],s=t.k,n=t.n,u=r.slice(0,i-2),d=z.size(u),p=e[1].dims[2]/4,f=e[0].dataType,h=be(t.k),l=be(p),y=be(n),_=u.concat([a,n]),b=a>1&&n/y%2===0?2:1,v=z.size(_)/y/b,x=64,$=[],S=[d,a,s/h],k=z.convertShape(e[1].dims).slice();k.splice(-1,1,p/l),$.push(...K(S)),$.push(...K(k)),$.push(...K(e[2].dims)),e.length===4&&$.push(...K(z.convertShape(e[3].dims)));let T=[d,a,n/y];$.push(...K(T));let E=I=>{let D=S.length,M=R("a",e[0].dataType,D,h),W=R("b",12,k.length,l),ee=R("scales",e[2].dataType,e[2].dims.length),te=[M,W,ee],U=e.length===4?R("zero_points",12,e[3].dims.length):void 0;U&&te.push(U);let ae=T.length,F=H("output",e[0].dataType,ae,y),G=Te(e[0].dataType),de=(()=>{switch(h){case 1:return`array<${G}, 8>`;case 2:return`mat4x2<${G}>`;case 4:return`mat2x4<${G}>`;default:throw new Error(`${h}-component is not supported.`)}})(),J=()=>{let N=`
          // reuse a data
            var input_offset = ${M.indicesToOffset(`${M.type.indices}(batch, row, word_offset)`)};
            var a_data: ${de};
            for (var j: u32 = 0; j < ${8/h}; j++) {
              a_data[j] = ${M.getByOffset("input_offset")};
              input_offset++;
            }
          `;for(let q=0;q<y*b;q++)N+=`
            b_value = ${l===1?`b${q}_data`:`b${q}_data[i]`};
            b_value_lower = unpack4xU8(b_value & b_mask);
            b_value_upper = unpack4xU8((b_value >> 4) & b_mask);
            b_quantized_values = ${de}(${Array.from({length:4},(se,we)=>`${G}(b_value_lower[${we}]), ${G}(b_value_upper[${we}])`).join(", ")});
            b_dequantized_values = ${h===1?`${de}(${Array.from({length:8},(se,we)=>`(b_quantized_values[${we}] - ${U?`zero_point${q}`:"zero_point"}) * scale${q}`).join(", ")});`:`(b_quantized_values - ${de}(${Array(8).fill(`${U?`zero_point${q}`:"zero_point"}`).join(",")})) * scale${q};`};
            workgroup_shared[local_id.x * ${b} + ${Math.floor(q/y)}]${y>1?`[${q%y}]`:""} += ${Array.from({length:8/h},(se,we)=>`${h===1?`a_data[${we}] * b_dequantized_values[${we}]`:`dot(a_data[${we}], b_dequantized_values[${we}])`}`).join(" + ")};
          `;return N},Z=()=>{let N=`
            var col_index = col * ${y};
            ${U?`
            let zero_point_bytes_per_col = (nBlocksPerCol + 1) / 2;
            var zero_point_byte_count: u32;
            var zero_point_word_index: u32;
            var zero_point_byte_offset: u32;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            var zero_point_bits_offset: u32;
            var zero_point_word: u32;`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${G}(8);`}
            `;for(let q=0;q<y*b;q++)N+=`
            let scale${q} = ${ee.getByOffset("col_index * nBlocksPerCol + block")};
            ${U?`
            zero_point_byte_count = col_index * zero_point_bytes_per_col + (block >> 0x1u);
            zero_point_word_index = zero_point_byte_count >> 0x2u;
            zero_point_byte_offset = zero_point_byte_count & 0x3u;
            zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            zero_point_word = ${U.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point${q} = ${G}((zero_point_word) & 0xFu);`:""}
            col_index += 1;`;return N},ue=()=>{let N=`col_index = col * ${y};`;for(let q=0;q<y*b;q++)N+=`
            let b${q}_data = ${W.getByIndices(`${W.type.indices}(col_index, block, word)`)};
            col_index += 1;`;return N+=`
            var b_value: u32;
            let b_mask: u32 = 0x0F0F0F0Fu;
            var b_value_lower: vec4<u32>;
            var b_value_upper: vec4<u32>;
            var b_quantized_values: ${de};
            var b_dequantized_values: ${de};`,N};return`
        var<workgroup> workgroup_shared: array<${F.type.value}, ${b*x}>;
        ${I.declareVariables(...te,F)}
        ${I.mainStart([x,1,1])}
          let output_indices = ${F.offsetToIndices(`(global_idx / ${x}) * ${b}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let nBlocksPerCol = uniforms.b_shape[1];

          for (var block = local_id.x; block < nBlocksPerCol; block += ${x}) {
            //process one block
            var word_offset: u32 = block * ${t.blockSize/h};
            ${Z()}
            for (var word: u32 = 0; word < ${p}; word += ${l}) {
              ${ue()}
              for (var i: u32 = 0; i < ${l}; i++) {
                ${J()}
                word_offset += ${8/h};
              }
            }
          }
          workgroupBarrier();

          if (local_id.x < ${b}) {
            var output_value: ${F.type.value} = ${F.type.value}(0);
            var workgroup_shared_offset: u32 = local_id.x;
            for (var b: u32 = 0u; b < ${x}u; b++) {
              output_value += workgroup_shared[workgroup_shared_offset];
              workgroup_shared_offset += ${b};
            }
            ${F.setByIndices(`${F.type.indices}(batch, row, col + local_id.x)`,"output_value")};
          }
        }`};return{name:"MatMulNBits",shaderCache:{hint:`${t.blockSize};${t.bits};${h};${l};${y};${b};${x}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:_,dataType:f}],dispatchGroup:{x:v},programUniforms:$}),getShaderSource:E}},xl=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],s=t.k,n=t.n,u=r.slice(0,i-2),d=z.size(u),p=e[1].dims[2]/4,f=e[0].dataType,h=be(t.k),l=be(p),y=u.concat([a,n]),_=128,b=n%8===0?8:n%4===0?4:1,v=_/b,x=v*l*8,$=x/h,S=x/t.blockSize,k=z.size(y)/b,T=[],E=[d,a,s/h],I=z.convertShape(e[1].dims).slice();I.splice(-1,1,p/l),T.push(...K(E)),T.push(...K(I)),T.push(...K(e[2].dims)),e.length===4&&T.push(...K(z.convertShape(e[3].dims)));let D=[d,a,n];T.push(...K(D));let M=W=>{let ee=E.length,te=R("a",e[0].dataType,ee,h),U=R("b",12,I.length,l),ae=R("scales",e[2].dataType,e[2].dims.length),F=[te,U,ae],G=e.length===4?R("zero_points",12,e[3].dims.length):void 0;G&&F.push(G);let de=D.length,J=H("output",e[0].dataType,de),Z=Te(e[0].dataType),ue=()=>{switch(h){case 1:return`
          let a_data0 = vec4<${Z}>(sub_a[word_offset], sub_a[word_offset + 1], sub_a[word_offset + 2], sub_a[word_offset + 3]);
          let a_data1 = vec4<${Z}>(sub_a[word_offset + 4], sub_a[word_offset + 5], sub_a[word_offset + 6], sub_a[word_offset + 7]);`;case 2:return`
          let a_data0 = vec4<${Z}>(sub_a[word_offset], sub_a[word_offset + 1]);
          let a_data1 = vec4<${Z}>(sub_a[word_offset + 2], sub_a[word_offset + 3]);`;case 4:return`
          let a_data0 = sub_a[word_offset];
          let a_data1 = sub_a[word_offset + 1];`;default:throw new Error(`${h}-component is not supported.`)}};return`
        var<workgroup> sub_a: array<${te.type.value}, ${$}>;
        var<workgroup> inter_results: array<array<${J.type.value}, ${v}>, ${b}>;
        ${W.declareVariables(...F,J)}
        ${W.mainStart([v,b,1])}
          let output_indices = ${J.offsetToIndices(`workgroup_index * ${b}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let n_blocks_per_col = uniforms.b_shape[1];
          let num_tiles =  (n_blocks_per_col - 1) / ${S} + 1;

          // Loop over shared dimension.
          for (var tile: u32 = 0; tile < num_tiles; tile += 1) {
            let a_col_start = tile * ${$};
            // load one tile A data into shared memory.
            for (var a_offset = local_idx; a_offset < ${$}; a_offset += ${_})
            {
              let a_col = a_col_start + a_offset;
              if (a_col < uniforms.a_shape[2])
              {
                sub_a[a_offset] = ${te.getByIndices(`${te.type.indices}(batch, row, a_col)`)};
              } else {
                sub_a[a_offset] = ${te.type.value}(0);
              }
            }
            workgroupBarrier();

            // each thread process one block
            let b_row = col + local_id.y;
            let block = tile * ${S} + local_id.x;
            ${G?`
            let zero_point_bytes_per_col = (n_blocks_per_col + 1) / 2;
            let zero_point_byte_count = b_row * zero_point_bytes_per_col + (block >> 0x1u);
            let zero_point_word_index = zero_point_byte_count >> 0x2u;
            let zero_point_byte_offset = zero_point_byte_count & 0x3u;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            let zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            let zero_point_word = ${G.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point = ${Z}((zero_point_word) & 0xFu);`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${Z}(8);`}
            let scale = ${ae.getByOffset("b_row * n_blocks_per_col + block")};
            let b_data = ${U.getByIndices(`${U.type.indices}(b_row, block, 0)`)};
            var word_offset = local_id.x * ${t.blockSize/h};
            for (var i: u32 = 0; i < ${l}; i++) {
              ${ue()}
              let b_value = ${l===1?"b_data":"b_data[i]"};
              let b_value_lower = unpack4xU8(b_value & 0x0F0F0F0Fu);
              let b_value_upper = unpack4xU8((b_value >> 4) & 0x0F0F0F0Fu);
              let b_quantized_values = mat2x4<${Z}>(${Array.from({length:4},(N,q)=>`${Z}(b_value_lower[${q}]), ${Z}(b_value_upper[${q}])`).join(", ")});
              let b_dequantized_values = (b_quantized_values - mat2x4<${Z}>(${Array(8).fill("zero_point").join(",")})) * scale;
              inter_results[local_id.y][local_id.x] += ${Array.from({length:2},(N,q)=>`${`dot(a_data${q}, b_dequantized_values[${q}])`}`).join(" + ")};
              word_offset += ${8/h};
            }
            workgroupBarrier();
          }

          if (local_idx < ${b}) {
            var output_value: ${J.type.value} = ${J.type.value}(0);
            for (var b = 0u; b < ${v}; b++) {
              output_value += inter_results[local_idx][b];
            }
            if (col + local_idx < uniforms.output_shape[2])
            {
              ${J.setByIndices(`${J.type.indices}(batch, row, col + local_idx)`,"output_value")}
            }
          }
        }`};return{name:"BlockwiseMatMulNBits32",shaderCache:{hint:`${t.blockSize};${h};${l};${v};${b}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:y,dataType:f}],dispatchGroup:{x:k},programUniforms:T}),getShaderSource:M}},wh=(e,t)=>{$l(e.inputs,t),t.blockSize===32&&e.adapterInfo.isVendor("intel")&&e.adapterInfo.isArchitecture("gen-12lp")?e.compute(xl(e.inputs,t)):e.compute(vl(e.inputs,t))},$h=e=>fe(e)}),kl,Sl,Tl,Cl,El,Il,zl,Al,vh,Pg=P(()=>{X(),re(),ie(),kl=e=>{if(!e||e.length<1)throw new Error("Too few inputs");if(e[0].dataType!==1&&e[0].dataType!==10)throw new Error("Input type must be float or float16.");if(e.length>=2){let t=e[0].dims.length*2===e[1].dims[0];if(e.length===4&&(t=e[3].dims[0]*2===e[1].dims[0]),!t)throw new Error("The pads should be a 1D tensor of shape [2 * input_rank] or [2 * num_axes].")}},Sl=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
            k = i32(${e.indicesGet("indices",a)}) - ${j("uniforms.pads",a,r)};
            if (k < 0) {
              break;
            }
            if (k >= i32(${j("uniforms.x_shape",a,t)})) {
              break;
            }
            offset += k * i32(${j("uniforms.x_strides",a,t)});
        `;return`
          value = ${e.type.value}(uniforms.constant_value);
          for (var i = 0; i < 1; i++) {
            var offset = 0;
            var k = 0;
            ${i}
            value = x[offset];
          }
      `},Tl=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${j("uniforms.pads",a,r)};
                if (k < 0) {
                  k = -k;
                }
                {
                  let _2n_1 = 2 * (i32(${j("uniforms.x_shape",a,t)}) - 1);
                  k = k % _2n_1;
                  if(k >= i32(${j("uniforms.x_shape",a,t)})) {
                    k = _2n_1 - k;
                  }
                }
                offset += k * i32(${j("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},Cl=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${j("uniforms.pads",a,r)};
                if (k < 0) {
                  k = 0;
                }
                if (k >= i32(${j("uniforms.x_shape",a,t)})) {
                  k = i32(${j("uniforms.x_shape",a,t)}) - 1;
                }
                offset += k * i32(${j("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},El=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${j("uniforms.pads",a,r)};
                if (k < 0)  {
                  k += i32(${j("uniforms.x_shape",a,t)}]);
                }
                if (k >= i32(${j("uniforms.x_shape",a,t)})) {
                  k -= i32(${j("uniforms.x_shape",a,t)});
                }
                offset += k * i32(${j("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},Il=(e,t,r)=>{switch(r.mode){case 0:return Sl(e,t,r.pads.length);case 1:return Tl(e,t,r.pads.length);case 2:return Cl(e,t,r.pads.length);case 3:return El(e,t,r.pads.length);default:throw new Error("Invalid mode")}},zl=(e,t)=>{let r=z.padShape(e[0].dims.slice(),t.pads),i=e[0].dims,a=z.size(r),s=[{type:12,data:a},{type:6,data:t.pads}],n=e.length>=3&&e[2].data;t.mode===0&&s.push({type:n?e[2].dataType:1,data:t.value}),s.push(...K(e[0].dims,r));let u=["rank"],d=p=>{let f=H("output",e[0].dataType,r.length),h=R("x",e[0].dataType,i.length),l=h.type.value,y=Il(f,i.length,t),_=[{name:"output_size",type:"u32"},{name:"pads",type:"i32",length:t.pads.length}];return t.mode===0&&_.push({name:"constant_value",type:n?l:"f32"}),`
            ${p.registerUniforms(_).declareVariables(h,f)}
            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

            let indices = ${f.offsetToIndices("global_idx")};

            var value = ${l}(0);
            ${y}
            output[global_idx] = value;
        }`};return{name:"Pad",shaderCache:{hint:`${t.mode}${n}`,inputDependencies:u},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(z.size(r)/64)},programUniforms:s}),getShaderSource:d}},Al=(e,t)=>{if(e.length>1){let r=e[1].getBigInt64Array(),i=e.length>=3&&e[2].data?e[2].dataType===10?e[2].getUint16Array()[0]:e[2].getFloat32Array()[0]:0,a=e[0].dims.length,s=new Int32Array(2*a).fill(0);if(e.length>=4){let u=e[3].getBigInt64Array();for(let d=0;d<u.length;d++)s[Number(u[d])]=Number(r[d]),s[Number(u[d])+a]=Number(r[d+u.length])}else r.forEach((u,d)=>s[Number(d)]=Number(u));let n=[];return s.forEach(u=>n.push(u)),{mode:t.mode,value:i,pads:n}}else return t},vh=(e,t)=>{kl(e.inputs);let r=Al(e.inputs,t);e.compute(zl(e.inputs,r),{inputs:[0]})}}),tr,ia,aa,na,sa,Ol,Dl,oa,ua,xh,kh,la,Sh,Th,da,Ch,Eh,Ih,zh,Vg=P(()=>{Ke(),X(),re(),ie(),tr=e=>{if(ge.webgpu.validateInputContent&&(!e||e.length!==1))throw new Error("Pool ops requires 1 input.")},ia=(e,t,r)=>{let i=t.format==="NHWC",a=e.dims.slice();i&&a.splice(1,0,a.pop());let s=Object.hasOwnProperty.call(t,"dilations"),n=t.kernelShape.slice(),u=t.strides.slice(),d=s?t.dilations.slice():[],p=t.pads.slice();Kr.adjustPoolAttributes(r,a,n,u,d,p);let f=Kr.computePoolOutputShape(r,a,u,d,n,p,t.autoPad),h=Object.assign({},t);s?Object.assign(h,{kernelShape:n,strides:u,pads:p,dilations:d,cacheKey:t.cacheKey}):Object.assign(h,{kernelShape:n,strides:u,pads:p,cacheKey:t.cacheKey});let l=f.slice();return l.push(l.splice(1,1)[0]),[h,i?l:f]},aa=(e,t)=>{let r=t.format==="NHWC",i=z.size(e),a=z.size(t.kernelShape),s=[{type:12,data:i},{type:12,data:a}],n=[{name:"outputSize",type:"u32"},{name:"kernelSize",type:"u32"}];if(t.kernelShape.length<=2){let u=t.kernelShape[t.kernelShape.length-1],d=t.strides[t.strides.length-1],p=t.pads[t.pads.length/2-1],f=t.pads[t.pads.length-1],h=!!(p+f);s.push({type:12,data:u},{type:12,data:d},{type:12,data:p},{type:12,data:f}),n.push({name:"kw",type:"u32"},{name:"sw",type:"u32"},{name:"pwStart",type:"u32"},{name:"pwEnd",type:"u32"});let l=!1;if(t.kernelShape.length===2){let y=t.kernelShape[t.kernelShape.length-2],_=t.strides[t.strides.length-2],b=t.pads[t.pads.length/2-2],v=t.pads[t.pads.length-2];l=!!(b+v),s.push({type:12,data:y},{type:12,data:_},{type:12,data:b},{type:12,data:v}),n.push({name:"kh",type:"u32"},{name:"sh",type:"u32"},{name:"phStart",type:"u32"},{name:"phEnd",type:"u32"})}return[s,n,!0,h,l]}else{if(r)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let u=z.computeStrides(t.kernelShape);s.push({type:12,data:u},{type:12,data:t.pads},{type:12,data:t.strides}),n.push({name:"kernelStrides",type:"u32",length:u.length},{name:"pads",type:"u32",length:t.pads.length},{name:"strides",type:"u32",length:t.strides.length});let d=t.pads.reduce((p,f)=>p+f);return[s,n,!!d,!1,!1]}},na=(e,t,r,i,a,s,n,u,d,p,f,h)=>{let l=a.format==="NHWC",y=t.type.value,_=H("output",t.type.tensor,i);if(a.kernelShape.length<=2){let b="",v="",x="",$=r-(l?2:1);if(f?b=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${$}] = indices[${$}] * uniforms.sw - uniforms.pwStart + i;
                  if (xIndices[${$}] < 0 || xIndices[${$}]
                      >= uniforms.x_shape[${$}]) {
                    pad++;
                    continue;
                  }
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${s}
                }`:b=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${$}] = indices[${$}] * uniforms.sw - uniforms.pwStart + i;
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${s}
                }`,a.kernelShape.length===2){let S=r-(l?3:2);h?v=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                  if (xIndices[${S}] < 0 || xIndices[${S}] >= uniforms.x_shape[${S}]) {
                    pad += i32(uniforms.kw);
                    continue;
                  }
              `:v=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                `,x=`
              }
            `}return`
            ${e.registerUniforms(d).declareVariables(t,_)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

              let indices = ${_.offsetToIndices("global_idx")};
              var xIndices = ${_.offsetToIndices("global_idx")};

              var value = ${y}(${u});
              var pad = 0;
              ${v}
              ${b}
              ${x}
              ${n}

              output[global_idx] = value;
            }`}else{if(l)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let b=a.kernelShape.length,v=a.pads.length,x="";return p?x=`
                if (xIndices[j] >= uniforms.x_shape[j]) {
                  pad++;
                  isPad = true;
                  break;
                }
              }
              if (!isPad) {
                let x_val = x[${t.indicesToOffset("xIndices")}];
                ${s}
              }`:x=`
              }
              let x_val = x[${t.indicesToOffset("xIndices")}];
              ${s}
            `,`
            ${e.registerUniforms(d).declareVariables(t,_)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
              let indices = ${_.offsetToIndices("global_idx")};
              var xIndices = ${_.offsetToIndices("global_idx")};

              var offsets: array<u32, ${b}>;

              var value = ${y}(${u});
              var pad = 0;
              var isPad = false;

              for (var i: u32 = 0u; i < uniforms.kernelSize; i++) {
                var offset = i;
                for (var j = 0u; j < ${b-1}u; j++) {
                  offsets[j] = offset / ${j("uniforms.kernelStrides","j",b)};
                  offset -= offsets[j] * ${j("uniforms.kernelStrides","j",b)};
                }
                offsets[${b-1}] = offset;

                isPad = false;
                for (var j = ${r-b}u; j < ${r}u; j++) {
                  xIndices[j] = indices[j] * ${j("uniforms.strides",`j - ${r-b}u`,b)}
                    + offsets[j - ${r-b}u] - ${j("uniforms.pads","j - 2u",v)};
                  ${x}
              }
              ${n}

              output[global_idx] = value;
            }`}},sa=e=>`${e.format};${e.ceilMode};${e.autoPad};${e.kernelShape.length}`,Ol=e=>`${sa(e)};${e.countIncludePad}`,Dl=e=>`${sa(e)};${e.storageOrder};${e.dilations}`,oa=e=>({format:e.format,autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],ceilMode:e.ceil_mode,kernelShape:e.kernel_shape,strides:e.strides,pads:e.pads}),ua=(e,t,r,i)=>{let[a,s]=ia(t,i,r),n=R("x",t.dataType,t.dims.length),u=n.type.value,d="value += x_val;",p="";a.countIncludePad?p+=`value /= ${u}(uniforms.kernelSize);`:p+=`value /= ${u}(i32(uniforms.kernelSize) - pad);`;let[f,h,l,y,_]=aa(s,a);f.push(...K(t.dims,s));let b=["rank"];return{name:e,shaderCache:{hint:`${i.cacheKey};${l};${y};${_}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:s,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(z.size(s)/64)},programUniforms:f}),getShaderSource:v=>na(v,n,t.dims.length,s.length,a,d,p,0,h,l,y,_)}},xh=e=>{let t=e.count_include_pad!==0,r=oa(e);if(r.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for AveragePool");let i={countIncludePad:t,...r,cacheKey:""};return{...i,cacheKey:Ol(i)}},kh=(e,t)=>{tr(e.inputs),e.compute(ua("AveragePool",e.inputs[0],!1,t))},la={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[]},Sh=e=>{let t=e.format;return{format:t,...la,cacheKey:t}},Th=(e,t)=>{tr(e.inputs),e.compute(ua("GlobalAveragePool",e.inputs[0],!0,t))},da=(e,t,r,i)=>{let[a,s]=ia(t,i,r),n=`
      value = max(x_val, value);
    `,u="",d=R("x",t.dataType,t.dims.length),p=["rank"],[f,h,l,y,_]=aa(s,a);return f.push(...K(t.dims,s)),{name:e,shaderCache:{hint:`${i.cacheKey};${l};${y};${_}`,inputDependencies:p},getRunData:()=>({outputs:[{dims:s,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(z.size(s)/64)},programUniforms:f}),getShaderSource:b=>na(b,d,t.dims.length,s.length,a,n,u,t.dataType===10?-65504:-1e5,h,l,y,_)}},Ch=(e,t)=>{tr(e.inputs),e.compute(da("MaxPool",e.inputs[0],!1,t))},Eh=e=>{let t=e.storage_order,r=e.dilations,i=oa(e);if(t!==0)throw new Error("column major storage order is not yet supported for MaxPool");if(i.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for MaxPool");let a={storageOrder:t,dilations:r,...i,cacheKey:""};return{...a,cacheKey:Dl(a)}},Ih=e=>{let t=e.format;return{format:t,...la,cacheKey:t}},zh=(e,t)=>{tr(e.inputs),e.compute(da("GlobalMaxPool",e.inputs[0],!0,t))}}),Rl,Bl,Ah,Oh,Ug=P(()=>{X(),re(),ve(),ie(),Rl=(e,t)=>{if(e.length<2||e.length>3)throw new Error("DequantizeLinear requires 2 or 3 inputs.");if(e.length===3&&e[1].dims===e[2].dims)throw new Error("x-scale and x-zero-point must have the same shape.");if(e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[0].dataType===6&&e.length>2)throw new Error("In the case of dequantizing int32 there is no zero point.");if(e[1].dims.length!==0&&e[1].dims.length!==1&&e[1].dims.length!==e[0].dims.length)throw new Error("scale input must be a scalar, a 1D tensor, or have the same rank as the input tensor.");if(e.length>2){if(e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[1].dims.length!==e[2].dims.length)throw new Error("scale and zero-point inputs must have the same rank.");if(!e[1].dims.map((r,i)=>r===e[2].dims[i]).reduce((r,i)=>r&&i,!0))throw new Error("scale and zero-point inputs must have the same shape.")}if(t.blockSize>0){if(e[1].dims.length===0||e[1].dims.length===1&&e[1].dims[0]===1)throw new Error("blockSize must be set only for block quantization.");if(!e[1].dims.map((a,s)=>s===t.axis||a===e[0].dims[s]).reduce((a,s)=>a&&s,!0))throw new Error("For block qunatization, scale input shape to match the input shape except for the axis");if(e[1].dims.length!==e[0].dims.length)throw new Error("For block qunatization the scale input rank must be the same as the x rank.");let r=e[0].dims[t.axis],i=e[1].dims[t.axis];if(t.blockSize<Math.ceil(r/i)||t.blockSize>Math.ceil(r/(i-1)-1))throw new Error("blockSize must be with in the range [ceil(dI / Si), ceil(dI / (Si - 1) - 1)].")}},Bl=(e,t)=>{let r=z.normalizeAxis(t.axis,e[0].dims.length),i=e[0].dataType,a=i===3,s=e[0].dims,n=e[1].dataType,u=z.size(s),d=i===3||i===2,p=d?[Math.ceil(z.size(e[0].dims)/4)]:e[0].dims,f=e[1].dims,h=e.length>2?e[2]:void 0,l=h?d?[Math.ceil(z.size(h.dims)/4)]:h.dims:void 0,y=f.length===0||f.length===1&&f[0]===1,_=y===!1&&f.length===1,b=be(u),v=y&&(!d||b===4),x=v?b:1,$=v&&!d?b:1,S=R("input",d?12:i,p.length,$),k=R("scale",n,f.length),T=h?R("zero_point",d?12:i,l.length):void 0,E=H("output",n,s.length,x),I=[S,k];T&&I.push(T);let D=[p,f];h&&D.push(l);let M=[{type:12,data:u/x},{type:12,data:r},{type:12,data:t.blockSize},...K(...D,s)],W=ee=>{let te=[{name:"output_size",type:"u32"},{name:"axis",type:"u32"},{name:"block_size",type:"u32"}];return`
      ${ee.registerUniforms(te).declareVariables(...I,E)}
      ${ee.mainStart()}
          ${ee.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let output_indices = ${E.offsetToIndices("global_idx")};

          // Set input x
          ${d?`
            let input = ${S.getByOffset("global_idx / 4")};
            let x_vec = ${a?"unpack4xI8(input)":"unpack4xU8(input)"};
            let x_value = ${x===1?"x_vec[global_idx % 4]":"x_vec"};`:`let x_value = ${S.getByOffset("global_idx")};`};

          // Set scale input
          ${y?`let scale_value= ${k.getByOffset("0")}`:_?`
            let scale_index = ${E.indicesGet("output_indices","uniforms.axis")};
            let scale_value= ${k.getByOffset("scale_index")};`:`
            var scale_indices: ${k.type.indices} = output_indices;
            let index = ${k.indicesGet("scale_indices","uniforms.axis")} / uniforms.block_size;
            ${k.indicesSet("scale_indices","uniforms.axis","index")};
            let scale_value= ${k.getByIndices("scale_indices")};`};

          // Set zero-point input
          ${T?y?d?`
                let zero_point_input = ${T.getByOffset("0")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value= zero_point_vec[0]`:`let zero_point_value = ${T.getByOffset("0")}`:_?d?`
                let zero_point_index = ${E.indicesGet("output_indices","uniforms.axis")};
                let zero_point_input = ${T.getByOffset("zero_point_index / 4")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_index % 4]`:`
                let zero_point_index = ${E.indicesGet("output_indices","uniforms.axis")};
                let zero_point_value = ${T.getByOffset("zero_point_index")};`:d?`
                let zero_point_offset = ${k.indicesToOffset("scale_indices")};
                let zero_point_input = ${T.getByOffset("zero_point_offset / 4")};
                let zero_point_vec = ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_offset % 4];`:`let zero_point_value = ${T.getByIndices("scale_indices")};`:`let zero_point_value = ${d?a?"i32":"u32":S.type.value}(0);`};
      // Compute and write output
      ${E.setByOffset("global_idx",`${E.type.value}(x_value - zero_point_value) * scale_value`)};
      }`};return{name:"DequantizeLinear",shaderCache:{hint:t.cacheKey,inputDependencies:T?["rank","rank","rank"]:["rank","rank"]},getShaderSource:W,getRunData:()=>({outputs:[{dims:s,dataType:n}],dispatchGroup:{x:Math.ceil(u/x/64),y:1,z:1},programUniforms:M})}},Ah=(e,t)=>{Rl(e.inputs,t),e.compute(Bl(e.inputs,t))},Oh=e=>fe({axis:e.axis,blockSize:e.blockSize})}),Nl,Ml,Dh,Wg=P(()=>{Ke(),X(),ie(),Nl=(e,t,r)=>{let i=e===t,a=e<t&&r<0,s=e>t&&r>0;if(i||a||s)throw new Error("Range these inputs' contents are invalid.")},Ml=(e,t,r,i)=>{let a=Math.abs(Math.ceil((t-e)/r)),s=[a],n=a,u=[{type:12,data:n},{type:i,data:e},{type:i,data:r},...K(s)],d=p=>{let f=H("output",i,s.length),h=f.type.value,l=[{name:"outputSize",type:"u32"},{name:"start",type:h},{name:"delta",type:h}];return`
        ${p.registerUniforms(l).declareVariables(f)}
        ${p.mainStart()}
        ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        output[global_idx] = uniforms.start + ${h}(global_idx) * uniforms.delta;
      }`};return{name:"Range",shaderCache:{hint:`${i}`},getShaderSource:d,getRunData:()=>({outputs:[{dims:s,dataType:i}],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:u})}},Dh=e=>{let t=0,r=0,i=0;e.inputs[0].dataType===6?(t=e.inputs[0].getInt32Array()[0],r=e.inputs[1].getInt32Array()[0],i=e.inputs[2].getInt32Array()[0]):e.inputs[0].dataType===1&&(t=e.inputs[0].getFloat32Array()[0],r=e.inputs[1].getFloat32Array()[0],i=e.inputs[2].getFloat32Array()[0]),ge.webgpu.validateInputContent&&Nl(t,r,i),e.compute(Ml(t,r,i,e.inputs[0].dataType),{inputs:[]})}}),Pl,Vl,Rh,Bh,qg=P(()=>{X(),re(),ve(),ie(),Pl=(e,t,r,i)=>{if(e!=="none"&&i!=="i32"&&i!=="u32"&&i!=="f32")throw new Error(`Input ${i} is not supported with reduction ${e}.`);let a=`{
                var oldValue = 0;
                loop {
                  let newValueF32 =`,s=`;
                  let newValue = bitcast<i32>(newValueF32);
                  let res = atomicCompareExchangeWeak(&${t}, oldValue, newValue);
                  if res.exchanged {
                    break;
                  }
                  oldValue = res.old_value;
                }
              }`;switch(e){case"none":return`${t}=${r};`;case"add":return i==="i32"||i==="u32"?`atomicAdd(&${t}, bitcast<${i}>(${r}));`:`
              ${a}bitcast<${i}>(oldValue) + (${r})${s}`;case"max":return i==="i32"||i==="u32"?`atomicMax(&${t}, bitcast<${i}>(${r}));`:`
                ${a}max(bitcast<f32>(oldValue), (${r}))${s}`;case"min":return i==="i32"||i==="u32"?`atomicMin(&${t}, bitcast<${i}>(${r}));`:`${a}min(bitcast<${i}>(oldValue), (${r}))${s}`;case"mul":return`${a}(bitcast<${i}>(oldValue) * (${r}))${s}`;default:throw new Error(`Reduction ${e} is not supported.`)}},Vl=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r,s=1,n=Math.ceil(z.size(i)/s),u=i[i.length-1],d=z.sizeFromDimension(r,u),p=[{type:12,data:n},{type:12,data:u},{type:12,data:d},...K(e[1].dims,e[2].dims,a)],f=h=>{let l=R("indices",e[1].dataType,e[1].dims.length),y=R("updates",e[2].dataType,e[2].dims.length,s),_=t.reduction!=="none"&&t.reduction!==""?pp("output",e[0].dataType,a.length):H("output",e[0].dataType,a.length,s);return`
      ${h.registerUniform("output_size","u32").registerUniform("last_index_dimension","u32").registerUniform("num_updates_elements","u32").declareVariables(l,y,_)}
      ${h.mainStart()}
        ${h.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
  var data_offset = 0u;
  let indices_start = uniforms.last_index_dimension * global_idx;
  let indices_end = indices_start + uniforms.last_index_dimension;
  for (var i = indices_start; i < indices_end; i++) {
    var index = i32(indices[i].x);
    ${e[0].dims.length===1?`
    let element_count_dim = uniforms.output_strides;
    let dim_value = uniforms.output_shape;`:`
    let element_count_dim = uniforms.output_strides[i - indices_start];
    let dim_value = uniforms.output_shape[i - indices_start + uniforms.last_index_dimension];`}
    if (index >= 0) {
      if (index >= i32(dim_value)) {
        index = i32(dim_value - 1);
      }
    } else {
      if (index < -i32(dim_value)) {
        index = 0;
      } else {
        index += i32(dim_value);
      }
    }
    data_offset += u32((u32(index) * element_count_dim));
  }

  for (var i = 0u; i < uniforms.num_updates_elements; i++) {
    let value = updates[uniforms.num_updates_elements * global_idx + i];
    ${Pl(t.reduction,"output[data_offset + i]","value",_.type.value)}
  }

      }`};return{name:"ScatterND",shaderCache:{hint:`${t.cacheKey}_${t.reduction}`,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:p}),getShaderSource:f}},Rh=e=>fe({reduction:e.reduction}),Bh=(e,t)=>{e.compute(Vl(e.inputs,t),{inputs:[e.inputs[1],e.inputs[2]],outputs:[]})}}),Ul,Wl,ql,Ll,Fl,Gl,Hl,jl,Kl,Zl,Yl,pa,Ql,Jl,Xl,ed,td,Nh,Mh,Lg=P(()=>{X(),re(),ve(),ie(),Ul=(e,t)=>{if(e.every(r=>r>0||(()=>{throw new Error("Resize requires scales input values to be positive")})),e.length>0){if(t.mode==="linear"){if(!(e.length===2||e.length===3||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1||e.length===5&&e[0]===1&&e[1]===1))throw new Error(`For linear mode, Resize requires scales to be 2D, 3D, 4D with either two outermost or one innermost and
            one outermost scale values equal to 1, or 5D with two outermost scale values equal to 1`)}else if(t.mode==="cubic"&&!(e.length===2||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1))throw new Error("Resize requires scales input size to be 2 or 4 for cubic mode")}},Wl=(e,t,r)=>{t.every(a=>a>=0&&a<r||(()=>{throw new Error("Resize requires axes input values to be positive and less than rank")}));let i=new Array(r).fill(1);return t.forEach((a,s)=>i[a]=e[s]),i},ql=(e,t,r,i,a,s)=>{let[n,u,d]=r>10?[1,2,3]:[-1,e.length>1?1:-1,-1],p=e[0].dims.length;if(n>0&&e.length>n&&e[n].dims.length>0)e[n].getFloat32Array().forEach(f=>s.push(f));else if(t.coordinateTransformMode==="tf_crop_and_resize")throw new Error("Resize requires RoI input to be specified when coordinateTransformMode is tfCropAndResize");if(u>0&&e.length>u&&e[u].dims.length===1&&e[u].dims[0]>0){if(e[u].getFloat32Array().forEach(f=>i.push(f)),i.length!==0&&i.length!==p&&r>=18&&i.length!==t.axes.length)throw new Error("Resize requires scales input size to be same as input rank or axes size for opset 18 and up");Ul(i,t),t.axes.length>0&&Wl(i,t.axes,p).forEach((f,h)=>i[h]=f)}if(d>0&&e.length>d&&e[d].dims.length===1&&e[d].dims[0]>0&&(e[d].getBigInt64Array().forEach(f=>a.push(Number(f))),a.length!==0&&a.length!==p&&r>=18&&a.length!==t.axes.length))throw new Error("Resize requires sizes input size to be same as input rank or axes size for opset 18 and up");if(t.axes.length>0){if(i.length!==0&&i.length!==t.axes.length)throw new Error('Resize requires "scales" input size to be of axes rank when axes attributes is specified');if(a.length!==0&&a.length!==t.axes.length)throw new Error('Resize requires "sizes" input size to be of rank axes rank when axes attributes is specified')}if(typeof i<"u"&&typeof a<"u"&&i.length>0&&a.length>p)throw new Error("Resize requires only of scales or sizes to be specified")},Ll=(e,t)=>`fn getOriginalCoordinateFromResizedCoordinate(xResized: u32, xScale: f32, lengthResized: u32,
     lengthOriginal: u32, roiStart: f32, roiEnd: f32) -> ${t} { `+(()=>{switch(e){case"asymmetric":return`return ${t}(xResized) / ${t}(xScale);`;case"pytorch_half_pixel":return`if (lengthResized > 1) {
                    return (${t}(xResized) + 0.5) / ${t}(xScale) - 0.5;
                  } else {
                    return 0.0;
                  }`;case"tf_half_pixel_for_nn":return`return (${t}(xResized) + 0.5) / ${t}(xScale);`;case"align_corners":return`if (lengthResized == 1) {
                    return 0.0;
                  } else {
                    // The whole part and the fractional part are calculated separately due to inaccuracy of floating
                    // point division. As an example, f32(21) / f32(7) may evaluate to 2.99... instead of 3, causing an
                    // offset-by-one error later in floor().
                    let whole = ${t}(xResized * (lengthOriginal - 1) / (lengthResized - 1));
                    let fract =
                        ${t}(xResized * (lengthOriginal - 1) % (lengthResized - 1)) / ${t}(lengthResized - 1);
                    return whole + fract;
                  }`;case"tf_crop_and_resize":return`if (lengthResized > 1) {
                    return ${t}(roiStart) * ${t}(lengthOriginal - 1) +
                        (${t}(xResized) * ${t}(roiEnd - roiStart) * ${t}(lengthOriginal - 1)) /
                        ${t}(lengthResized - 1);
                  } else {
                    return 0.5 * ${t}(roiStart + roiEnd) * ${t}(lengthOriginal - 1);
                  }`;case"half_pixel_symmetric":return`const outputWidth = ${t}xScale * ${t}(lengthResized);
                  const adjustment = ${t}(lengthResized) / outputWidth;
                  const center = ${t}(lengthOriginal) / 2;
                  const offset = center * (1 - adjustment);
                  return offset + ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;case"half_pixel":return`return ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;default:throw new Error(`Coordinate transform mode ${e} is not supported`)}})()+"}",Fl=(e,t,r)=>`fn getNearestPixelFromOriginal(xOriginal: ${r}, isDownSample: bool) -> ${r} {`+(()=>{switch(e){case"round_prefer_ceil":return"if (fract(xOriginal) == 0.5) {             return ceil(xOriginal);           } else {             return round(xOriginal);           }";case"floor":return"return floor(xOriginal);";case"ceil":return"return ceil(xOriginal);";case"round_prefer_floor":return"if (fract(xOriginal) == 0.5) {                     return floor(xOriginal);                   } else {                     return round(xOriginal);                   }";case"simple":default:if(t<11)return"if (isDownSample)                     {                       return ceil(xOriginal);                     } else {                       return xOriginal;                     }";throw new Error(`Nearest mode ${e} is not supported`)}})()+"}",Gl=(e,t,r)=>{let i=new Array(r).fill(0).concat(new Array(r).fill(1)),a=e.length===0?i:e.slice();return t.length>0?(t.forEach((s,n)=>{i[s]=a[n],i[n+r]=a[t.length+n]}),i):a},Hl=(e,t,r,i)=>{let a=[];if(r.length>0)if(i.length>0){if(e.forEach(s=>a.push(s)),Math.max(...i)>e.length)throw new Error("axes is out of bound");i.forEach((s,n)=>a[s]=r[n])}else r.forEach(s=>a.push(s));else{if(t.length===0)throw new Error("Resize requires either scales or sizes.");a=e.map((s,n)=>Math.round(s*t[n]))}return a},jl=(e,t,r)=>{let i=(()=>{switch(r.keepAspectRatioPolicy){case"not_larger":return r.axes.length>0?Math.min(...r.axes.map(s=>t[s]),Number.MAX_VALUE):Math.min(...t,Number.MAX_VALUE);case"not_smaller":return r.axes.length>0?Math.max(...r.axes.map(s=>t[s]),Number.MIN_VALUE):Math.max(...t,Number.MIN_VALUE);default:throw new Error(`Keep aspect ratio policy ${r.keepAspectRatioPolicy} is not supported`)}})();t.fill(1,0,t.length);let a=e.slice();return r.axes.length>0?(r.axes.forEach(s=>t[s]=i),r.axes.forEach(s=>a[s]=Math.round(e[s]*t[s]))):(t.fill(i,0,t.length),a.forEach((s,n)=>a[n]=Math.round(s*t[n]))),a},Kl=(e,t,r,i,a)=>`
    fn calculateOriginalIndicesFromOutputIndices(output_indices: ${e.type.indices}) -> array<${e.type.value}, ${r.length}> {
      var original_indices: array<${e.type.value}, ${r.length}>;
      for (var i:u32 = 0; i < ${r.length}; i++) {
        var output_index = ${e.indicesGet("output_indices","i")};
        var scale = ${j("uniforms.scales","i",i)};
        var roi_low = ${j("uniforms.roi","i",a)};
        var roi_hi = ${j("uniforms.roi",`i + ${t.length}`,a)};
        if (scale == 1.0) {
          original_indices[i] = ${e.type.value}(output_index);
        } else {
          var input_shape_i = ${j("uniforms.input_shape","i",t.length)};
          var output_shape_i = ${j("uniforms.output_shape","i",r.length)};
          original_indices[i] = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                           input_shape_i, roi_low, roi_hi);
        }
      }
      return original_indices;
    }`,Zl=(e,t,r,i,a,s,n)=>`
    fn calculateInputIndicesFromOutputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
      var input_indices: ${e.type.indices};
      for (var i:u32 = 0; i < ${i.length}; i++) {
        var output_index = ${t.indicesGet("output_indices","i")};
        var input_index: u32;
        var scale = ${j("uniforms.scales","i",a)};
        if (scale == 1.0) {
          input_index = output_index;
        } else {
          var roi_low = ${j("uniforms.roi","i",s)};
          var roi_hi = ${j("uniforms.roi",`i + ${r.length}`,s)};
          var input_shape_i = ${j("uniforms.input_shape","i",r.length)};
          var output_shape_i = ${j("uniforms.output_shape","i",i.length)};
          var original_idx = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                        input_shape_i, roi_low, roi_hi);
          if (!${n} || (original_idx >= 0 && original_idx < ${t.type.value}(input_shape_i))) {
            if (original_idx < 0) {
              input_index = 0;
            } else if (original_idx > ${t.type.value}(input_shape_i - 1)) {
              input_index = input_shape_i - 1;
            } else {
              input_index = u32(getNearestPixelFromOriginal(original_idx, scale < 1));
            }
          } else {
            input_index = u32(original_idx);
          }
        }
        ${e.indicesSet("input_indices","i"," input_index")}
      }
      return input_indices;
    }`,Yl=(e,t)=>`
    fn checkInputIndices(input_indices: ${e.type.indices}) -> bool {
      for (var i:u32 = 0; i < ${t.length}; i++) {
        var input_index = ${e.indicesGet("input_indices","i")};
        if (input_index < 0 || input_index >= ${j("uniforms.input_shape","i",t.length)}) {
          return false;
        }
      }
      return true;
    }`,pa=(e,t,r,i)=>e.rank>i?`
    ${e.indicesSet("input_indices",t,"channel")};
    ${e.indicesSet("input_indices",r,"batch")};
`:"",Ql=(e,t,r,i,a)=>{let[s,n,u,d]=r.length===2?[-1,0,1,-1]:[0,2,3,1],p=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, row: u32, col: u32) -> ${p} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",n,`max(0, min(row, ${r[n]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(col, ${r[u]} - 1))`)};
      ${pa(e,d,s,2)}
      return ${e.getByIndices("input_indices")};
    }

    fn bilinearInterpolation(output_indices: ${t.type.indices}) -> ${p} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var row:${p} = originalIndices[${n}];
      var col:${p} = originalIndices[${u}];
      ${i?`if (row < 0 || row > (${r[n]} - 1) || col < 0 || col > (${r[u]} - 1)) {
        return ${a};
      }`:""};
      row = max(0, min(row, ${r[n]} - 1));
      col = max(0, min(col, ${r[u]} - 1));
      var row1: u32 = u32(row);
      var col1: u32 = u32(col);
      var row2: u32 = u32(row + 1);
      var col2: u32 = u32(col + 1);
      var channel: u32 = ${r.length>2?`u32(originalIndices[${d}])`:"0"};
      var batch: u32 =  ${r.length>2?`u32(originalIndices[${s}])`:"0"};
      var x11: ${p} = getInputValue(batch, channel, row1, col1);
      var x12: ${p} = getInputValue(batch, channel, row1, col2);
      var x21: ${p} = getInputValue(batch, channel, row2, col1);
      var x22: ${p} = getInputValue(batch, channel, row2, col2);
      var dx1: ${p} = abs(row - ${p}(row1));
      var dx2: ${p} = abs(${p}(row2) - row);
      var dy1: ${p} = abs(col - ${p}(col1));
      var dy2: ${p} = abs(${p}(col2) - col);
      if (row1 == row2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (col1 == col2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      return (x11 * dx2 * dy2 + x12 * dx2 * dy1 + x21 * dx1 * dy2 + x22 * dx1 * dy1);
    }`},Jl=(e,t,r,i,a,s,n,u,d,p)=>{let f=r.length===2,[h,l]=f?[0,1]:[2,3],y=e.type.value,_=b=>{let v=b===h?"row":"col";return`
      fn ${v}CubicInterpolation(input_indices: ${e.type.indices}, output_indices: ${t.type.indices}) -> ${y} {
        var output_index = ${t.indicesGet("output_indices",b)};
        var originalIdx: ${y} = getOriginalCoordinateFromResizedCoordinate(output_index, ${a[b]},
        ${i[b]}, ${r[b]}, ${s[b]}, ${s[b]} + ${r.length});
        var fractOriginalIdx: ${y} = originalIdx - floor(originalIdx);
        var coefs = getCubicInterpolationCoefs(fractOriginalIdx);

        if (${u} && (originalIdx < 0 || originalIdx > (${r[b]} - 1))) {
          return ${d};
        }
        var data: array<${y}, 4> = array<${y}, 4>(0.0, 0.0, 0.0, 0.0);
        for (var i: i32 = -1; i < 3; i++) {
          var ${v}: ${y} = originalIdx + ${y}(i);
          if (${v} < 0 || ${v} >= ${r[b]}) {
            ${p?`coefs[i + 1] = 0.0;
                        continue;`:u?`return ${d};`:`${v} = max(0, min(${v}, ${r[b]} - 1));`};
          }
        var input_indices_copy: ${e.type.indices} = input_indices;
          ${e.indicesSet("input_indices_copy",b,`u32(${v})`)};
          data[i + 1] = ${b===h?e.getByIndices("input_indices_copy"):"rowCubicInterpolation(input_indices_copy, output_indices)"};
        }
        return cubicInterpolation1D(data, coefs);
      }`};return`
    ${_(h)};
    ${_(l)};
  fn getCubicInterpolationCoefs(s: ${y}) -> array<${y}, 4> {
    var absS = abs(s);
    var coeffs: array<${y}, 4> = array<${y}, 4>(0.0, 0.0, 0.0, 0.0);
    var oneMinusAbsS: ${y} = 1.0 - absS;
    var twoMinusAbsS: ${y} = 2.0 - absS;
    var onePlusAbsS: ${y} = 1.0 + absS;
    coeffs[0] = ((${n} * onePlusAbsS - 5 * ${n}) * onePlusAbsS + 8 * ${n}) * onePlusAbsS - 4 * ${n};
    coeffs[1] = ((${n} + 2) * absS - (${n} + 3)) * absS * absS + 1;
    coeffs[2] = ((${n} + 2) * oneMinusAbsS - (${n} + 3)) * oneMinusAbsS * oneMinusAbsS + 1;
    coeffs[3] = ((${n} * twoMinusAbsS - 5 * ${n}) * twoMinusAbsS + 8 * ${n}) * twoMinusAbsS - 4 * ${n};
    return coeffs;
  }

  fn cubicInterpolation1D(x: array<${y}, 4>, coefs: array<${y}, 4>) -> ${y} {
    var coefsSum: ${y} = coefs[0] + coefs[1] + coefs[2] + coefs[3];
    return (x[0] * coefs[0] + x[1] * coefs[1]+ x[2] * coefs[2]+ x[3] * coefs[3]) / coefsSum;
  }

  fn bicubicInterpolation(output_indices: ${t.type.indices}) -> ${y} {
    var input_indices: ${e.type.indices} = output_indices;
    return colCubicInterpolation(input_indices, output_indices);
  }
    `},Xl=(e,t,r,i,a)=>{let[s,n,u,d,p]=r.length===3?[-1,0,1,2,-1]:[0,2,3,4,1],f=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, depth:u32, height: u32, width: u32) -> ${f} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",n,`max(0, min(depth, ${r[n]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(height, ${r[u]} - 1))`)};
      ${e.indicesSet("input_indices",d,`max(0, min(width, ${r[d]} - 1))`)};
      ${pa(e,p,s,3)}
      return ${e.getByIndices("input_indices")};
    }

    fn trilinearInterpolation(output_indices: ${t.type.indices}) -> ${f} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var depth:${f} = originalIndices[${n}];
      var height:${f} = originalIndices[${u}];
      var width:${f} = originalIndices[${d}];
      ${i?`if (depth < 0 || depth > (${r[n]} - 1) || height < 0 || height > (${r[u]} - 1) || width < 0 || (width > ${r[d]} - 1)) {
      return ${a};
        }`:""};

    depth = max(0, min(depth, ${r[n]} - 1));
      height = max(0, min(height, ${r[u]} - 1));
      width = max(0, min(width, ${r[d]} - 1));
      var depth1: u32 = u32(depth);
      var height1: u32 = u32(height);
      var width1: u32 = u32(width);
      var depth2: u32 = u32(depth + 1);
      var height2: u32 = u32(height + 1);
      var width2: u32 = u32(width + 1);
      var channel: u32 = ${r.length>3?`u32(originalIndices[${p}])`:"0"};
      var batch: u32 =  ${r.length>3?`u32(originalIndices[${s}])`:"0"};

      var x111: ${f} = getInputValue(batch, channel, depth1, height1, width1);
      var x112: ${f} = getInputValue(batch, channel, depth1, height1, width2);
      var x121: ${f} = getInputValue(batch, channel, depth1, height2, width1);
      var x122: ${f} = getInputValue(batch, channel, depth1, height2, width2);
      var x211: ${f} = getInputValue(batch, channel, depth2, height1, width1);
      var x212: ${f} = getInputValue(batch, channel, depth2, height1, width2);
      var x221: ${f} = getInputValue(batch, channel, depth2, height2, width1);
      var x222: ${f} = getInputValue(batch, channel, depth2, height2, width2);
      var dx1: ${f} = abs(depth - ${f}(depth1));
      var dx2: ${f} = abs(${f}(depth2) - depth);
      var dy1: ${f} = abs(height - ${f}(height1));
      var dy2: ${f} = abs(${f}(height2) - height);
      var dz1: ${f} = abs(width - ${f}(width1));
      var dz2: ${f} = abs(${f}(width2) - width);
      if (depth1 == depth2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (height1 == height2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      if (width1 == width2) {
        dz1 = 0.5;
        dz2 = 0.5;
      }
      return (x111 * dx2 * dy2 * dz2 + x112 * dx2 * dy2 * dz1 + x121 * dx2 * dy1 *dz2 + x122 * dx2 * dy1 * dz1 +
              x211 * dx1 * dy2 * dz2 + x212 * dx1 * dy2 * dz1 + x221 * dx1 * dy1 *dz2 + x222 * dx1 * dy1 * dz1);
    }`},ed=(e,t,r,i,a,s)=>{let n=e.dims,u=Gl(s,t.axes,n.length),d=Hl(n,i,a,t.axes),p=i.slice();i.length===0&&(p=n.map(($,S)=>$===0?1:d[S]/$),t.keepAspectRatioPolicy!=="stretch"&&(d=jl(n,p,t)));let f=H("output",e.dataType,d.length),h=R("input",e.dataType,n.length),l=z.size(d),y=n.length===d.length&&n.every(($,S)=>$===d[S]),_=t.coordinateTransformMode==="tf_crop_and_resize",b=t.extrapolationValue,v=h.type.value,x=$=>`
      ${y?"":`
      ${Ll(t.coordinateTransformMode,v)};
      ${(()=>{switch(t.mode){case"nearest":return`
              ${Yl(h,n)};
              ${Fl(t.nearestMode,r,v)};
              ${Zl(h,f,n,d,p.length,u.length,_)};
              `;case"linear":return`
              ${Kl(f,n,d,p.length,u.length)};
              ${(()=>{if(n.length===2||n.length===4)return`${Ql(h,f,n,_,b)}`;if(n.length===3||n.length===5)return`${Xl(h,f,n,_,b)}`;throw Error("Linear mode only supports input dims 2, 3, 4 and 5 are supported in linear mode.")})()};
            `;case"cubic":return`
            ${(()=>{if(n.length===2||n.length===4)return`${Jl(h,f,n,d,p,u,t.cubicCoeffA,_,t.extrapolationValue,t.excludeOutside)}`;throw Error("Cubic mode only supports input dims 2 and 4 are supported in linear mode.")})()};
            `;default:throw Error("Invalid resize mode")}})()};
      `}
      ${$.registerUniform("output_size","u32").registerUniform("scales","f32",p.length).registerUniform("roi","f32",u.length).declareVariables(h,f)}
      ${$.mainStart()}
        ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
        ${y?"output[global_idx] = input[global_idx];":`
        let output_indices = ${f.offsetToIndices("global_idx")};
        var input_indices: ${h.type.indices};
        ${(()=>{switch(t.mode){case"nearest":return`input_indices = calculateInputIndicesFromOutputIndices(output_indices);
                if (checkInputIndices(input_indices)) {
                  output[global_idx] = ${h.getByIndices("input_indices")};
                } else {
                  output[global_idx] = ${t.extrapolationValue};
                }`;case"linear":return`output[global_idx] = ${n.length===2||n.length===4?"bilinearInterpolation":"trilinearInterpolation"}(output_indices);`;case"cubic":return"output[global_idx] = bicubicInterpolation(output_indices);";default:throw Error(`Unsupported resize mode: ${t.mode}`)}})()};
`}
      }`;return{name:"Resize",shaderCache:{hint:`${t.cacheKey}|${r}|${p.length>0?p:""}|${a.length>0?a:""}|${u.length>0?u:""}|${y}|${n}`,inputDependencies:["rank"]},getShaderSource:x,getRunData:()=>({outputs:[{dims:d,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:[{type:12,data:l},{type:1,data:p},{type:1,data:u},...K(n,d)]})}},td=e=>{let t=e.customDataBuffer;return new Uint32Array(t,t.byteOffset,1)[0]},Nh=(e,t)=>{let r=[],i=[],a=[],s=td(e);if(t.antialias!==0)throw Error("Only default value (0) for Antialias attribute is supported");ql(e.inputs,t,s,r,i,a),e.compute(ed(e.inputs[0],t,s,r,i,a),{inputs:[0]})},Mh=e=>{let t=e.antialias,r=e.axes,i=e.coordinateTransformMode,a=e.cubicCoeffA,s=e.excludeOutside!==0,n=e.extrapolationValue,u=e.keepAspectRatioPolicy,d=e.mode,p=e.nearestMode===""?"simple":e.nearestMode;return fe({antialias:t,axes:r,coordinateTransformMode:i,cubicCoeffA:a,excludeOutside:s,extrapolationValue:n,keepAspectRatioPolicy:u,mode:d,nearestMode:p})}}),rd,id,Ph,Fg=P(()=>{X(),re(),ve(),ie(),rd=(e,t)=>{let[r,i,a,s]=e,{numHeads:n,rotaryEmbeddingDim:u}=t;if(r.dims.length!==3&&r.dims.length!==4)throw new Error(`Input 'x' is expected to have 3 or 4 dimensions, got ${r.dims.length}`);if(!z.areEqual(i.dims,[])&&!z.areEqual(i.dims,[1])&&i.dims.length!==2)throw new Error(`Input 'position_ids' is expected to have 0, 1, or 2 dimensions, got ${i.dims.length}`);if(a.dims.length!==2)throw new Error(`Input 'cos_cache' is expected to have 2 dimensions, got ${a.dims.length}`);if(s.dims.length!==2)throw new Error(`Input 'sin_cache' is expected to have 2 dimensions, got ${s.dims.length}`);if(!z.areEqual(a.dims,s.dims))throw new Error("Inputs 'cos_cache' and 'sin_cache' are expected to have the same shape");if(u>0&&n===0)throw new Error("num_heads must be provided if rotary_embedding_dim is specified");let d=r.dims[0],p=r.dims[r.dims.length-2],f=a.dims[0],h=z.sizeFromDimension(r.dims,1)/p,l=u===0?a.dims[1]*2:h/n;if(u>l)throw new Error("rotary_embedding_dim must be less than or equal to head_size");if(i.dims.length===2){if(d!==i.dims[0])throw new Error(`Input 'position_ids' dimension 0 should be of size batch_size, got ${i.dims[0]}`);if(p!==i.dims[1])throw new Error(`Input 'position_ids' dimension 1 should be of size sequence_length, got ${i.dims[1]}`)}if(l/2!==a.dims[1]&&u/2!==a.dims[1])throw new Error(`Input 'cos_cache' dimension 1 should be same as head_size / 2 or rotary_embedding_dim / 2, got ${a.dims[1]}`);if(p>f)throw new Error("Updating cos_cache and sin_cache in RotaryEmbedding is not currently supported")},id=(e,t)=>{let{interleaved:r,numHeads:i,rotaryEmbeddingDim:a,scale:s}=t,n=e[0].dims[0],u=z.sizeFromDimension(e[0].dims,1),d=e[0].dims[e[0].dims.length-2],p=u/d,f=e[2].dims[1],h=a===0?f*2:p/i,l=new Array(n,d,p/h,h-f),y=z.computeStrides(l),_=[{type:1,data:s},{type:12,data:l},{type:12,data:y},...e[0].dims.length===3?new Array({type:12,data:[u,p,h,1]}):[],...e[0].dims.length===4?new Array({type:12,data:[u,h,d*h,1]}):[],...K(e[0].dims,e[1].dims,e[2].dims,e[3].dims,e[0].dims)],b=v=>{let x=R("input",e[0].dataType,e[0].dims.length),$=R("position_ids",e[1].dataType,e[1].dims.length),S=R("cos_cache",e[2].dataType,e[2].dims.length),k=R("sin_cache",e[3].dataType,e[3].dims.length),T=H("output",e[0].dataType,e[0].dims.length);return v.registerUniforms([{name:"scale",type:"f32"},{name:"global_shape",type:"u32",length:l.length},{name:"global_strides",type:"u32",length:y.length},{name:"input_output_strides",type:"u32",length:y.length}]),`
        ${v.declareVariables(x,$,S,k,T)}

        ${v.mainStart(Ft)}
          let half_rotary_emb_dim = uniforms.${S.name}_shape[1];
          let bsnh = global_idx / uniforms.global_strides % uniforms.global_shape;
          let size = uniforms.global_shape[0] * uniforms.global_strides[0];
          ${v.guardAgainstOutOfBoundsWorkgroupSizes("size")}

          if (bsnh[3] < half_rotary_emb_dim) {
            let position_ids_idx =
                ${$.broadcastedIndicesToOffset("bsnh.xy",H("",$.type.tensor,2))};
            let position_id =
                u32(${$.getByOffset("position_ids_idx")}) + select(0, bsnh[1], position_ids_idx == 0);
            let i = dot(bsnh, uniforms.input_output_strides) + select(0, bsnh[3], ${r});
            let j = i + select(half_rotary_emb_dim, 1, ${r});
            let re = ${x.getByOffset("i")} * ${S.get("position_id","bsnh[3]")} -
                ${x.getByOffset("j")} * ${k.get("position_id","bsnh[3]")};
            ${T.setByOffset("i","re")}
            let im = ${x.getByOffset("i")} * ${k.get("position_id","bsnh[3]")} +
                ${x.getByOffset("j")} * ${S.get("position_id","bsnh[3]")};
            ${T.setByOffset("j","im")}
          } else {
            let k = dot(bsnh, uniforms.input_output_strides) + half_rotary_emb_dim;
            ${T.setByOffset("k",x.getByOffset("k"))}
          }
        }`};return{name:"RotaryEmbedding",shaderCache:{hint:fe({interleaved:r}).cacheKey,inputDependencies:["rank","rank","rank","rank"]},getShaderSource:b,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(z.size(l)/Ft)},programUniforms:_})}},Ph=(e,t)=>{rd(e.inputs,t),e.compute(id(e.inputs,t))}}),ad,nd,Vh,Gg=P(()=>{X(),re(),ie(),ad=e=>{if(!e||e.length<3)throw new Error("layerNorm requires at least 3 inputs.");let t=e[0],r=e[1],i=e[2];if(t.dataType!==r.dataType||t.dataType!==i.dataType)throw new Error("All inputs must have the same data type");if(t.dims.length!==3&&t.dims.length!==2)throw new Error("Input must be 2D or 3D");if(r.dims.length!==3&&r.dims.length!==2)throw new Error("Skip must be 2D or 3D");let a=t.dims[t.dims.length-1],s=t.dims[t.dims.length-2];if(r.dims[r.dims.length-1]!==a)throw new Error("Skip must have the same hidden size as input");if(r.dims[r.dims.length-2]!==s)throw new Error("Skip must have the same sequence length as input");if(i.dims.length!==1)throw new Error("Gamma must be 1D");if(i.dims[i.dims.length-1]!==a)throw new Error("Gamma must have the same hidden size as input");if(e.length>3){let n=e[3];if(n.dims.length!==1)throw new Error("Beta must be 1D");if(n.dims[n.dims.length-1]!==a)throw new Error("Beta must have the same hidden size as input")}if(e.length>4){let n=e[4];if(n.dims.length!==1)throw new Error("Bias must be 1D");if(n.dims[n.dims.length-1]!==a)throw new Error("Bias must have the same hidden size as input")}},nd=(e,t,r,i)=>{let a=t.simplified,s=e[0].dims,n=z.size(s),u=s,d=n,p=s.slice(-1)[0],f=i?s.slice(0,-1).concat(1):[],h=!a&&e.length>3,l=e.length>4,y=i&&r>1,_=i&&r>2,b=r>3,v=64,x=be(p),$=[{type:12,data:d},{type:12,data:x},{type:12,data:p},{type:1,data:t.epsilon}],S=T=>{let E=[{name:"output_size",type:"u32"},{name:"components",type:"u32"},{name:"hidden_size",type:"u32"},{name:"epsilon",type:"f32"}],I=[R("x",e[0].dataType,e[0].dims,x),R("skip",e[1].dataType,e[1].dims,x),R("gamma",e[2].dataType,e[2].dims,x)];h&&I.push(R("beta",e[3].dataType,e[3].dims,x)),l&&I.push(R("bias",e[4].dataType,e[4].dims,x)),I.push(H("output",e[0].dataType,u,x)),y&&I.push(H("mean_output",1,f)),_&&I.push(H("inv_std_output",1,f)),b&&I.push(H("input_skip_bias_sum",e[0].dataType,u,x));let D=Te(e[0].dataType),M=Te(1,x);return`

      ${T.registerUniforms(E).declareVariables(...I)}
      var<workgroup> sum_shared : array<${M}, ${v}>;
      var<workgroup> sum_squared_shared : array<${M}, ${v}>;

      ${T.mainStart([v,1,1])}
        let ix = local_id.x;
        let iy = global_id.x / ${v};

        let hidden_size_vectorized: u32 = uniforms.hidden_size / uniforms.components;
        var stride = hidden_size_vectorized / ${v};
        let offset = ix * stride + iy * hidden_size_vectorized;
        let offset1d = stride * ix;
        if (ix == ${v-1}) {
          stride = hidden_size_vectorized - stride * ix;
        }
        for (var i: u32 = 0; i < stride; i++) {
          let skip_value = skip[offset + i];
          let bias_value = ${l?"bias[offset1d + i]":D+"(0.0)"};
          let input_value = x[offset + i];
          let value = input_value + skip_value + bias_value;
          ${b?"input_skip_bias_sum[offset + i] = value;":""}
          output[offset + i] = value;
          let f32_value = ${Wt(D,x,"value")};
          sum_shared[ix] += f32_value;
          sum_squared_shared[ix] += f32_value * f32_value;
        }
        workgroupBarrier();

        var reduce_size : u32 = ${v};
        for (var curr_size = reduce_size >> 1;  curr_size > 0; curr_size = reduce_size >> 1) {
          reduce_size = curr_size + (reduce_size & 1);
          if (ix < curr_size) {
            sum_shared[ix] += sum_shared[ix + reduce_size];
            sum_squared_shared[ix] += sum_squared_shared[ix + reduce_size];
          }
          workgroupBarrier();
        }

        let sum = sum_shared[0];
        let square_sum = sum_squared_shared[0];
        let mean = ${yt("sum",x)} / f32(uniforms.hidden_size);
        let inv_std_dev = inverseSqrt(${yt("square_sum",x)} / f32(uniforms.hidden_size) ${a?"":"- mean * mean"} + uniforms.epsilon);
        ${y?"mean_output[global_idx] = mean;":""}
        ${_?"inv_std_output[global_idx] = inv_std_dev;":""}

        for (var i: u32 = 0; i < stride; i++) {
          output[offset + i] = (output[offset + i] ${a?"":`- ${D}(mean)`}) *
            ${D}(inv_std_dev) * gamma[offset1d + i]
            ${h?"+ beta[offset1d + i]":""};
        }
      }`},k=[{dims:u,dataType:e[0].dataType}];return r>1&&k.push({dims:f,dataType:1}),r>2&&k.push({dims:f,dataType:1}),r>3&&k.push({dims:s,dataType:e[0].dataType}),{name:"SkipLayerNormalization",shaderCache:{hint:`${x};${y};${_};${b}`,inputDependencies:e.map((T,E)=>"type")},getShaderSource:S,getRunData:()=>({outputs:k,dispatchGroup:{x:Math.ceil(d/p)},programUniforms:$})}},Vh=(e,t)=>{ad(e.inputs);let r=[0];e.outputCount>1&&r.push(-3),e.outputCount>2&&r.push(-3),e.outputCount>3&&r.push(3),e.compute(nd(e.inputs,t,e.outputCount,!1),{outputs:r})}}),sd,rr,od,ca,ud,ld,Uh,Wh,Hg=P(()=>{X(),re(),ve(),ie(),sd=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");if(t.axes.length!==0){if(t.axes.length!==t.starts.length||t.axes.length!==t.ends.length)throw new Error("axes, starts and ends must have the same length")}else if(t.starts.length!==t.ends.length)throw new Error("starts and ends must have the same length");e.slice(1).forEach((r,i)=>{if(e[i+1].dataType!==6&&e[i+1].dataType!==7)throw new Error(`Input ${i} must be an array of int32 or int64`)})},rr=(e,t)=>{let r=[];if(e.length>t)if(e[t].dataType===7)e[t].getBigInt64Array().forEach(i=>r.push(Number(i)));else if(e[t].dataType===6)e[t].getInt32Array().forEach(i=>r.push(Number(i)));else throw new Error(`Input ${t} must be an array of int32 or int64`);return r},od=(e,t)=>{if(e.length>1){let r=rr(e,1),i=rr(e,2),a=rr(e,3);return a.length===0&&(a=[...Array(e[0].dims.length).keys()]),fe({starts:r,ends:i,axes:a})}else return t},ca=(e,t,r,i,a)=>{let s=e;return e<0&&(s+=r[i[t]]),a[t]<0?Math.max(0,Math.min(s,r[i[t]]-1)):Math.max(0,Math.min(s,r[i[t]]))},ud=(e,t,r)=>`fn calculateInputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
          var input_indices: ${e.type.indices};
          var carry = 0u;
          for (var i = ${r.length}; i >= 0; i--) {
            let input_shape_i = ${j("uniforms.input_shape","i",r.length)};
            let steps_i = ${j("uniforms.steps","i",r.length)};
            let signs_i = ${j("uniforms.signs","i",r.length)};
            let starts_i = ${j("uniforms.starts","i",r.length)};
            var output_index = ${t.indicesGet("output_indices","i")};
            var input_index = output_index * steps_i + starts_i + carry;
            carry = input_index / input_shape_i;
            input_index = input_index % input_shape_i;
            if (signs_i < 0) {
              input_index = input_shape_i - input_index - 1u + starts_i;
            }
            ${e.indicesSet("input_indices","i","input_index")};
          }
          return input_indices;
      }`,ld=(e,t)=>{let r=e[0].dims,i=z.size(r),a=t.axes.length>0?z.normalizeAxes(t.axes,r.length):[...Array(r.length).keys()],s=rr(e,4);s.forEach(x=>x!==0||(()=>{throw new Error("step cannot be 0")})),s.length===0&&(s=Array(a.length).fill(1));let n=t.starts.map((x,$)=>ca(x,$,r,a,s)),u=t.ends.map((x,$)=>ca(x,$,r,a,s));if(a.length!==n.length||a.length!==u.length)throw new Error("start, ends and axes should have the same number of elements");if(a.length!==r.length)for(let x=0;x<r.length;++x)a.includes(x)||(n.splice(x,0,0),u.splice(x,0,r[x]),s.splice(x,0,1));let d=s.map(x=>Math.sign(x));s.forEach((x,$,S)=>{if(x<0){let k=(u[$]-n[$])/x,T=n[$],E=T+k*s[$];n[$]=E,u[$]=T,S[$]=-x}});let p=r.slice(0);a.forEach((x,$)=>{p[x]=Math.ceil((u[x]-n[x])/s[x])});let f={dims:p,dataType:e[0].dataType},h=H("output",e[0].dataType,p.length),l=R("input",e[0].dataType,e[0].dims.length),y=z.size(p),_=[{name:"outputSize",type:"u32"},{name:"starts",type:"u32",length:n.length},{name:"signs",type:"i32",length:d.length},{name:"steps",type:"u32",length:s.length}],b=[{type:12,data:y},{type:12,data:n},{type:6,data:d},{type:12,data:s},...K(e[0].dims,p)],v=x=>`
      ${x.registerUniforms(_).declareVariables(l,h)}
        ${ud(l,h,r)}
        ${x.mainStart()}
          ${x.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
          let output_indices = ${h.offsetToIndices("global_idx")};
          let input_indices = calculateInputIndices(output_indices);
          ${h.setByOffset("global_idx",l.getByIndices("input_indices"))}
      }`;return{name:"Slice",shaderCache:{hint:`${d.length}_${n.length}_${s.length}`,inputDependencies:["rank"]},getShaderSource:v,getRunData:()=>({outputs:[f],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:b})}},Uh=(e,t)=>{sd(e.inputs,t);let r=od(e.inputs,t);e.compute(ld(e.inputs,r),{inputs:[0]})},Wh=e=>{let t=e.starts,r=e.ends,i=e.axes;return fe({starts:t,ends:r,axes:i})}}),dd,pd,qh,Lh,jg=P(()=>{X(),re(),ve(),bt(),ie(),dd=e=>{if(!e||e.length!==1)throw new Error("Softmax op requires 1 input.")},pd=(e,t)=>{let r=e.inputs[0],i=r.dims,a=z.size(i),s=i.length,n=z.normalizeAxis(t.axis,s),u=n<i.length-1,d,p=[];u?(p=Array.from({length:s},(I,D)=>D),p[n]=s-1,p[s-1]=n,d=e.compute(Pe(r,p),{inputs:[r],outputs:[-1]})[0]):d=r;let f=d.dims,h=f[s-1],l=a/h,y=be(h),_=h/y,b=64;l===1&&(b=256);let v=(I,D)=>D===4?`max(max(${I}.x, ${I}.y), max(${I}.z, ${I}.w))`:D===2?`max(${I}.x, ${I}.y)`:D===3?`max(max(${I}.x, ${I}.y), ${I}.z)`:I,x=R("x",d.dataType,d.dims,y),$=H("result",d.dataType,d.dims,y),S=x.type.value,k=Te(d.dataType)==="f32"?`var threadMax = ${S}(-3.402823e+38f);`:`var threadMax = ${S}(-65504.0h);`,T=I=>`
      var<workgroup> rowMaxShared : ${S};
      var<workgroup> rowSumShared : ${S};
      var<workgroup> threadShared : array<${S}, ${b}>;

      fn getValue(row: i32, col: i32, row_stride: i32) -> ${S} {
        let index = row * row_stride + col;
        return x[index];
      }

      fn setValue(row: i32, col: i32, row_stride: i32, value: ${S}) {
        let index = row * row_stride + col;
        result[index] = value;
      }
      ${I.registerUniform("packedCols","i32").declareVariables(x,$)}
      ${I.mainStart(b)}
        let gindex = i32(global_idx);
        let lindex = i32(local_idx);
        const wg = ${b};
        let row = gindex / wg;
        let cols = uniforms.packedCols;
        let row_stride : i32 = uniforms.packedCols;

        // find the rows max
        ${k}
        for (var col = lindex; col < cols; col += wg) {
          let value = getValue(row, col, row_stride);
          threadMax = max(threadMax, value);
        }
        if (lindex < cols) {
          threadShared[lindex] = threadMax;
        }
        workgroupBarrier();

        var reduceSize = min(cols, wg);
        for (var currSize = reduceSize >> 1;  currSize > 0; currSize = reduceSize >> 1) {
          reduceSize = currSize + (reduceSize & 1);
          if (lindex < currSize) {
            threadShared[lindex] = max(threadShared[lindex], threadShared[lindex + reduceSize]);
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowMaxShared = ${S}(${v("threadShared[0]",y)});
        }
        workgroupBarrier();

        // find the rows sum
        var threadSum = ${S}(0.0);
        for (var col = lindex; col < cols; col += wg) {
          let subExp = exp(getValue(row, col, row_stride) - rowMaxShared);
          threadSum += subExp;
        }
        threadShared[lindex] = threadSum;
        workgroupBarrier();

        for (var currSize = wg >> 1;  currSize > 0; currSize = currSize >> 1) {
          if (lindex < currSize) {
            threadShared[lindex] = threadShared[lindex] + threadShared[lindex + currSize];
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowSumShared = ${S}(${yt("threadShared[0]",y)});
        }
        workgroupBarrier();

        // calculate final value for each element in the row
        for (var col = lindex; col < cols; col += wg) {
          let value = exp(getValue(row, col, row_stride) - rowMaxShared) / rowSumShared;
          setValue(row, col, row_stride, value);
        }
      }`,E=e.compute({name:"Softmax",shaderCache:{hint:`${y};${b}`,inputDependencies:["type"]},getRunData:()=>({outputs:[{dims:f,dataType:d.dataType}],dispatchGroup:{x:l},programUniforms:[{type:6,data:_}]}),getShaderSource:T},{inputs:[d],outputs:[u?-1:0]})[0];u&&e.compute(Pe(E,p),{inputs:[E]})},qh=(e,t)=>{dd(e.inputs),pd(e,t)},Lh=e=>fe({axis:e.axis})}),ha,cd,hd,fd,Fh,Kg=P(()=>{X(),re(),ie(),ha=e=>Array.from(e.getBigInt64Array(),Number),cd=e=>{if(!e||e.length!==2)throw new Error("Tile requires 2 inputs.");if(e[0].dataType!==1&&e[0].dataType!==10&&e[0].dataType!==6&&e[0].dataType!==12)throw new Error("Tile only support float, float16, int32, and uint32 data types");if(e[1].dataType!==7)throw new Error("Tile `repeats` input should be of int64 data type");if(e[1].dims.length!==1)throw new Error("Tile `repeats` input should be 1-D");if(ha(e[1]).length!==e[0].dims.length)throw new Error("Tile `repeats` input should have same number of elements as rank of input data tensor")},hd=(e,t)=>{let r=[];for(let i=0;i<e.length;++i)r.push(e[i]*t[i]);return r},fd=(e,t)=>{let r=e[0].dims,i=t??ha(e[1]),a=hd(r,i),s=z.size(a),n=e[0].dataType,u=R("input",n,r.length),d=H("output",n,a.length),p=f=>`
      const inputShape = ${u.indices(...r)};
      ${f.registerUniform("output_size","u32").declareVariables(u,d)}
      ${f.mainStart()}
      ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let output_indices = ${d.offsetToIndices("global_idx")};
      var input_indices: ${u.type.indices};
      for (var i = 0; i < ${r.length}; i++) {
        let input_dim_i = ${u.indicesGet("uniforms.input_shape","i")};
        let input_dim_value = ${d.indicesGet("output_indices","i")}  % input_dim_i;

        ${u.indicesSet("input_indices","i","input_dim_value")}
      }
      ${d.setByOffset("global_idx",u.getByIndices("input_indices"))}
    }`;return{name:"Tile",shaderCache:{hint:`${i}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:[{type:12,data:s},...K(e[0].dims,a)]}),getShaderSource:p}},Fh=e=>{cd(e.inputs),e.compute(fd(e.inputs),{inputs:[0]})}}),md,gd,Gh,Zg=P(()=>{X(),re(),ie(),md=(e,t,r,i,a)=>{let s=H("output_data",a,r.length,4),n=R("a_data",t[1].dataType,t[1].dims.length,4),u=R("b_data",t[2].dataType,t[2].dims.length,4),d=R("c_data",t[0].dataType,t[0].dims.length,4),p,f=(h,l,y)=>`select(${l}, ${h}, ${y})`;if(!i)p=s.setByOffset("global_idx",f(n.getByOffset("global_idx"),u.getByOffset("global_idx"),d.getByOffset("global_idx")));else{let h=(l,y,_="")=>{let b=`a_data[index_a${y}][component_a${y}]`,v=`b_data[index_b${y}][component_b${y}]`,x=`bool(c_data[index_c${y}] & (0xffu << (component_c${y} * 8)))`;return`
            let output_indices${y} = ${s.offsetToIndices(`global_idx * 4u + ${y}u`)};
            let offset_a${y} = ${n.broadcastedIndicesToOffset(`output_indices${y}`,s)};
            let offset_b${y} = ${u.broadcastedIndicesToOffset(`output_indices${y}`,s)};
            let offset_c${y} = ${d.broadcastedIndicesToOffset(`output_indices${y}`,s)};
            let index_a${y} = offset_a${y} / 4u;
            let index_b${y} = offset_b${y} / 4u;
            let index_c${y} = offset_c${y} / 4u;
            let component_a${y} = offset_a${y} % 4u;
            let component_b${y} = offset_b${y} % 4u;
            let component_c${y} = offset_c${y} % 4u;
            ${l}[${y}] = ${_}(${f(b,v,x)});
          `};a===9?p=`
            var data = vec4<u32>(0);
            ${h("data",0,"u32")}
            ${h("data",1,"u32")}
            ${h("data",2,"u32")}
            ${h("data",3,"u32")}
            output_data[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:p=`
            ${h("output_data[global_idx]",0)}
            ${h("output_data[global_idx]",1)}
            ${h("output_data[global_idx]",2)}
            ${h("output_data[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(d,n,u,s)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${p}
      }`},gd=e=>{let t=e[1].dims,r=e[2].dims,i=e[0].dims,a=e[1].dataType,s=!(z.areEqual(t,r)&&z.areEqual(r,i)),n=t,u=z.size(t);if(s){let p=Lt.calcShape(Lt.calcShape(t,r,!1),i,!1);if(!p)throw new Error("Can't perform where op on the given tensors");n=p,u=z.size(n)}let d=Math.ceil(u/4);return{name:"Where",shaderCache:{inputDependencies:["rank","rank","rank"]},getShaderSource:p=>md(p,e,n,s,a),getRunData:()=>({outputs:[{dims:n,dataType:a}],dispatchGroup:{x:Math.ceil(u/64/4)},programUniforms:[{type:12,data:d},...K(i,t,r,n)]})}},Gh=e=>{e.compute(gd(e.inputs))}}),Hh,Yg=P(()=>{lg(),an(),dg(),pg(),cg(),hg(),fg(),bg(),$g(),vg(),xg(),kg(),Sg(),Tg(),Cg(),Eg(),Ig(),zg(),Ag(),Og(),Dg(),Rg(),Bg(),Ng(),Mg(),ch(),Pg(),Vg(),Ug(),Wg(),qg(),rn(),Lg(),Fg(),Gg(),Hg(),jg(),mh(),Kg(),bt(),nn(),Zg(),Hh=new Map([["Abs",[Up]],["Acos",[Wp]],["Acosh",[qp]],["Add",[vc]],["ArgMax",[Np,Ea]],["ArgMin",[Bp,Ea]],["Asin",[Lp]],["Asinh",[Fp]],["Atan",[Gp]],["Atanh",[Hp]],["Attention",[Mp]],["AveragePool",[kh,xh]],["BatchNormalization",[Pp]],["BiasAdd",[Vp]],["BiasSplitGelu",[$c]],["Cast",[Kp,jp]],["Ceil",[Yp]],["Clip",[Zp]],["Concat",[Oc,Dc]],["Conv",[Ra,Da]],["ConvTranspose",[Lc,qc]],["Cos",[Qp]],["Cosh",[Jp]],["CumSum",[Fc,Gc]],["DepthToSpace",[Hc,jc]],["DequantizeLinear",[Ah,Oh]],["Div",[xc]],["Einsum",[Kc,Zc]],["Elu",[Xp,ur]],["Equal",[kc]],["Erf",[ec]],["Exp",[tc]],["Expand",[Yc]],["FastGelu",[Qc]],["Floor",[rc]],["FusedConv",[Ra,Da]],["Gather",[Xc,Jc]],["GatherElements",[nh,ah]],["GatherBlockQuantized",[rh,ih]],["GatherND",[eh,th]],["Gelu",[ic]],["Gemm",[oh,sh]],["GlobalAveragePool",[Th,Sh]],["GlobalMaxPool",[zh,Ih]],["Greater",[Ec]],["GreaterOrEqual",[zc]],["GridSample",[uh,lh]],["GroupQueryAttention",[gh]],["HardSigmoid",[pc,dc]],["InstanceNormalization",[yh]],["LayerNormalization",[_h]],["LeakyRelu",[ac,ur]],["Less",[Ic]],["LessOrEqual",[Ac]],["Log",[bc]],["MatMul",[bh]],["MatMulNBits",[wh,$h]],["MaxPool",[Ch,Eh]],["Mul",[Sc]],["MultiHeadAttention",[ph,dh]],["Neg",[sc]],["Not",[nc]],["Pad",[vh]],["Pow",[Tc]],["QuickGelu",[wc,ur]],["Range",[Dh]],["Reciprocal",[oc]],["ReduceMin",[zp]],["ReduceMean",[Sp]],["ReduceMax",[Ip]],["ReduceSum",[Op]],["ReduceProd",[Ap]],["ReduceL1",[Tp]],["ReduceL2",[Cp]],["ReduceLogSum",[Rp]],["ReduceLogSumExp",[Ep]],["ReduceSumSquare",[Dp]],["Relu",[uc]],["Resize",[Nh,Mh]],["RotaryEmbedding",[Ph]],["ScatterND",[Bh,Rh]],["Sigmoid",[lc]],["Sin",[cc]],["Sinh",[hc]],["Slice",[Uh,Wh]],["SkipLayerNormalization",[Vh]],["Split",[hh,fh]],["Sqrt",[fc]],["Softmax",[qh,Lh]],["Sub",[Cc]],["Tan",[mc]],["Tanh",[gc]],["ThresholdedRelu",[_c,ur]],["Tile",[Fh]],["Transpose",[hp,fp]],["Where",[Gh]]])}),jh,Qg=P(()=>{Ke(),st(),ie(),jh=class{constructor(e){this.backend=e,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r,i,a){tt(e.programInfo.name);let s=this.backend.device,n=this.backend.getComputePassEncoder();this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2);let u=[];for(let p of t)u.push({binding:u.length,resource:{buffer:p.buffer}});for(let p of r)u.push({binding:u.length,resource:{buffer:p.buffer}});a&&u.push({binding:u.length,resource:a});let d=s.createBindGroup({layout:e.computePipeline.getBindGroupLayout(0),entries:u,label:e.programInfo.name});if(this.backend.sessionStatus==="capturing"){let p={kernelId:this.backend.currentKernelId,computePipeline:e.computePipeline,bindGroup:d,dispatchGroup:i};this.backend.capturedCommandList.get(this.backend.currentSessionId).push(p)}n.setPipeline(e.computePipeline),n.setBindGroup(0,d),n.dispatchWorkgroups(...i),this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2+1),this.backend.pendingDispatchNumber++,(this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber||this.backend.queryType==="at-passes")&&this.backend.endComputePass(),this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber&&this.backend.flush(),je(e.programInfo.name)}dispose(){}build(e,t){tt(e.name);let r=this.backend.device,i=[];[{feature:"shader-f16",extension:"f16"},{feature:"subgroups",extension:"subgroups"},{feature:"subgroups-f16",extension:"subgroups_f16"}].forEach(p=>{r.features.has(p.feature)&&i.push(`enable ${p.extension};`)});let a=cp(t,this.backend.device.limits),s=e.getShaderSource(a),n=`${i.join(`
`)}
${a.additionalImplementations}
${s}`,u=r.createShaderModule({code:n,label:e.name});he("verbose",()=>`[WebGPU] ${e.name} shader code: ${n}`);let d=r.createComputePipeline({compute:{module:u,entryPoint:"main"},layout:"auto",label:e.name});return je(e.name),{programInfo:e,computePipeline:d,uniformVariablesInfo:a.variablesInfo}}normalizeDispatchGroupSize(e){let t=typeof e=="number"?e:e.x,r=typeof e=="number"?1:e.y||1,i=typeof e=="number"?1:e.z||1,a=this.backend.device.limits.maxComputeWorkgroupsPerDimension;if(t<=a&&r<=a&&i<=a)return[t,r,i];let s=t*r*i,n=Math.ceil(Math.sqrt(s));if(n>a){if(n=Math.ceil(Math.cbrt(s)),n>a)throw new Error("Total dispatch size exceeds WebGPU maximum.");return[n,n,n]}else return[n,n,1]}}}),yd,_d,bd,wd,Kh,Jg=P(()=>{Ke(),X(),st(),sp(),og(),Yg(),Qg(),yd=(e,t)=>{if(t.length!==e.length)throw new Error(`inputDependencies length ${t.length} is not equal to inputTensors length ${e.length}.`);let r=[];for(let i=0;i<e.length;++i){let a=e[i].dataType;switch(t[i]){case"none":{r.push("");break}case"type":{r.push(`${a}`);break}case"rank":{let s=e[i].dims.length;r.push(`${a};${s}`);break}case"dims":{let s=e[i].dims.join(",");r.push(`${a};${s}`);break}default:throw new Error(`unsupported input dependency: ${t[i]}`)}}return r.join("|")},_d=(e,t,r)=>{var a,s;let i=e.name;return(a=e.shaderCache)!=null&&a.hint&&(i+="["+e.shaderCache.hint+"]"),i+=":"+r+`:${yd(t,((s=e.shaderCache)==null?void 0:s.inputDependencies)??new Array(t.length).fill("dims"))}`,i},bd=class{constructor(e){e&&(this.architecture=e.architecture,this.vendor=e.vendor)}isArchitecture(e){return this.architecture===e}isVendor(e){return this.vendor===e}},wd=class{constructor(e){this.subgroupsSupported=e.features.has("subgroups"),this.subgroupsF16Supported=e.features.has("subgroups");let t=e.limits;!this.subgroupsSupported||!t.minSubgroupSize||!t.maxSubgroupSize?this.subgroupSizeRange=void 0:this.subgroupSizeRange=[t.minSubgroupSize,t.maxSubgroupSize]}},Kh=class{constructor(){this.currentSessionId=null,this.currentKernelId=null,this.commandEncoder=null,this.computePassEncoder=null,this.maxDispatchNumber=16,this.pendingDispatchNumber=0,this.pendingKernels=[],this.pendingQueries=new Map,this.sessionStatus="default",this.capturedCommandList=new Map,this.capturedPendingKernels=new Map,this.sessionExternalDataMapping=new Map}get currentKernelCustomData(){if(this.currentKernelId===null)throw new Error("currentKernelCustomData(): currentKernelId is null. (should not happen)");let e=this.kernelCustomData.get(this.currentKernelId);return e||(e={},this.kernelCustomData.set(this.currentKernelId,e)),e}async initialize(e,t){this.env=e;let r=[],i={requiredLimits:{maxComputeWorkgroupStorageSize:t.limits.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:t.limits.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:t.limits.maxStorageBufferBindingSize,maxBufferSize:t.limits.maxBufferSize,maxComputeInvocationsPerWorkgroup:t.limits.maxComputeInvocationsPerWorkgroup,maxComputeWorkgroupSizeX:t.limits.maxComputeWorkgroupSizeX,maxComputeWorkgroupSizeY:t.limits.maxComputeWorkgroupSizeY,maxComputeWorkgroupSizeZ:t.limits.maxComputeWorkgroupSizeZ},requiredFeatures:r},a=s=>t.features.has(s)&&r.push(s)&&!0;a("chromium-experimental-timestamp-query-inside-passes")||a("timestamp-query"),a("shader-f16"),a("subgroups")&&a("subgroups-f16"),this.device=await t.requestDevice(i),this.deviceInfo=new wd(this.device),this.adapterInfo=new bd(t.info||await t.requestAdapterInfo()),this.gpuDataManager=op(this),this.programManager=new jh(this),this.kernels=new Map,this.kernelPersistentData=new Map,this.kernelCustomData=new Map,Ja(e.logLevel,!!e.debug),this.device.onuncapturederror=s=>{s.error instanceof GPUValidationError&&console.error(`An uncaught WebGPU validation error was raised: ${s.error.message}`)},Object.defineProperty(this.env.webgpu,"device",{value:this.device,writable:!1,enumerable:!0,configurable:!1}),Object.defineProperty(this.env.webgpu,"adapter",{value:t,writable:!1,enumerable:!0,configurable:!1}),this.setQueryType()}dispose(){typeof this.querySet<"u"&&this.querySet.destroy(),this.gpuDataManager.dispose()}getCommandEncoder(){return this.commandEncoder||(this.commandEncoder=this.device.createCommandEncoder()),this.commandEncoder}getComputePassEncoder(){if(!this.computePassEncoder){let e=this.getCommandEncoder(),t={};this.queryType==="at-passes"&&(t.timestampWrites={querySet:this.querySet,beginningOfPassWriteIndex:this.pendingDispatchNumber*2,endOfPassWriteIndex:this.pendingDispatchNumber*2+1}),this.computePassEncoder=e.beginComputePass(t)}return this.computePassEncoder}endComputePass(){this.computePassEncoder&&(this.computePassEncoder.end(),this.computePassEncoder=null)}flush(){if(!this.commandEncoder)return;tt(),this.endComputePass();let e;this.queryType!=="none"&&(this.commandEncoder.resolveQuerySet(this.querySet,0,this.pendingDispatchNumber*2,this.queryResolveBuffer,0),e=this.device.createBuffer({size:this.pendingDispatchNumber*2*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),this.pendingQueries.set(e,this.pendingKernels),this.pendingKernels=[],this.commandEncoder.copyBufferToBuffer(this.queryResolveBuffer,0,e,0,this.pendingDispatchNumber*2*8)),this.device.queue.submit([this.commandEncoder.finish()]),this.gpuDataManager.refreshPendingBuffers(),this.commandEncoder=null,this.pendingDispatchNumber=0,this.queryType!=="none"&&e.mapAsync(GPUMapMode.READ).then(()=>{var i;let t=new BigUint64Array(e.getMappedRange()),r=this.pendingQueries.get(e);for(let a=0;a<t.length/2;a++){let s=r[a],n=s.kernelId,u=this.kernels.get(n),d=u.kernelType,p=u.kernelName,f=s.programName,h=s.inputTensorViews,l=s.outputTensorViews,y=t[a*2],_=t[a*2+1];typeof this.queryTimeBase>"u"&&(this.queryTimeBase=y);let b=Number(y-this.queryTimeBase),v=Number(_-this.queryTimeBase);if(!Number.isSafeInteger(b)||!Number.isSafeInteger(v))throw new RangeError("incorrect timestamp range");if((i=this.env.webgpu.profiling)!=null&&i.ondata)this.env.webgpu.profiling.ondata({version:1,inputsMetadata:h.map(x=>({dims:x.dims,dataType:It(x.dataType)})),outputsMetadata:l.map(x=>({dims:x.dims,dataType:It(x.dataType)})),kernelId:n,kernelType:d,kernelName:p,programName:f,startTime:b,endTime:v});else{let x="";h.forEach((S,k)=>{x+=`input[${k}]: [${S.dims}] | ${It(S.dataType)}, `});let $="";l.forEach((S,k)=>{$+=`output[${k}]: [${S.dims}] | ${It(S.dataType)}, `}),console.log(`[profiling] kernel "${n}|${d}|${p}|${f}" ${x}${$}execution time: ${v-b} ns`)}Gr("GPU",`${f}::${y}::${_}`)}e.unmap(),this.pendingQueries.delete(e)}),je()}run(e,t,r,i,a,s){tt(e.name);let n=[];for(let $=0;$<t.length;++$){let S=t[$].data;if(S===0)continue;let k=this.gpuDataManager.get(S);if(!k)throw new Error(`no GPU data for input: ${S}`);n.push(k)}let{outputs:u,dispatchGroup:d,programUniforms:p}=e.getRunData(t),f=r.length===0?u.map(($,S)=>S):r;if(f.length!==u.length)throw new Error(`Output size ${f.length} must be equal to ${u.length}.`);let h=[],l=[];for(let $=0;$<u.length;++$){if(!Number.isInteger(f[$])||f[$]<-3||f[$]>=s)throw new Error(`Invalid output index: ${f[$]}`);if(f[$]===-3)continue;let S=f[$]===-1,k=f[$]===-2,T=S||k?a(u[$].dataType,u[$].dims):i(f[$],u[$].dataType,u[$].dims);if(h.push(T),T.data===0)continue;let E=this.gpuDataManager.get(T.data);if(!E)throw new Error(`no GPU data for output: ${T.data}`);if(S&&this.temporaryData.push(E),k){let I=this.kernelPersistentData.get(this.currentKernelId);I||(I=[],this.kernelPersistentData.set(this.currentKernelId,I)),I.push(E)}l.push(E)}if(n.length!==t.length||l.length!==h.length){if(l.length===0)return je(e.name),h;throw new Error(`Program ${e.name} has zero-sized tensor(s) in inputs or outputs. This is not supported now.`)}let y;if(p){let $=0,S=[];p.forEach(I=>{let D=typeof I.data=="number"?[I.data]:I.data;if(D.length===0)return;let M=I.type===10?2:4,W,ee;I.type===10?(ee=D.length>4?16:D.length>2?8:D.length*M,W=D.length>4?16:M*D.length):(ee=D.length<=2?D.length*M:16,W=16),$=Math.ceil($/ee)*ee,S.push($);let te=I.type===10?8:4;$+=D.length>4?Math.ceil(D.length/te)*W:D.length*M});let k=16;$=Math.ceil($/k)*k;let T=new ArrayBuffer($);p.forEach((I,D)=>{let M=S[D],W=typeof I.data=="number"?[I.data]:I.data;if(I.type===6)new Int32Array(T,M,W.length).set(W);else if(I.type===12)new Uint32Array(T,M,W.length).set(W);else if(I.type===10)new Uint16Array(T,M,W.length).set(W);else if(I.type===1)new Float32Array(T,M,W.length).set(W);else throw new Error(`Unsupported uniform type: ${It(I.type)}`)});let E=this.gpuDataManager.create($,GPUBufferUsage.COPY_DST|GPUBufferUsage.UNIFORM);this.device.queue.writeBuffer(E.buffer,0,T,0,$),this.gpuDataManager.release(E.id),y={offset:0,size:$,buffer:E.buffer}}let _=this.programManager.normalizeDispatchGroupSize(d),b=_[1]===1&&_[2]===1,v=_d(e,t,b),x=this.programManager.getArtifact(v);if(x||(x=this.programManager.build(e,_),this.programManager.setArtifact(v,x),he("info",()=>`[artifact] key: ${v}, programName: ${e.name}`)),p&&x.uniformVariablesInfo){if(p.length!==x.uniformVariablesInfo.length)throw new Error(`Uniform variables count mismatch: expect ${x.uniformVariablesInfo.length}, got ${p.length} in program "${x.programInfo.name}".`);for(let $=0;$<p.length;$++){let S=p[$],k=S.type,T=typeof S.data=="number"?1:S.data.length,[E,I]=x.uniformVariablesInfo[$];if(k!==E||T!==I)throw new Error(`Uniform variable ${$} mismatch: expect type ${E} with size ${I}, got type ${k} with size ${T} in program "${x.programInfo.name}".`)}}if(he("info",()=>`[ProgramManager] run "${e.name}" (key=${v}) with ${_[0]}x${_[1]}x${_[2]}`),this.queryType!=="none"||this.sessionStatus==="capturing"){let $={kernelId:this.currentKernelId,programName:x.programInfo.name,inputTensorViews:t,outputTensorViews:h};this.pendingKernels.push($),this.sessionStatus==="capturing"&&this.capturedPendingKernels.get(this.currentSessionId).push($)}return this.programManager.run(x,n,l,_,y),je(e.name),h}upload(e,t){this.gpuDataManager.upload(e,t)}memcpy(e,t){this.gpuDataManager.memcpy(e,t)}async download(e,t){await this.gpuDataManager.download(e,t)}alloc(e){return this.gpuDataManager.create(e).id}free(e){return this.gpuDataManager.release(e)}createKernel(e,t,r,i){let a=Hh.get(e);if(!a)throw new Error(`kernel not implemented: ${e}`);let s={kernelType:e,kernelName:i,kernelEntry:a[0],attributes:[a[1],r]};this.kernels.set(t,s)}releaseKernel(e){let t=this.kernelPersistentData.get(e);if(t){for(let r of t)this.gpuDataManager.release(r.id);this.kernelPersistentData.delete(e)}this.kernelCustomData.delete(e),this.kernels.delete(e)}computeKernel(e,t,r){let i=this.kernels.get(e);if(!i)throw new Error(`kernel not created: ${e}`);let a=i.kernelType,s=i.kernelName,n=i.kernelEntry,u=i.attributes;if(this.currentKernelId!==null)throw new Error(`kernel "[${a}] ${s}" is not allowed to be called recursively`);this.currentKernelId=e,u[0]&&(u[1]=u[0](u[1]),u[0]=void 0),he("info",()=>`[WebGPU] Start to run kernel "[${a}] ${s}"...`);let d=this.env.debug;this.temporaryData=[];try{return d&&this.device.pushErrorScope("validation"),n(t,u[1]),0}catch(p){return r.push(Promise.resolve(`[WebGPU] Kernel "[${a}] ${s}" failed. ${p}`)),1}finally{d&&r.push(this.device.popErrorScope().then(p=>p?`GPU validation error for kernel "[${a}] ${s}": ${p.message}`:null));for(let p of this.temporaryData)this.gpuDataManager.release(p.id);this.temporaryData=[],this.currentKernelId=null}}registerBuffer(e,t,r,i){let a=this.sessionExternalDataMapping.get(e);a||(a=new Map,this.sessionExternalDataMapping.set(e,a));let s=a.get(t),n=this.gpuDataManager.registerExternalBuffer(r,i,s);return a.set(t,[n,r]),n}unregisterBuffers(e){let t=this.sessionExternalDataMapping.get(e);t&&(t.forEach(r=>this.gpuDataManager.unregisterExternalBuffer(r[0])),this.sessionExternalDataMapping.delete(e))}getBuffer(e){let t=this.gpuDataManager.get(e);if(!t)throw new Error(`no GPU data for buffer: ${e}`);return t.buffer}createDownloader(e,t,r){return async()=>{let i=await Sa(this,e,t);return Xa(i.buffer,r)}}writeTimestamp(e){this.queryType==="inside-passes"&&this.computePassEncoder.writeTimestamp(this.querySet,e)}setQueryType(){var e;this.queryType="none",(((e=this.env.webgpu.profiling)==null?void 0:e.mode)==="default"||(typeof this.env.trace>"u"?this.env.wasm.trace:this.env.trace))&&(this.device.features.has("chromium-experimental-timestamp-query-inside-passes")?this.queryType="inside-passes":this.device.features.has("timestamp-query")&&(this.queryType="at-passes"),this.queryType!=="none"&&typeof this.querySet>"u"&&(this.querySet=this.device.createQuerySet({type:"timestamp",count:this.maxDispatchNumber*2}),this.queryResolveBuffer=this.device.createBuffer({size:this.maxDispatchNumber*2*8,usage:GPUBufferUsage.COPY_SRC|GPUBufferUsage.QUERY_RESOLVE})))}captureBegin(){he("info","captureBegin"),this.capturedCommandList.get(this.currentSessionId)||this.capturedCommandList.set(this.currentSessionId,[]),this.capturedPendingKernels.get(this.currentSessionId)||this.capturedPendingKernels.set(this.currentSessionId,[]),this.flush(),this.sessionStatus="capturing"}captureEnd(){he("info","captureEnd"),this.flush(),this.sessionStatus="default"}replay(){he("info","replay"),this.sessionStatus="replaying";let e=this.capturedCommandList.get(this.currentSessionId),t=this.capturedPendingKernels.get(this.currentSessionId),r=e.length;this.pendingKernels=[];for(let i=0;i<r;i++){let a=this.getComputePassEncoder(),s=e[i];this.writeTimestamp(this.pendingDispatchNumber*2),a.setPipeline(s.computePipeline),a.setBindGroup(0,s.bindGroup),a.dispatchWorkgroups(...s.dispatchGroup),this.writeTimestamp(this.pendingDispatchNumber*2+1),this.pendingDispatchNumber++,this.queryType!=="none"&&this.pendingKernels.push(t[i]),(this.pendingDispatchNumber>=this.maxDispatchNumber||this.queryType==="at-passes")&&this.endComputePass(),this.pendingDispatchNumber>=this.maxDispatchNumber&&this.flush()}this.flush(),this.sessionStatus="default"}onCreateSession(){this.gpuDataManager.onCreateSession()}onReleaseSession(e){this.unregisterBuffers(e),this.capturedCommandList.has(e)&&this.capturedCommandList.delete(e),this.capturedPendingKernels.has(e)&&this.capturedPendingKernels.delete(e),this.gpuDataManager.onReleaseSession(e)}onRunStart(e){this.currentSessionId=e,this.setQueryType()}}}),$d,fa,vd,ma,ga,ya,xd,Zh,Xg=P(()=>{st(),$d=1,fa=()=>$d++,vd=new Map([["float32",32],["float16",16],["int32",32],["uint32",32],["int64",64],["uint64",64],["int8",8],["uint8",8],["int4",4],["uint4",4]]),ma=(e,t)=>{let r=vd.get(e);if(!r)throw new Error("Unsupported data type.");return t.length>0?Math.ceil(t.reduce((i,a)=>i*a)*r/8):0},ga=class{constructor(e){this.sessionId=e.sessionId,this.mlContext=e.context,this.mlTensor=e.tensor,this.dataType=e.dataType,this.tensorShape=e.shape}get tensor(){return this.mlTensor}get type(){return this.dataType}get shape(){return this.tensorShape}get byteLength(){return ma(this.dataType,this.tensorShape)}destroy(){he("verbose",()=>"[WebNN] TensorWrapper.destroy"),this.mlTensor.destroy()}write(e){this.mlContext.writeTensor(this.mlTensor,e)}async read(e){return e?this.mlContext.readTensor(this.mlTensor,e):this.mlContext.readTensor(this.mlTensor)}canReuseTensor(e,t,r){return this.mlContext===e&&this.dataType===t&&this.tensorShape.length===r.length&&this.tensorShape.every((i,a)=>i===r[a])}},ya=class{constructor(e,t){this.tensorManager=e,this.wrapper=t}get tensorWrapper(){return this.wrapper}releaseTensor(){this.tensorWrapper&&(this.tensorManager.releaseTensor(this.tensorWrapper),this.wrapper=void 0)}async ensureTensor(e,t,r,i){if(this.wrapper){if(this.wrapper.canReuseTensor(e,t,r))return this.wrapper.tensor;if(i){if(this.wrapper.byteLength!==ma(t,r))throw new Error("Unable to copy data to tensor with different size.");this.activeUpload=new Uint8Array(await this.wrapper.read())}this.tensorManager.releaseTensor(this.wrapper)}let a=typeof MLTensorUsage>"u"?void 0:MLTensorUsage.READ|MLTensorUsage.WRITE;return this.wrapper=await this.tensorManager.getCachedTensor(t,r,a,!0,!0),i&&this.activeUpload&&(this.wrapper.write(this.activeUpload),this.activeUpload=void 0),this.wrapper.tensor}upload(e){if(this.wrapper)if(e.byteLength===this.wrapper.byteLength){this.wrapper.write(e);return}else he("verbose",()=>"Data size does not match tensor size. Releasing tensor."),this.releaseTensor();this.activeUpload?this.activeUpload.set(e):this.activeUpload=new Uint8Array(e)}async download(e){if(this.activeUpload)if(e){e instanceof ArrayBuffer?new Uint8Array(e).set(this.activeUpload):new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(this.activeUpload);return}else return this.activeUpload.buffer;if(!this.wrapper)throw new Error("Tensor has not been created.");return e?this.wrapper.read(e):this.wrapper.read()}},xd=class{constructor(e){this.backend=e,this.tensorTrackersById=new Map,this.freeTensors=[],this.externalTensors=new Set}reserveTensorId(){let e=fa();return this.tensorTrackersById.set(e,new ya(this)),e}releaseTensorId(e){let t=this.tensorTrackersById.get(e);t&&(this.tensorTrackersById.delete(e),t.tensorWrapper&&this.releaseTensor(t.tensorWrapper))}async ensureTensor(e,t,r,i){he("verbose",()=>`[WebNN] TensorManager.ensureTensor {tensorId: ${e}, dataType: ${t}, shape: ${r}, copyOld: ${i}}`);let a=this.tensorTrackersById.get(e);if(!a)throw new Error("Tensor not found.");return a.ensureTensor(this.backend.currentContext,t,r,i)}upload(e,t){let r=this.tensorTrackersById.get(e);if(!r)throw new Error("Tensor not found.");r.upload(t)}async download(e,t){he("verbose",()=>`[WebNN] TensorManager.download {tensorId: ${e}, dstBuffer: ${t==null?void 0:t.byteLength}}`);let r=this.tensorTrackersById.get(e);if(!r)throw new Error("Tensor not found.");return r.download(t)}releaseTensorsForSession(e){for(let t of this.freeTensors)t.sessionId===e&&t.destroy();this.freeTensors=this.freeTensors.filter(t=>t.sessionId!==e)}registerTensor(e,t,r,i){let a=fa(),s=new ga({sessionId:this.backend.currentSessionId,context:e,tensor:t,dataType:r,shape:i});return this.tensorTrackersById.set(a,new ya(this,s)),this.externalTensors.add(s),a}async getCachedTensor(e,t,r,i,a){let s=this.backend.currentSessionId,n=this.backend.currentContext;for(let[d,p]of this.freeTensors.entries())if(p.canReuseTensor(n,e,t)){he("verbose",()=>`[WebNN] Reusing tensor {dataType: ${e}, shape: ${t}}`);let f=this.freeTensors.splice(d,1)[0];return f.sessionId=s,f}he("verbose",()=>`[WebNN] MLContext.createTensor {dataType: ${e}, shape: ${t}}`);let u=await n.createTensor({dataType:e,shape:t,dimensions:t,usage:r,writable:i,readable:a});return new ga({sessionId:s,context:n,tensor:u,dataType:e,shape:t})}releaseTensor(e){this.externalTensors.has(e)&&this.externalTensors.delete(e),this.freeTensors.push(e)}},Zh=(...e)=>new xd(...e)}),_a,kd,Yh,e0=P(()=>{X(),Dt(),sp(),Xg(),st(),_a=new Map([[1,"float32"],[10,"float16"],[6,"int32"],[12,"uint32"],[7,"int64"],[13,"uint64"],[22,"int4"],[21,"uint4"],[3,"int8"],[2,"uint8"],[9,"uint8"]]),kd=(e,t)=>{if(e===t)return!0;if(e===void 0||t===void 0)return!1;let r=Object.keys(e).sort(),i=Object.keys(t).sort();return r.length===i.length&&r.every((a,s)=>a===i[s]&&e[a]===t[a])},Yh=class{constructor(e){this.tensorManager=Zh(this),this.mlContextBySessionId=new Map,this.sessionIdsByMLContext=new Map,this.mlContextCache=[],Ja(e.logLevel,!!e.debug)}get currentSessionId(){if(this.activeSessionId===void 0)throw new Error("No active session");return this.activeSessionId}onRunStart(e){this.activeSessionId=e}async createMLContext(e){if(e instanceof GPUDevice){let r=this.mlContextCache.findIndex(i=>i.gpuDevice===e);if(r!==-1)return this.mlContextCache[r].mlContext;{let i=await navigator.ml.createContext(e);return this.mlContextCache.push({gpuDevice:e,mlContext:i}),i}}else if(e===void 0){let r=this.mlContextCache.findIndex(i=>i.options===void 0&&i.gpuDevice===void 0);if(r!==-1)return this.mlContextCache[r].mlContext;{let i=await navigator.ml.createContext();return this.mlContextCache.push({mlContext:i}),i}}let t=this.mlContextCache.findIndex(r=>kd(r.options,e));if(t!==-1)return this.mlContextCache[t].mlContext;{let r=await navigator.ml.createContext(e);return this.mlContextCache.push({options:e,mlContext:r}),r}}get currentContext(){let e=this.getMLContext(this.currentSessionId);if(!e)throw new Error(`No MLContext found for session ${this.currentSessionId}`);return e}registerMLContext(e,t){this.mlContextBySessionId.set(e,t);let r=this.sessionIdsByMLContext.get(t);r||(r=new Set,this.sessionIdsByMLContext.set(t,r)),r.add(e)}onReleaseSession(e){let t=this.mlContextBySessionId.get(e);if(!t)return;this.tensorManager.releaseTensorsForSession(e),this.mlContextBySessionId.delete(e);let r=this.sessionIdsByMLContext.get(t);if(r.delete(e),r.size===0){this.sessionIdsByMLContext.delete(t);let i=this.mlContextCache.findIndex(a=>a.mlContext===t);i!==-1&&this.mlContextCache.splice(i,1)}}getMLContext(e){return this.mlContextBySessionId.get(e)}reserveTensorId(){return this.tensorManager.reserveTensorId()}releaseTensorId(e){he("verbose",()=>`[WebNN] releaseTensorId {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e)}async ensureTensor(e,t,r,i){let a=_a.get(t);if(!a)throw new Error(`Unsupported ONNX data type: ${t}`);return this.tensorManager.ensureTensor(e,a,r,i)}uploadTensor(e,t){if(!Se().shouldTransferToMLTensor)throw new Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");he("verbose",()=>`[WebNN] uploadTensor {tensorId: ${e}, data: ${t.byteLength}}`),this.tensorManager.upload(e,t)}async downloadTensor(e,t){return this.tensorManager.download(e,t)}createMLTensorDownloader(e,t){return async()=>{let r=await this.tensorManager.download(e);return Xa(r,t)}}registerMLTensor(e,t,r){let i=_a.get(t);if(!i)throw new Error(`Unsupported ONNX data type: ${t}`);let a=this.tensorManager.registerTensor(this.currentContext,e,i,r);return he("verbose",()=>`[WebNN] registerMLTensor {tensor: ${e}, dataType: ${i}, dimensions: ${r}} -> {tensorId: ${a}}`),a}registerMLConstant(e,t,r,i,a,s){if(!s)throw new Error("External mounted files are not available.");let n=e;e.startsWith("./")&&(n=e.substring(2));let u=s.get(n);if(!u)throw new Error(`File with name ${n} not found in preloaded files.`);if(t+r>u.byteLength)throw new Error("Out of bounds: data offset and length exceed the external file data size.");let d=u.slice(t,t+r).buffer,p;switch(a.dataType){case"float32":p=new Float32Array(d);break;case"float16":p=new Uint16Array(d);break;case"int32":p=new Int32Array(d);break;case"uint32":p=new Uint32Array(d);break;case"int64":p=new BigInt64Array(d);break;case"uint64":p=new BigUint64Array(d);break;case"int8":p=new Int8Array(d);break;case"int4":case"uint4":case"uint8":p=new Uint8Array(d);break;default:throw new Error(`Unsupported data type: ${a.dataType} in creating WebNN Constant from external data.`)}return he("verbose",()=>`[WebNN] registerMLConstant {dataType: ${a.dataType}, shape: ${a.shape}}}`),i.constant(a,p)}flush(){}}}),Qh={};fr(Qh,{init:()=>Jh});var Vr,Sd,Jh,t0=P(()=>{X(),Jg(),st(),re(),e0(),Vr=class Xh{constructor(t,r,i,a){this.module=t,this.dataType=r,this.data=i,this.dims=a}getFloat32Array(){if(this.dataType!==1)throw new Error("Invalid data type");let t=z.size(this.dims);return t===0?new Float32Array:new Float32Array(this.module.HEAP8.buffer,this.data,t)}getBigInt64Array(){if(this.dataType!==7)throw new Error("Invalid data type");let t=z.size(this.dims);return t===0?new BigInt64Array:new BigInt64Array(this.module.HEAP8.buffer,this.data,t)}getInt32Array(){if(this.dataType!==6)throw new Error("Invalid data type");let t=z.size(this.dims);return t===0?new Int32Array:new Int32Array(this.module.HEAP8.buffer,this.data,t)}getUint16Array(){if(this.dataType!==10&&this.dataType!==4)throw new Error("Invalid data type");let t=z.size(this.dims);return t===0?new Uint16Array:new Uint16Array(this.module.HEAP8.buffer,this.data,t)}reshape(t){if(z.size(t)!==z.size(this.dims))throw new Error("Invalid new shape");return new Xh(this.module,this.dataType,this.data,t)}},Sd=class{constructor(e,t,r){this.module=e,this.backend=t,this.customDataOffset=0,this.customDataSize=0,this.adapterInfo=t.adapterInfo,this.deviceInfo=t.deviceInfo;let i=e.PTR_SIZE,a=r/e.PTR_SIZE,s=i===4?"i32":"i64";this.opKernelContext=Number(e.getValue(i*a++,s));let n=Number(e.getValue(i*a++,s));this.outputCount=Number(e.getValue(i*a++,s)),this.customDataOffset=Number(e.getValue(i*a++,"*")),this.customDataSize=Number(e.getValue(i*a++,s));let u=[];for(let d=0;d<n;d++){let p=Number(e.getValue(i*a++,s)),f=Number(e.getValue(i*a++,"*")),h=Number(e.getValue(i*a++,s)),l=[];for(let y=0;y<h;y++)l.push(Number(e.getValue(i*a++,s)));u.push(new Vr(e,p,f,l))}this.inputs=u}get kernelCustomData(){return this.backend.currentKernelCustomData}get customDataBuffer(){return this.module.HEAPU8.subarray(this.customDataOffset,this.customDataOffset+this.customDataSize)}compute(e,t){var n;let r=((n=t==null?void 0:t.inputs)==null?void 0:n.map(u=>typeof u=="number"?this.inputs[u]:u))??this.inputs,i=(t==null?void 0:t.outputs)??[],a=(u,d,p)=>new Vr(this.module,d,this.output(u,p),p),s=(u,d)=>{let p=Ut(u,d);if(!p)throw new Error(`Unsupported data type: ${u}`);let f=p>0?this.backend.gpuDataManager.create(p).id:0;return new Vr(this.module,u,f,d)};return this.backend.run(e,r,i,a,s,this.outputCount)}output(e,t){let r=this.module.stackSave();try{let i=this.module.PTR_SIZE,a=i===4?"i32":"i64",s=this.module.stackAlloc((1+t.length)*i);this.module.setValue(s,t.length,a);for(let n=0;n<t.length;n++)this.module.setValue(s+i*(n+1),t[n],a);return this.module._JsepOutput(this.opKernelContext,e,s)}catch(i){throw new Error(`Failed to generate kernel's output[${e}] with dims [${t}]. If you are running with pre-allocated output, please make sure the output type/dims are correct. Error: ${i}`)}finally{this.module.stackRestore(r)}}},Jh=async(e,t,r,i)=>{let a=t.jsepInit;if(!a)throw new Error("Failed to initialize JSEP. The WebAssembly module is not built with JSEP support.");if(e==="webgpu"){let s=new Kh;await s.initialize(r,i),a("webgpu",[s,n=>s.alloc(Number(n)),n=>s.free(n),(n,u,d,p=!1)=>{if(p)he("verbose",()=>`[WebGPU] jsepCopyGpuToGpu: src=${Number(n)}, dst=${Number(u)}, size=${Number(d)}`),s.memcpy(Number(n),Number(u));else{he("verbose",()=>`[WebGPU] jsepCopyCpuToGpu: dataOffset=${Number(n)}, gpuDataId=${Number(u)}, size=${Number(d)}`);let f=t.HEAPU8.subarray(Number(n>>>0),Number(n>>>0)+Number(d));s.upload(Number(u),f)}},async(n,u,d)=>{he("verbose",()=>`[WebGPU] jsepCopyGpuToCpu: gpuDataId=${n}, dataOffset=${u}, size=${d}`),await s.download(Number(n),()=>t.HEAPU8.subarray(Number(u)>>>0,Number(u+d)>>>0))},(n,u,d)=>s.createKernel(n,Number(u),d,t.UTF8ToString(t._JsepGetNodeName(Number(u)))),n=>s.releaseKernel(n),(n,u,d,p)=>{he("verbose",()=>`[WebGPU] jsepRun: sessionHandle=${d}, kernel=${n}, contextDataOffset=${u}`);let f=new Sd(t,s,Number(u));return s.computeKernel(Number(n),f,p)},()=>s.captureBegin(),()=>s.captureEnd(),()=>s.replay()])}else{let s=new Yh(r);a("webnn",[s,()=>s.reserveTensorId(),n=>s.releaseTensorId(n),async(n,u,d,p)=>s.ensureTensor(n,u,d,p),(n,u)=>{s.uploadTensor(n,u)},async(n,u)=>s.downloadTensor(n,u)])}}}),Td,pn,cn,mt,Cd,Qr,hn,fn,ba,mn,gn,yn,ef=P(()=>{ng(),sg(),X(),Dt(),ja(),np(),Td=(e,t)=>{Se()._OrtInit(e,t)!==0&&pe("Can't initialize onnxruntime.")},pn=async e=>{Td(e.wasm.numThreads,jr(e.logLevel))},cn=async(e,t)=>{{let r=(t0(),Fr(Qh)).init;if(t==="webgpu"){if(typeof navigator>"u"||!navigator.gpu)throw new Error("WebGPU is not supported in current environment");let i=e.webgpu.adapter;if(i){if(typeof i.limits!="object"||typeof i.features!="object"||typeof i.requestDevice!="function")throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.")}else{let a=e.webgpu.powerPreference;if(a!==void 0&&a!=="low-power"&&a!=="high-performance")throw new Error(`Invalid powerPreference setting: "${a}"`);let s=e.webgpu.forceFallbackAdapter;if(s!==void 0&&typeof s!="boolean")throw new Error(`Invalid forceFallbackAdapter setting: "${s}"`);if(i=await navigator.gpu.requestAdapter({powerPreference:a,forceFallbackAdapter:s}),!i)throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.')}await r("webgpu",Se(),e,i)}if(t==="webnn"){if(typeof navigator>"u"||!navigator.ml)throw new Error("WebNN is not supported in current environment");await r("webnn",Se(),e)}}},mt=new Map,Cd=e=>{let t=Se(),r=t.stackSave();try{let i=t.PTR_SIZE,a=t.stackAlloc(2*i);t._OrtGetInputOutputCount(e,a,a+i)!==0&&pe("Can't get session input/output count.");let s=i===4?"i32":"i64";return[Number(t.getValue(a,s)),Number(t.getValue(a+i,s))]}finally{t.stackRestore(r)}},Qr=e=>{let t=Se(),r=t._malloc(e.byteLength);if(r===0)throw new Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);return t.HEAPU8.set(e,r),[r,e.byteLength]},hn=async(e,t)=>{var h,l,y;let r,i,a=Se();Array.isArray(e)?[r,i]=e:e.buffer===a.HEAPU8.buffer?[r,i]=[e.byteOffset,e.byteLength]:[r,i]=Qr(e);let s=0,n=0,u=0,d=[],p=[],f=[];try{if([n,d]=ap(t),(t==null?void 0:t.externalData)&&a.mountExternalData){let T=[];for(let E of t.externalData){let I=typeof E=="string"?E:E.path;T.push(Qa(typeof E=="string"?E:E.data).then(D=>{a.mountExternalData(I,D)}))}await Promise.all(T)}for(let T of(t==null?void 0:t.executionProviders)??[])if((typeof T=="string"?T:T.name)==="webnn"){if(a.shouldTransferToMLTensor=!1,typeof T!="string"){let E=T,I=E==null?void 0:E.context,D=E==null?void 0:E.gpuDevice,M=E==null?void 0:E.deviceType,W=E==null?void 0:E.powerPreference;I?a.currentContext=I:D?a.currentContext=await a.jsepCreateMLContext(D):a.currentContext=await a.jsepCreateMLContext({deviceType:M,powerPreference:W})}else a.currentContext=await a.jsepCreateMLContext();break}s=await a._OrtCreateSession(r,i,n),s===0&&pe("Can't create a session."),(h=a.jsepOnCreateSession)==null||h.call(a),a.currentContext&&(a.jsepRegisterMLContext(s,a.currentContext),a.currentContext=void 0,a.shouldTransferToMLTensor=!0);let[_,b]=Cd(s),v=!!(t!=null&&t.enableGraphCapture),x=[],$=[],S=[];for(let T=0;T<_;T++){let E=a._OrtGetInputName(s,T);E===0&&pe("Can't get an input name."),p.push(E),x.push(a.UTF8ToString(E))}for(let T=0;T<b;T++){let E=a._OrtGetOutputName(s,T);E===0&&pe("Can't get an output name."),f.push(E);let I=a.UTF8ToString(E);$.push(I);{if(v&&(t==null?void 0:t.preferredOutputLocation)===void 0){S.push("gpu-buffer");continue}let D=typeof(t==null?void 0:t.preferredOutputLocation)=="string"?t.preferredOutputLocation:((l=t==null?void 0:t.preferredOutputLocation)==null?void 0:l[I])??"cpu";if(D!=="cpu"&&D!=="cpu-pinned"&&D!=="gpu-buffer"&&D!=="ml-tensor")throw new Error(`Not supported preferred output location: ${D}.`);if(v&&D!=="gpu-buffer")throw new Error(`Not supported preferred output location: ${D}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);S.push(D)}}let k=null;return S.some(T=>T==="gpu-buffer"||T==="ml-tensor")&&(u=a._OrtCreateBinding(s),u===0&&pe("Can't create IO binding."),k={handle:u,outputPreferredLocations:S,outputPreferredLocationsEncoded:S.map(T=>ka(T))}),mt.set(s,[s,p,f,k,v,!1]),[s,x,$]}catch(_){throw p.forEach(b=>a._OrtFree(b)),f.forEach(b=>a._OrtFree(b)),u!==0&&a._OrtReleaseBinding(u)!==0&&pe("Can't release IO binding."),s!==0&&a._OrtReleaseSession(s)!==0&&pe("Can't release session."),_}finally{a._free(r),n!==0&&a._OrtReleaseSessionOptions(n)!==0&&pe("Can't release session options."),d.forEach(_=>a._free(_)),(y=a.unmountExternalData)==null||y.call(a)}},fn=e=>{var d;let t=Se(),r=mt.get(e);if(!r)throw new Error(`cannot release session. invalid session id: ${e}`);let[i,a,s,n,u]=r;n&&(u&&t._OrtClearBoundOutputs(n.handle)!==0&&pe("Can't clear bound outputs."),t._OrtReleaseBinding(n.handle)!==0&&pe("Can't release IO binding.")),(d=t.jsepOnReleaseSession)==null||d.call(t,e),a.forEach(p=>t._OrtFree(p)),s.forEach(p=>t._OrtFree(p)),t._OrtReleaseSession(i)!==0&&pe("Can't release session."),mt.delete(e)},ba=(e,t,r,i,a,s=!1)=>{if(!e){t.push(0);return}let n=Se(),u=n.PTR_SIZE,d=e[0],p=e[1],f=e[3],h,l;if(d==="string"&&(f==="gpu-buffer"||f==="ml-tensor"))throw new Error("String tensor is not supported on GPU.");if(s&&f!=="gpu-buffer")throw new Error(`External buffer must be provided for input/output index ${a} when enableGraphCapture is true.`);if(f==="gpu-buffer"){let b=e[2].gpuBuffer;l=Ut(sr(d),p);let v=n.jsepRegisterBuffer;if(!v)throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');h=v(i,a,b,l)}else if(f==="ml-tensor"){let b=e[2].mlTensor;l=Ut(sr(d),p);let v=n.jsepRegisterMLTensor;if(!v)throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');h=v(b,sr(d),p)}else{let b=e[2];if(Array.isArray(b)){l=u*b.length,h=n._malloc(l),r.push(h);for(let v=0;v<b.length;v++){if(typeof b[v]!="string")throw new TypeError(`tensor data at index ${v} is not a string`);n.setValue(h+v*u,Ee(b[v],r),"*")}}else l=b.byteLength,h=n._malloc(l),r.push(h),n.HEAPU8.set(new Uint8Array(b.buffer,b.byteOffset,l),h)}let y=n.stackSave(),_=n.stackAlloc(4*p.length);try{p.forEach((v,x)=>n.setValue(_+x*u,v,u===4?"i32":"i64"));let b=n._OrtCreateTensor(sr(d),h,l,_,p.length,ka(f));b===0&&pe(`Can't create tensor for input/output. session=${i}, index=${a}.`),t.push(b)}finally{n.stackRestore(y)}},mn=async(e,t,r,i,a,s)=>{var ee,te;let n=Se(),u=n.PTR_SIZE,d=mt.get(e);if(!d)throw new Error(`cannot run inference. invalid session id: ${e}`);let p=d[0],f=d[1],h=d[2],l=d[3],y=d[4],_=d[5],b=t.length,v=i.length,x=0,$=[],S=[],k=[],T=[],E=n.stackSave(),I=n.stackAlloc(b*u),D=n.stackAlloc(b*u),M=n.stackAlloc(v*u),W=n.stackAlloc(v*u);try{(ee=n.jsepOnRunStart)==null||ee.call(n,p),[x,$]=ip(s);for(let F=0;F<b;F++)ba(r[F],S,T,e,t[F],y);for(let F=0;F<v;F++)ba(a[F],k,T,e,b+i[F],y);for(let F=0;F<b;F++)n.setValue(I+F*u,S[F],"*"),n.setValue(D+F*u,f[t[F]],"*");for(let F=0;F<v;F++)n.setValue(M+F*u,k[F],"*"),n.setValue(W+F*u,h[i[F]],"*");if(l&&!_){let{handle:F,outputPreferredLocations:G,outputPreferredLocationsEncoded:de}=l;if(f.length!==b)throw new Error(`input count from feeds (${b}) is expected to be always equal to model's input count (${f.length}).`);for(let J=0;J<b;J++){let Z=t[J];await n._OrtBindInput(F,f[Z],S[J])!==0&&pe(`Can't bind input[${J}] for session=${e}.`)}for(let J=0;J<v;J++){let Z=i[J];(te=a[J])!=null&&te[3]?n._OrtBindOutput(F,h[Z],k[J],0)!==0&&pe(`Can't bind pre-allocated output[${J}] for session=${e}.`):n._OrtBindOutput(F,h[Z],0,de[Z])!==0&&pe(`Can't bind output[${J}] to ${G[J]} for session=${e}.`)}mt.set(e,[p,f,h,l,y,!0])}let U;l?U=await n._OrtRunWithBinding(p,l.handle,v,M,x):U=await n._OrtRun(p,D,I,b,W,v,M,x),U!==0&&pe("failed to call OrtRun().");let ae=[];for(let F=0;F<v;F++){let G=Number(n.getValue(M+F*u,"*"));if(G===k[F]){ae.push(a[F]);continue}let de=n.stackSave(),J=n.stackAlloc(4*u),Z=!1,ue,N=0;try{n._OrtGetTensorData(G,J,J+u,J+2*u,J+3*u)!==0&&pe(`Can't access output tensor data on index ${F}.`);let q=u===4?"i32":"i64",se=Number(n.getValue(J,q));N=n.getValue(J+u,"*");let we=n.getValue(J+u*2,"*"),Ae=Number(n.getValue(J+u*3,q)),ke=[];for(let ye=0;ye<Ae;ye++)ke.push(Number(n.getValue(we+ye*u,q)));n._OrtFree(we)!==0&&pe("Can't free memory for tensor dims.");let Ze=ke.reduce((ye,me)=>ye*me,1);ue=It(se);let wt=l==null?void 0:l.outputPreferredLocations[i[F]];if(ue==="string"){if(wt==="gpu-buffer"||wt==="ml-tensor")throw new Error("String tensor is not supported on GPU.");let ye=[];for(let me=0;me<Ze;me++){let ut=n.getValue(N+me*u,"*"),Ht=n.getValue(N+(me+1)*u,"*"),ai=me===Ze-1?void 0:Ht-ut;ye.push(n.UTF8ToString(ut,ai))}ae.push([ue,ke,ye,"cpu"])}else if(wt==="gpu-buffer"&&Ze>0){let ye=n.jsepGetBuffer;if(!ye)throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');let me=ye(N),ut=Ut(se,Ze);if(ut===void 0||!Za(ue))throw new Error(`Unsupported data type: ${ue}`);Z=!0,ae.push([ue,ke,{gpuBuffer:me,download:n.jsepCreateDownloader(me,ut,ue),dispose:()=>{n._OrtReleaseTensor(G)!==0&&pe("Can't release tensor.")}},"gpu-buffer"])}else if(wt==="ml-tensor"&&Ze>0){let ye=n.jsepEnsureTensor;if(!ye)throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');if(Ut(se,Ze)===void 0||!Ya(ue))throw new Error(`Unsupported data type: ${ue}`);let me=await ye(N,se,ke,!1);Z=!0,ae.push([ue,ke,{mlTensor:me,download:n.jsepCreateMLTensorDownloader(N,ue),dispose:()=>{n.jsepReleaseTensorId(N),n._OrtReleaseTensor(G)}},"ml-tensor"])}else{let ye=Ka(ue),me=new ye(Ze);new Uint8Array(me.buffer,me.byteOffset,me.byteLength).set(n.HEAPU8.subarray(N,N+me.byteLength)),ae.push([ue,ke,me,"cpu"])}}finally{n.stackRestore(de),ue==="string"&&N&&n._free(N),Z||n._OrtReleaseTensor(G)}}return l&&!y&&(n._OrtClearBoundOutputs(l.handle)!==0&&pe("Can't clear bound outputs."),mt.set(e,[p,f,h,l,y,!1])),ae}finally{n.stackRestore(E),S.forEach(U=>n._OrtReleaseTensor(U)),k.forEach(U=>n._OrtReleaseTensor(U)),T.forEach(U=>n._free(U)),x!==0&&n._OrtReleaseRunOptions(x),$.forEach(U=>n._free(U))}},gn=e=>{let t=Se(),r=mt.get(e);if(!r)throw new Error("invalid session id");let i=r[0],a=t._OrtEndProfiling(i);a===0&&pe("Can't get an profile file name."),t._OrtFree(a)},yn=e=>{let t=[];for(let r of e){let i=r[2];!Array.isArray(i)&&"buffer"in i&&t.push(i.buffer)}return t}}),gt,Oe,Pt,ir,ar,Ur,wa,Wr,Tt,Ct,Ed,tf,rf,af,nf,sf,of,uf,lf=P(()=>{Ke(),ef(),Dt(),Ga(),gt=()=>!!ge.wasm.proxy&&typeof document<"u",Pt=!1,ir=!1,ar=!1,Wr=new Map,Tt=(e,t)=>{let r=Wr.get(e);r?r.push(t):Wr.set(e,[t])},Ct=()=>{if(Pt||!ir||ar||!Oe)throw new Error("worker not ready")},Ed=e=>{switch(e.data.type){case"init-wasm":Pt=!1,e.data.err?(ar=!0,wa[1](e.data.err)):(ir=!0,wa[0]()),Ur&&(URL.revokeObjectURL(Ur),Ur=void 0);break;case"init-ep":case"copy-from":case"create":case"release":case"run":case"end-profiling":{let t=Wr.get(e.data.type);e.data.err?t.shift()[1](e.data.err):t.shift()[0](e.data.out);break}}},tf=async()=>{if(!ir){if(Pt)throw new Error("multiple calls to 'initWasm()' detected.");if(ar)throw new Error("previous call to 'initWasm()' failed.");if(Pt=!0,gt())return new Promise((e,t)=>{Oe==null||Oe.terminate(),tp().then(([r,i])=>{var a;try{Oe=i,Oe.onerror=n=>t(n),Oe.onmessage=Ed,wa=[e,t];let s={type:"init-wasm",in:ge};!s.in.wasm.wasmPaths&&(r||(a=import.meta.url)!=null&&a.startsWith("file:"))&&(s.in.wasm.wasmPaths={wasm:new URL("/assets/ort-wasm-simd-threaded.jsep-CJtsIIQL.wasm",import.meta.url).href}),Oe.postMessage(s),Ur=r}catch(s){t(s)}},t)});try{await Ha(ge.wasm),await pn(ge),ir=!0}catch(e){throw ar=!0,e}finally{Pt=!1}}},rf=async e=>{if(gt())return Ct(),new Promise((t,r)=>{Tt("init-ep",[t,r]);let i={type:"init-ep",in:{epName:e,env:ge}};Oe.postMessage(i)});await cn(ge,e)},af=async e=>gt()?(Ct(),new Promise((t,r)=>{Tt("copy-from",[t,r]);let i={type:"copy-from",in:{buffer:e}};Oe.postMessage(i,[e.buffer])})):Qr(e),nf=async(e,t)=>{if(gt()){if(t!=null&&t.preferredOutputLocation)throw new Error('session option "preferredOutputLocation" is not supported for proxy.');return Ct(),new Promise((r,i)=>{Tt("create",[r,i]);let a={type:"create",in:{model:e,options:{...t}}},s=[];e instanceof Uint8Array&&s.push(e.buffer),Oe.postMessage(a,s)})}else return hn(e,t)},sf=async e=>{if(gt())return Ct(),new Promise((t,r)=>{Tt("release",[t,r]);let i={type:"release",in:e};Oe.postMessage(i)});fn(e)},of=async(e,t,r,i,a,s)=>{if(gt()){if(r.some(n=>n[3]!=="cpu"))throw new Error("input tensor on GPU is not supported for proxy.");if(a.some(n=>n))throw new Error("pre-allocated output tensor is not supported for proxy.");return Ct(),new Promise((n,u)=>{Tt("run",[n,u]);let d=r,p={type:"run",in:{sessionId:e,inputIndices:t,inputs:d,outputIndices:i,options:s}};Oe.postMessage(p,yn(d))})}else return mn(e,t,r,i,a,s)},uf=async e=>{if(gt())return Ct(),new Promise((t,r)=>{Tt("end-profiling",[t,r]);let i={type:"end-profiling",in:e};Oe.postMessage(i)});gn(e)}}),$a,Id,df,r0=P(()=>{Ke(),lf(),X(),Fa(),np(),$a=(e,t)=>{switch(e.location){case"cpu":return[e.type,e.dims,e.data,"cpu"];case"gpu-buffer":return[e.type,e.dims,{gpuBuffer:e.gpuBuffer},"gpu-buffer"];case"ml-tensor":return[e.type,e.dims,{mlTensor:e.mlTensor},"ml-tensor"];default:throw new Error(`invalid data location: ${e.location} for ${t()}`)}},Id=e=>{switch(e[3]){case"cpu":return new He(e[0],e[2],e[1]);case"gpu-buffer":{let t=e[0];if(!Za(t))throw new Error(`not supported data type: ${t} for deserializing GPU tensor`);let{gpuBuffer:r,download:i,dispose:a}=e[2];return He.fromGpuBuffer(r,{dataType:t,dims:e[1],download:i,dispose:a})}case"ml-tensor":{let t=e[0];if(!Ya(t))throw new Error(`not supported data type: ${t} for deserializing MLTensor tensor`);let{mlTensor:r,download:i,dispose:a}=e[2];return He.fromMLTensor(r,{dataType:t,dims:e[1],download:i,dispose:a})}default:throw new Error(`invalid data location: ${e[3]}`)}},df=class{async fetchModelAndCopyToWasmMemory(e){return af(await Qa(e))}async loadModel(e,t){tt();let r;typeof e=="string"?r=await this.fetchModelAndCopyToWasmMemory(e):r=e,[this.sessionId,this.inputNames,this.outputNames]=await nf(r,t),je()}async dispose(){return sf(this.sessionId)}async run(e,t,r){tt();let i=[],a=[];Object.entries(e).forEach(h=>{let l=h[0],y=h[1],_=this.inputNames.indexOf(l);if(_===-1)throw new Error(`invalid input '${l}'`);i.push(y),a.push(_)});let s=[],n=[];Object.entries(t).forEach(h=>{let l=h[0],y=h[1],_=this.outputNames.indexOf(l);if(_===-1)throw new Error(`invalid output '${l}'`);s.push(y),n.push(_)});let u=i.map((h,l)=>$a(h,()=>`input "${this.inputNames[a[l]]}"`)),d=s.map((h,l)=>h?$a(h,()=>`output "${this.outputNames[n[l]]}"`):null),p=await of(this.sessionId,a,u,n,d,r),f={};for(let h=0;h<p.length;h++)f[this.outputNames[n[h]]]=s[h]??Id(p[h]);return je(),f}startProfiling(){}endProfiling(){uf(this.sessionId)}}}),pf={};fr(pf,{OnnxruntimeWebAssemblyBackend:()=>Ma,initializeFlags:()=>Na,wasmBackend:()=>cf});var Na,Ma,cf,i0=P(()=>{Ke(),lf(),r0(),Na=()=>{if((typeof ge.wasm.initTimeout!="number"||ge.wasm.initTimeout<0)&&(ge.wasm.initTimeout=0),ge.wasm.simd===!1&&console.warn('Deprecated property "env.wasm.simd" is set to false. non-SIMD build is no longer provided, and this setting will be ignored.'),typeof ge.wasm.proxy!="boolean"&&(ge.wasm.proxy=!1),typeof ge.wasm.trace!="boolean"&&(ge.wasm.trace=!1),typeof ge.wasm.numThreads!="number"||!Number.isInteger(ge.wasm.numThreads)||ge.wasm.numThreads<=0)if(typeof self<"u"&&!self.crossOriginIsolated)ge.wasm.numThreads=1;else{let e=typeof navigator>"u"?Wm("node:os").cpus().length:navigator.hardwareConcurrency;ge.wasm.numThreads=Math.min(4,Math.ceil((e||1)/2))}},Ma=class{async init(e){Na(),await tf(),await rf(e)}async createInferenceSessionHandler(e,t){let r=new df;return await r.loadModel(e,t),Promise.resolve(r)}},cf=new Ma});Ke();Ke();Ke();var a0="1.21.0-dev.20250114-228dd16893";{let e=(i0(),Fr(pf)).wasmBackend;Vt("webgpu",e,5),Vt("webnn",e,5),Vt("cpu",e,10),Vt("wasm",e,10)}Object.defineProperty(ge.versions,"web",{value:a0,enumerable:!0});/**
* @license
* Copyright 2021 Google LLC. All Rights Reserved.
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* =============================================================================
*//**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 *//**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */console.log("background service worker loaded");let _n=!1,cr=new Set,hr=new Set,bn=!1,wn=!1,$n=!1,vn=!1,xn=!1,kn=!1,Sn=!1,Tn=.7,Cn=.4,En=.4,In=.4,zn=.4,An=.4;function _t(e){try{chrome.runtime.sendMessage(e,()=>{chrome.runtime.lastError})}catch{}}chrome.storage.local.get(["autoBlockEnabled","blockedHosts","blockedDomains","blockedPaths","networkDetectionPaused","cookieDetectionPaused","windowVarDetectionPaused","pageNetworkDetectionPaused","metaClassifierDetectionPaused","combinedClassifierDetectionPaused","networkThreshold","cookieThreshold","windowVarThreshold","pageNetworkThreshold","metaClassifierThreshold","combinedClassifierThreshold","autoCookieDeletionEnabled","autoWindowVarClearEnabled"]).then(e=>{_n=!!(e!=null&&e.autoBlockEnabled),bn=!!(e!=null&&e.networkDetectionPaused),wn=!!(e!=null&&e.cookieDetectionPaused),On=!!(e!=null&&e.windowVarDetectionPaused),$n=!!(e!=null&&e.pageNetworkDetectionPaused),vn=!!(e!=null&&e.metaClassifierDetectionPaused),xn=!!(e!=null&&e.combinedClassifierDetectionPaused),kn=!!(e!=null&&e.autoCookieDeletionEnabled),Sn=!!(e!=null&&e.autoWindowVarClearEnabled),Tn=typeof(e==null?void 0:e.networkThreshold)=="number"?e.networkThreshold:.7,Cn=typeof(e==null?void 0:e.cookieThreshold)=="number"?e.cookieThreshold:.4,En=typeof(e==null?void 0:e.windowVarThreshold)=="number"?e.windowVarThreshold:.4,In=typeof(e==null?void 0:e.pageNetworkThreshold)=="number"?e.pageNetworkThreshold:.4,zn=typeof(e==null?void 0:e.metaClassifierThreshold)=="number"?e.metaClassifierThreshold:.4,An=typeof(e==null?void 0:e.combinedClassifierThreshold)=="number"?e.combinedClassifierThreshold:.4;const t=Array.isArray(e==null?void 0:e.blockedDomains)?e.blockedDomains:[],r=Array.isArray(e==null?void 0:e.blockedHosts)?e.blockedHosts:[],i=Array.from(new Set([...r||[],...t||[]]));cr=new Set(i);const a=Array.isArray(e==null?void 0:e.blockedPaths)?e.blockedPaths:[];hr=new Set(a),hf()});let zd=Promise.resolve();function hf(){zd=zd.then(()=>x0(Array.from(cr),Array.from(hr))).catch(()=>{})}chrome.storage.onChanged.addListener((e,t)=>{if(t==="local"){if(e.autoBlockEnabled&&(_n=!!e.autoBlockEnabled.newValue),e.networkDetectionPaused!==void 0&&(bn=!!e.networkDetectionPaused.newValue),e.cookieDetectionPaused!==void 0&&(wn=!!e.cookieDetectionPaused.newValue),e.windowVarDetectionPaused!==void 0&&(On=!!e.windowVarDetectionPaused.newValue),e.pageNetworkDetectionPaused!==void 0&&($n=!!e.pageNetworkDetectionPaused.newValue),e.metaClassifierDetectionPaused!==void 0&&(vn=!!e.metaClassifierDetectionPaused.newValue),e.combinedClassifierDetectionPaused!==void 0&&(xn=!!e.combinedClassifierDetectionPaused.newValue),e.networkThreshold!==void 0&&(Tn=typeof e.networkThreshold.newValue=="number"?e.networkThreshold.newValue:.9),e.cookieThreshold!==void 0&&(Cn=typeof e.cookieThreshold.newValue=="number"?e.cookieThreshold.newValue:.2),e.windowVarThreshold!==void 0&&(En=typeof e.windowVarThreshold.newValue=="number"?e.windowVarThreshold.newValue:.2),e.pageNetworkThreshold!==void 0&&(In=typeof e.pageNetworkThreshold.newValue=="number"?e.pageNetworkThreshold.newValue:.4),e.metaClassifierThreshold!==void 0&&(zn=typeof e.metaClassifierThreshold.newValue=="number"?e.metaClassifierThreshold.newValue:.5),e.combinedClassifierThreshold!==void 0&&(An=typeof e.combinedClassifierThreshold.newValue=="number"?e.combinedClassifierThreshold.newValue:.5),e.autoCookieDeletionEnabled!==void 0&&(kn=!!e.autoCookieDeletionEnabled.newValue),e.autoWindowVarClearEnabled!==void 0&&(Sn=!!e.autoWindowVarClearEnabled.newValue),e.blockedHosts){const r=Array.isArray(e.blockedHosts.newValue)?e.blockedHosts.newValue:[];cr=new Set(r)}if(e.blockedPaths){const r=Array.isArray(e.blockedPaths.newValue)?e.blockedPaths.newValue:[];hr=new Set(r)}(e.blockedHosts||e.blockedPaths)&&hf()}});function ot(e){let t=null,r=!1;const i=[];function a(){return chrome.runtime.getURL(e)}function s(){ge.wasm.numThreads=1,ge.wasm.simd=!0}async function n(){if(!t){s();const f=a();t=La.create(f)}return t}function u(){t=null}async function d(){if(!(r||i.length===0)){for(r=!0;i.length>0;){const f=i.shift();if(!f)break;try{const h=await n(),l=h.inputNames[0],y=new Float32Array(f.features),_=new He("float32",y,[1,y.length]),b=await h.run({[l]:_}),v=h.outputNames[0],x=b[v].data,$=Number(x[0]),S=h.outputNames[1],k=b[S].data;let T;k.length===2?T=k[1]:k.length>2?T=k[$]:k.length===1&&$===1&&(T=k[0]),f.resolve({predictedLabel:$,probabilities:k,positiveClassProbability:T})}catch(h){const l=h instanceof Error?h.message:String(h);(l.includes("Session already started")||l.includes("Session mismatch"))&&u(),f.reject(h instanceof Error?h:new Error(String(h)))}}r=!1}}async function p(f){return new Promise((h,l)=>{i.push({resolve:h,reject:l,features:f}),d().catch(y=>{const _=i.pop();_&&_.reject(y instanceof Error?y:new Error(String(y)))})})}return{predict:p}}const ff=ot("models/logistic_regression_model.onnx"),n0=ot("models/network-request-domain.onnx"),s0=ot("models/logistic_regression_model_cookies.onnx"),o0=ot("models/logistic_regression_model_window.onnx"),u0=ot("models/meta-feature-network.onnx"),l0=ot("models/meta-feature-cookie.onnx"),d0=ot("models/meta-feature-window.onnx"),p0=ot("models/meta-classifier.onnx"),c0=ot("models/combined-classifier.onnx");let On=!1;const Pa=new Set,Jr=new Set;let Me=[],Xr=null,ei=null,qt=!1;function h0(e){e.length!==0&&(Me.push(e),Me.length>1e3&&Me.shift())}function f0(){if(Me.length===0)return null;const e=new Array(ri.length).fill(0);for(const t of Me)for(let r=0;r<t.length&&r<e.length;r++)t[r]===1&&(e[r]=1);return e}async function m0(){if($n)return;const e=await mr().catch(()=>null);if(!e)return;const{url:t}=e;if(t.startsWith("chrome://")||t.startsWith("chrome-extension://"))return;try{const[i]=await chrome.tabs.query({active:!0,currentWindow:!0});if((i==null?void 0:i.id)!==Xr||(i==null?void 0:i.url)!==ei){Me=[],qt=!1,Xr=(i==null?void 0:i.id)??null,ei=(i==null?void 0:i.url)??null;return}}catch{return}if(Me.length===0)return;const r=f0();if(!(!r||r.every(i=>i===0)))try{const a=(await n0.predict(r)).positiveClassProbability??0;if(console.log(`[Page Network Detection] Vector: [${r.join(",")}], Probability: ${(a*100).toFixed(2)}%, Requests: ${Me.length}`),a>=In&&!qt){qt=!0,chrome.notifications.create(`sst-page-network-${Date.now()}`,{type:"basic",iconUrl:chrome.runtime.getURL("icon-128.png"),title:"SST Detected (Page Network)",message:`Probability: ${(a*100).toFixed(1)}%`,priority:2});const s=await chrome.storage.local.get("pageNetworkDetections"),n=Array.isArray(s==null?void 0:s.pageNetworkDetections)?s.pageNetworkDetections:[];n.unshift({probability:a,vector:r,requestCount:Me.length,url:t,ts:Date.now()}),n.length>100&&(n.length=100),await chrome.storage.local.set({pageNetworkDetections:n}),_t({type:"SST_PAGE_NETWORK_DETECTED",payload:{probability:a,vector:r,requestCount:Me.length,url:t,ts:Date.now()}})}}catch(i){console.warn("Page network inference error:",i)}}setInterval(()=>{m0().catch(()=>{})},5e3);chrome.tabs.onUpdated.addListener((e,t,r)=>{t.status==="loading"&&r.active&&(Me=[],qt=!1,Xr=e,ei=r.url??null)});chrome.tabs.onActivated.addListener(async()=>{if(Me=[],qt=!1,await mr().catch(()=>null))try{const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});Xr=(t==null?void 0:t.id)??null,ei=(t==null?void 0:t.url)??null}catch{}});chrome.runtime.onMessage.addListener((e,t,r)=>{if(e&&e.type==="LR_PREDICT"){const{features:i}=e;return ff.predict(i).then(a=>{r({ok:!0,result:a})}).catch(a=>{r({ok:!1,error:(a==null?void 0:a.message)??String(a)})}),!0}if(e&&e.type==="WINDOW_VARS_EXTRACTED")return E0(e.payload,r),!0;if(e&&e.type==="RESET_ALERTED_DOMAINS")return Ua.clear(),Pa.clear(),ti.clear(),Jr.clear(),Me=[],qt=!1,De.clear(),r({ok:!0}),!0});const Va=[{name:"pattern_1_standard_ga",regex:/^GA1\.[123](-2)?\.[0-9]{6,10}\.17[0-9]{8,13}$/},{name:"pattern_2_double_prefix",regex:/^GA1\.1\.GA1\.2\.[0-9]{9,10}\.17[0-9]{11}$/},{name:"pattern_3_alphanumeric",regex:/^GA1\.2\.[a-z]{3}\.[A-Za-z0-9]{11}$/},{name:"pattern_4_uuid",regex:/^GA1\.1\.[a-z0-9]{8}-([0-9a-z]{4}-){3}[0-9a-z]{12}$/},{name:"pattern_5_ga4",regex:/^GS2\.1\.s17[0-9]{8}(\$[a-z][0-9]+)+$/}],mf={name:"google_tag_data[chrome_version]",regex:/(?!)/},gf={name:"google_tag_data[platform_version]",regex:/(?!)/},yf={name:"uapv",regex:/(?!)/},Ad=[{name:"dataLayer",regex:/"event":\s*"gtm\.(dom|load|js|scrollDepth)"|"event":\s*"coreWebVitals"/},{name:"gaGlobal[hid]",regex:/"hid":\s*\d+/},{name:"gaGlobal[vid]",regex:/"vid":\s*"\d+\.17[0-9]{8}"/},{name:"gaGlobal[fromCookie]",regex:/"from_cookie":\s*(?:true|false)/},mf,{name:"google_tag_data[brand_strings]",regex:/"(Chromium|Google Chrome|Not_A Brand)"/},{name:"google_tag_data[architecture]",regex:/"(arm|x86)"/},{name:"google_tag_data[bitness]",regex:/"(64|32)"/},gf,{name:"google_tag_data[container_id]",regex:/"G-[A-Z0-9]{5,10}"/}],ri=[{name:"cid",regex:/(?:GA\d+\.\d+\.)?\d{8,10}\.17\d{8,11}/},{name:"tid",regex:/G-[A-Z0-9]{10}/},{name:"dl",regex:/https:\/\/[^\s&#]+/},{name:"gtm",regex:/45[A-Za-z]{1,2}[0-9]{2}[A-Za-z0-9]+/},{name:"ul",regex:/([A-Za-z]{2}[-_][A-Za-z]{2})|([A-Za-z]{2})|([Ee]nglish)/},{name:"tag_exp",regex:/[0-9]{9}(~[0-9]{9}){8,}/},{name:"gcd",regex:/13([a-zA-Z_]{1}\d{1}){5}/},{name:"sid",regex:/\d{10}/},{name:"_p",regex:/\d{13}/},{name:"pscdl",regex:/(noapi|denied)/},{name:"tfd",regex:/\d{3,4}/},{name:"uaa",regex:/^(x86|arm)$/},{name:"uab",regex:/^(64|32)$/},{name:"uafvl",regex:/^(\[\{"brand":"[^"]+","version":"[^"]+"\}(,\{"brand":"[^"]+","version":"[^"]+"\})*\]|[A-Za-z0-9)(\s;|.%_-]+)$/},{name:"uap",regex:/^(Linux|macOS|Windows|Android|Chrome OS|Chromium OS|iOS)$/},yf,{name:"en",regex:/(page_view|scroll|ad_impression|user_engagement|view_item_list|view_item|scroll_depth|view_promotion|scroll_75|time_engaged|mp_pageview|ddm_standard_event|click|Scroll Depth|page_load_time|scroll_25|ads_impression|scroll_50|scroll_tracking|proctor|Newsfeed_show|Playbook Fired|scroll_90|page_scroll)/},{name:"_gid",regex:/\d{8,10}.\d{9,10}/},{name:"_u",regex:/([A-Za-z]{17}|[A-Za-z]{14}|[A-Za-z]{9}|[A-Za-z]{16})~/},{name:"_eu",regex:/'([A-Za-z]{2,3}[A-Z]{4})|([A-Z]{2,4})|([A-Za-z]{2,3})'/},{name:"gcs",regex:/'G[0-3\-]{3}'/},{name:"tcfd",regex:/'[0-6]{2}[0-9a-zA-Z]{2,3}[a-z]?$'/},{name:"ep.user_agent",regex:/'^([Mm]ozilla\/\d+\.\d+\s+\([^)]+\)\s+.+)$'/}];(async()=>{try{const e=await navigator.userAgentData.getHighEntropyValues(["uaFullVersion","platformVersion"]);if(e.uaFullVersion){const t=e.uaFullVersion.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");mf.regex=new RegExp(`"${t}"`)}if(e.platformVersion){const t=e.platformVersion.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");gf.regex=new RegExp(`"${t}"`),yf.regex=new RegExp(t)}await chrome.storage.local.set({browserHints:{uaFullVersion:e.uaFullVersion??null,platformVersion:e.platformVersion??null,platform:navigator.userAgentData.platform??null,brands:navigator.userAgentData.brands??[],mobile:navigator.userAgentData.mobile??!1}})}catch{}})();function g0(e){const t=new Array(23).fill(0);let r=null;try{r=new URL(e).searchParams}catch{return t}const i=[];return r.forEach(a=>{a!==""&&i.push(a)}),ri.forEach((a,s)=>{i.some(n=>a.regex.test(n))&&(t[s]=1)}),t}function y0(e){const t=e.url??"";return g0(t)}function _0(e){try{const t=new URL(e).hostname.toLowerCase();return!!(t.includes("google-analytics")||t.includes("doubleclick")||t.includes("googleads")||t==="analytics.google.com"||t.endsWith(".analytics.google.com"))}catch{return!1}}function nt(e){if(!e)return!1;const t=e.toLowerCase();return!!(t.includes("google")&&(t==="google.com"||t==="www.google.com"||t.startsWith("www.google.")||t.endsWith(".google.com")||t.endsWith(".googleapis.com")||t.endsWith(".gstatic.com")||t.endsWith(".googleusercontent.com")||t.endsWith(".googlesyndication.com")||t.endsWith(".googleadservices.com")||t.endsWith(".google-analytics.com")||t.endsWith(".googleads.com")||t.endsWith(".googleadservices.com")||t.endsWith(".googletagmanager.com")||t.endsWith(".googletagservices.com")||t.endsWith(".googleoptimize.com")||t.endsWith(".google.com.au")||t.endsWith(".google.co.uk")||t.endsWith(".google.de")||t.endsWith(".google.fr")||t.endsWith(".google.jp")||t.endsWith(".google.cn")||t.endsWith(".doubleclick.net")||t.includes("doubleclick")||t.includes("google-analytics")||t.includes("googleads")||t.includes("googlesyndication")||t.includes("googleadservices")))}const Gt=new Map;function _f(e){if(!e)return null;try{return new URL(e).hostname||null}catch{return null}}function b0(e,t){return e.type==="main_frame"?(e.tabId>=0&&Gt.set(e.tabId,t),t):e.tabId<0?null:Gt.get(e.tabId)??null}chrome.tabs.onUpdated.addListener((e,t)=>{const r=_f(t.url);r&&Gt.set(e,r)});chrome.tabs.onRemoved.addListener(e=>{Gt.delete(e)});chrome.tabs.query({}).then(e=>{for(const t of e){const r=_f(t.url);t.id!==void 0&&r&&!Gt.has(t.id)&&Gt.set(t.id,r)}}).catch(()=>{});try{chrome.webRequest.onBeforeRequest.addListener(e=>{if(bn||_0(e.url))return;const t=y0(e);let r=null;try{r=new URL(e.url).hostname}catch{}if(r&&!nt(r)&&h0(t),r&&!nt(r)){const i=b0(e,r);i&&I0(i,t)}ff.predict(t).then(i=>{const a={url:e.url,method:e.method,type:e.type,features:t,probability:i.positiveClassProbability,raw:Array.from(i.probabilities),predictedLabel:i.predictedLabel};console.log("LR inference",a),typeof i.positiveClassProbability=="number"&&i.positiveClassProbability>=Tn&&(w0(e.url,e.initiator).catch(()=>{}),k0({...a,ts:Date.now()}))}).catch(i=>{console.warn("Inference error for request",e.url,i)})},{urls:["<all_urls>"]},["requestBody"])}catch(e){console.warn("Failed to attach webRequest listeners:",e)}async function w0(e,t){if(_n)try{const r=new URL(e),i=r.hostname,a=r.pathname||"/";let s=null;try{t&&(s=new URL(t).hostname)}catch{s=null}if(s&&i!==s&&!nt(i)){if(!cr.has(i)){cr.add(i);const n=await chrome.storage.local.get(["blockedHosts"]),u=Array.isArray(n==null?void 0:n.blockedHosts)?n.blockedHosts:[];u.includes(i)||u.unshift(i),await chrome.storage.local.set({blockedHosts:u.slice(0,1e3)}),_t({type:"BLOCKLIST_UPDATED",payload:i})}}else{const n=`${i}|${a}`;if(!hr.has(n)){hr.add(n);const u=await chrome.storage.local.get(["blockedPaths"]),d=Array.isArray(u==null?void 0:u.blockedPaths)?u.blockedPaths:[];d.includes(n)||d.unshift(n),await chrome.storage.local.set({blockedPaths:d.slice(0,1e3)}),_t({type:"BLOCKLIST_UPDATED",payload:n})}}}catch{}}function $0(e){let t=0;for(let i=0;i<e.length;i++){const a=e.charCodeAt(i);t=(t<<5)-t+a,t|=0}return 1e5+Math.abs(t)%1e7}function v0(e){let t=0;for(let i=0;i<e.length;i++){const a=e.charCodeAt(i);t=(t<<5)-t+a,t|=0}return 5e6+Math.abs(t)%1e7}async function x0(e,t){try{const i=(await chrome.declarativeNetRequest.getDynamicRules()).map(n=>n.id),a=e.filter(n=>!nt(n)).map(n=>({id:$0(n),priority:1e4,action:{type:chrome.declarativeNetRequest.RuleActionType.BLOCK},condition:{regexFilter:"^https?://"+n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"(?::|/|$)",isUrlFilterCaseSensitive:!1,resourceTypes:["main_frame","sub_frame","stylesheet","script","image","font","xmlhttprequest","ping","websocket","other"]}})),s=t.map(n=>{const[u,d]=n.split("|"),p=u.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),f=d.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return{id:v0(n),priority:1e4,action:{type:chrome.declarativeNetRequest.RuleActionType.BLOCK},condition:{regexFilter:`^https?://${p}(?::\\d+)?${f}(?:[?#/]|$)`,isUrlFilterCaseSensitive:!1,resourceTypes:["main_frame","sub_frame","stylesheet","script","image","font","xmlhttprequest","ping","websocket","other"]}}});await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:i,addRules:[...a,...s]}),console.info("DNR: synced rules for hosts/paths",e,t)}catch{}}async function k0(e){try{const t=await chrome.storage.local.get("detections"),r=Array.isArray(t==null?void 0:t.detections)?t.detections:[];r.unshift(e),r.length>200&&(r.length=200),await chrome.storage.local.set({detections:r}),_t({type:"DETECTION_ADDED",payload:e})}catch(t){console.warn("Failed to record detection",t)}}const Ua=new Set;function S0(e){const t=new Array(Va.length).fill(0),r=[];for(const i of e){const a=i.value;Va.forEach((s,n)=>{s.regex.test(a)&&(t[n]=1,r.push({name:i.name,value:i.value,pattern:s.name}))})}return t.some(i=>i===1)&&(console.log("[Cookie Features] Vector:",t),console.log("[Cookie Features] Matched patterns:",r)),t}async function mr(){try{const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e!=null&&e.url?{domain:new URL(e.url).hostname,url:e.url}:null}catch{return null}}async function bf(e){try{const t=await chrome.cookies.getAll({domain:e}),r=e.startsWith(".")?e:"."+e,i=await chrome.cookies.getAll({domain:r}),a=await chrome.cookies.getAll({url:`https://${e}`}),s=new Set,n=[];for(const u of[...t,...i,...a]){const d=`${u.name}|${u.domain}`;s.has(d)||(s.add(d),n.push(u))}return n}catch{return[]}}async function T0(e){const t=[];try{const r=await bf(e);for(const i of r)if(Va.some(s=>s.regex.test(i.value))){const n=`https://${i.domain.startsWith(".")?i.domain.slice(1):i.domain}${i.path}`;try{await chrome.cookies.remove({url:n,name:i.name})?t.push({name:i.name,domain:i.domain,deleted:!0}):t.push({name:i.name,domain:i.domain,deleted:!1})}catch{t.push({name:i.name,domain:i.domain,deleted:!1})}}}catch(r){console.warn("Error while deleting tracking cookies:",r)}return t}async function ii(){if(wn)return;const e=await mr();if(!e)return;const{domain:t,url:r}=e;if(r.startsWith("chrome://")||r.startsWith("chrome-extension://"))return;const i=await bf(t);if(i.length===0)return;const a=S0(i);if(nt(t)||z0(t,a),!a.every(s=>s===0))try{const n=(await s0.predict(a)).positiveClassProbability??0;if(console.log(`[Cookie Detection] Domain: ${t}, Vector: [${a.join(",")}], Probability: ${(n*100).toFixed(2)}%`),n>=Cn&&(kn&&await T0(t),!Ua.has(t))){Ua.add(t),chrome.notifications.create(`sst-detected-${t}`,{type:"basic",iconUrl:chrome.runtime.getURL("icon-128.png"),title:"Server-Side Tracking Detected",message:`Domain: ${t}
Probability: ${(n*100).toFixed(1)}%`,priority:2}),_t({type:"SST_COOKIE_DETECTED",payload:{domain:t,probability:n,vector:a,ts:Date.now()}});const u=await chrome.storage.local.get("cookieDetections"),d=Array.isArray(u==null?void 0:u.cookieDetections)?u.cookieDetections:[];d.unshift({domain:t,probability:n,vector:a,ts:Date.now()}),d.length>100&&(d.length=100),await chrome.storage.local.set({cookieDetections:d})}}catch(s){console.warn("Cookie inference error for",t,s)}}chrome.alarms.create("cookieScan",{periodInMinutes:.5});chrome.alarms.onAlarm.addListener(e=>{e.name==="cookieScan"&&ii().catch(()=>{})});chrome.tabs.onActivated.addListener(()=>{setTimeout(()=>ii().catch(()=>{}),500)});chrome.tabs.onUpdated.addListener((e,t,r)=>{t.status==="complete"&&r.active&&[500,1500,3e3].forEach(a=>{setTimeout(()=>ii().catch(()=>{}),a)})});setTimeout(()=>ii().catch(()=>{}),2e3);function C0(e){const t=new Array(Ad.length).fill(0),r=new Set,i=[];for(const[a,s]of Object.entries(e))Ad.forEach((n,u)=>{n.regex.test(s)&&(t[u]=1,r.add(a),i.push({varName:a,pattern:n.name}))});return t.some(a=>a===1)&&(console.log("[Window Var Features] Vector:",t),console.log("[Window Var Features] Matched variables:",Array.from(r)),console.log("[Window Var Features] Matched patterns:",i)),{vector:t,matchedVars:Array.from(r)}}async function E0(e,t){if(On){t({detected:!1,reason:"paused"});return}const{domain:r,windowVars:i}=e;if(!i||Object.keys(i).length===0){t({detected:!1,reason:"no_vars"});return}const{vector:a,matchedVars:s}=C0(i);if(nt(r)||A0(r,a),a.every(n=>n===0)){t({detected:!1,reason:"no_match"});return}try{const u=(await o0.predict(a)).positiveClassProbability??0;if(console.log(`[Window Var Detection] Domain: ${r}, Vector: [${a.join(",")}], Probability: ${(u*100).toFixed(2)}%`),u>=En){if(!Pa.has(r)){Pa.add(r),chrome.notifications.create(`sst-window-detected-${r}`,{type:"basic",iconUrl:chrome.runtime.getURL("icon-128.png"),title:"SST Detected (Window Variables)",message:`Domain: ${r}
Probability: ${(u*100).toFixed(1)}%`,priority:2}),_t({type:"SST_WINDOW_VAR_DETECTED",payload:{domain:r,probability:u,vector:a,varsFound:Object.keys(i),matchedVars:s,ts:Date.now()}});const p=await chrome.storage.local.get("windowVarDetections"),f=Array.isArray(p==null?void 0:p.windowVarDetections)?p.windowVarDetections:[];f.unshift({domain:r,probability:u,vector:a,varsFound:Object.keys(i),matchedVars:s,ts:Date.now()}),f.length>100&&(f.length=100),await chrome.storage.local.set({windowVarDetections:f})}t({detected:!0,probability:u,varsToClear:Sn?s:[]})}else t({detected:!1,probability:u})}catch(n){console.warn("Window var inference error for",r,n),t({detected:!1,error:String(n)})}}const De=new Map,ti=new Set;let va=!1;function I0(e,t){if(!e||t.length===0)return;De.has(e)||De.set(e,{networkFeatures:[],cookieVector:null,windowVarVector:null,lastUpdated:Date.now()});const r=De.get(e);r.networkFeatures.push(t),r.lastUpdated=Date.now()}function z0(e,t){if(!e)return;De.has(e)||De.set(e,{networkFeatures:[],cookieVector:null,windowVarVector:null,lastUpdated:Date.now()});const r=De.get(e);r.cookieVector=t,r.lastUpdated=Date.now()}function A0(e,t){if(!e)return;De.has(e)||De.set(e,{networkFeatures:[],cookieVector:null,windowVarVector:null,lastUpdated:Date.now()});const r=De.get(e);r.windowVarVector=t,r.lastUpdated=Date.now()}async function O0(){if(vn)return;if(va){console.log("[Meta-Classifier] Already processing, skipping...");return}const e=await mr().catch(()=>null);if(!e)return;const{domain:t}=e;if(e.url.startsWith("chrome://")||e.url.startsWith("chrome-extension://")||nt(t))return;const r=De.get(t);if(r){if(r.networkFeatures.length===0||!r.cookieVector||!r.windowVarVector){console.log(`[Meta-Classifier] Skipping ${t}: network=${r.networkFeatures.length}, cookie=${r.cookieVector?"set":"null"}, window=${r.windowVarVector?"set":"null"}`);return}va=!0;try{const i=new Array(ri.length).fill(0);for(const y of r.networkFeatures)for(let _=0;_<y.length&&_<i.length;_++)y[_]===1&&(i[_]=1);if(i.every(y=>y===0)&&r.cookieVector.every(y=>y===0)&&r.windowVarVector.every(y=>y===0))return;const[a,s,n]=await Promise.all([u0.predict(i),l0.predict(r.cookieVector),d0.predict(r.windowVarVector)]),u=a.positiveClassProbability??0,d=s.positiveClassProbability??0,p=n.positiveClassProbability??0,f=[u,d,p],l=(await p0.predict(f)).positiveClassProbability??0;if(console.log(`[Meta-Classifier] Domain: ${t}, Network: ${(u*100).toFixed(1)}%, Cookie: ${(d*100).toFixed(1)}%, Window: ${(p*100).toFixed(1)}%, Final: ${(l*100).toFixed(1)}%`),l>=zn&&!ti.has(t)){ti.add(t),chrome.notifications.create(`sst-meta-${t}`,{type:"basic",iconUrl:chrome.runtime.getURL("icon-128.png"),title:"SST Detected (Meta-Classifier)",message:`Domain: ${t}
Probability: ${(l*100).toFixed(1)}%`,priority:2});const y=await chrome.storage.local.get("metaClassifierDetections"),_=Array.isArray(y==null?void 0:y.metaClassifierDetections)?y.metaClassifierDetections:[];_.unshift({domain:t,probability:l,networkProb:u,cookieProb:d,windowProb:p,ts:Date.now()}),_.length>100&&(_.length=100),await chrome.storage.local.set({metaClassifierDetections:_}),_t({type:"SST_META_CLASSIFIER_DETECTED",payload:{domain:t,probability:l,networkProb:u,cookieProb:d,windowProb:p,ts:Date.now()}})}}catch(i){console.warn("Meta-classifier inference error for",t,i)}finally{va=!1}}}setInterval(()=>{O0().catch(()=>{})},1e4);let xa=!1;async function D0(){if(xn)return;if(xa){console.log("[Combined Classifier] Already processing, skipping...");return}const e=await mr().catch(()=>null);if(!e)return;const{domain:t}=e;if(e.url.startsWith("chrome://")||e.url.startsWith("chrome-extension://")||nt(t))return;const r=De.get(t);if(r&&!(r.networkFeatures.length===0||!r.cookieVector||!r.windowVarVector)){xa=!0;try{const i=new Array(ri.length).fill(0);for(const u of r.networkFeatures)for(let d=0;d<u.length&&d<i.length;d++)u[d]===1&&(i[d]=1);const a=[...i,...r.cookieVector,...r.windowVarVector];if(a.every(u=>u===0))return;const n=(await c0.predict(a)).positiveClassProbability??0;if(console.log(`[Combined Classifier] Domain: ${t}, Vector length: ${a.length}, Probability: ${(n*100).toFixed(2)}%`),n>=An&&!Jr.has(t)){Jr.add(t),chrome.notifications.create(`sst-combined-${t}`,{type:"basic",iconUrl:chrome.runtime.getURL("icon-128.png"),title:"SST Detected (Combined Classifier)",message:`Domain: ${t}
Probability: ${(n*100).toFixed(1)}%`,priority:2});const u=await chrome.storage.local.get("combinedClassifierDetections"),d=Array.isArray(u==null?void 0:u.combinedClassifierDetections)?u.combinedClassifierDetections:[];d.unshift({domain:t,probability:n,vectorLength:a.length,ts:Date.now()}),d.length>100&&(d.length=100),await chrome.storage.local.set({combinedClassifierDetections:d}),_t({type:"SST_COMBINED_CLASSIFIER_DETECTED",payload:{domain:t,probability:n,vectorLength:a.length,ts:Date.now()}})}}catch(i){console.warn("Combined classifier inference error for",t,i)}finally{xa=!1}}}setInterval(()=>{D0().catch(()=>{})},1e4);chrome.tabs.onUpdated.addListener((e,t,r)=>{if(t.status==="loading"&&r.url)try{const a=new URL(r.url).hostname;for(const[s]of De.entries())(s!==a||nt(s))&&(De.delete(s),ti.delete(s),Jr.delete(s))}catch{}});
