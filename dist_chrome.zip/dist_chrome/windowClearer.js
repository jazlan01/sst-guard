// Window variable clearer - runs in page context
// Listens for a custom event with variable names to clear/block
(function() {
  window.addEventListener('__SST_CLEAR_VARS__', function handler(event) {
    window.removeEventListener('__SST_CLEAR_VARS__', handler);
    try {
      const varsToClear = JSON.parse(event.detail || '[]');
      for (const varName of varsToClear) {
        try {
          // First, clear the current value
          if (varName in window) {
            try {
              window[varName] = undefined;
            } catch (e) {
              // Property might not be writable
            }
          }
          
          // Then, try to redefine the property to permanently return undefined
          // This prevents scripts from re-setting the variable
          try {
            Object.defineProperty(window, varName, {
              get: function() { return undefined; },
              set: function() { /* silently ignore writes */ },
              configurable: true
            });
          } catch (e) {
            // Some properties can't be redefined, fall back to periodic clearing
          }
        } catch (e) {
          // Ignore errors for individual variables
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }
  });
})();
